import {
  Product,
  ProductVariant,
  Brand,
  Category,
  CartItem,
  WishlistItem,
  Order,
  OrderStatus,
  Offer,
  Banner,
  Review,
  BookingEnquiry,
  LuckyDrawPrize,
  LuckyDrawWinner,
  FinanceProvider,
  BookPageConfig,
  SiteSettings,
  AuditLog,
  Profile,
  UserRole,
} from '../types/database';
import {
  initialSiteSettings,
  initialBookPages,
  initialBrands,
  initialCategories,
  initialProducts,
  initialOffers,
  initialBanners,
  initialLuckyPrizes,
  initialLuckyWinners,
  initialFinanceProviders,
  initialReviews,
  initialOrders,
  initialAuditLogs,
  initialProfiles,
} from '../data/initialData';
import { isSupabaseConfigured, supabase } from '../lib/supabase';

// Local storage keys
const STORAGE_PREFIX = 'meru_store_';
const KEYS = {
  SETTINGS: `${STORAGE_PREFIX}settings`,
  BOOK_PAGES: `${STORAGE_PREFIX}book_pages`,
  BRANDS: `${STORAGE_PREFIX}brands`,
  CATEGORIES: `${STORAGE_PREFIX}categories`,
  PRODUCTS: `${STORAGE_PREFIX}products`,
  CART: `${STORAGE_PREFIX}cart`,
  WISHLIST: `${STORAGE_PREFIX}wishlist`,
  ORDERS: `${STORAGE_PREFIX}orders`,
  OFFERS: `${STORAGE_PREFIX}offers`,
  BANNERS: `${STORAGE_PREFIX}banners`,
  REVIEWS: `${STORAGE_PREFIX}reviews`,
  LUCKY_PRIZES: `${STORAGE_PREFIX}lucky_prizes`,
  LUCKY_WINNERS: `${STORAGE_PREFIX}lucky_winners`,
  FINANCE: `${STORAGE_PREFIX}finance`,
  BOOKINGS: `${STORAGE_PREFIX}bookings`,
  AUDIT: `${STORAGE_PREFIX}audit`,
  CURRENT_USER: `${STORAGE_PREFIX}user`,
};

function loadLocal<T>(key: string, fallback: T): T {
  try {
    const val = localStorage.getItem(key);
    if (val) return JSON.parse(val);
  } catch (err) {
    console.warn('Failed to load from localStorage:', key, err);
  }
  return fallback;
}

function saveLocal<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.warn('Failed to save to localStorage:', key, err);
  }
}

// Event emitter for cross-component realtime sync
type Listener = () => void;
const listeners: Set<Listener> = new Set();
export const subscribeToStore = (listener: Listener) => {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
};
const notify = () => {
  listeners.forEach((l) => l());
};

// Store Service
export const StoreService = {
  isCloudConnected: isSupabaseConfigured,

  // --- SITE SETTINGS ---
  getSettings: (): SiteSettings => {
    return loadLocal<SiteSettings>(KEYS.SETTINGS, initialSiteSettings);
  },
  updateSettings: async (settings: Partial<SiteSettings>, adminName = 'Admin'): Promise<SiteSettings> => {
    const current = StoreService.getSettings();
    const updated = { ...current, ...settings };
    saveLocal(KEYS.SETTINGS, updated);

    StoreService.addAuditLog({
      admin_name: adminName,
      action: 'UPDATE_SETTINGS',
      entity: 'SiteSettings',
      new_value: 'Store information & WhatsApp updated',
    });

    if (isSupabaseConfigured() && supabase) {
      try {
        await supabase.from('site_settings').upsert({ id: 'current', ...updated });
      } catch (e) {
        console.error('Supabase settings update error:', e);
      }
    }

    notify();
    return updated;
  },

  // --- BOOK PAGES ---
  getBookPages: (): BookPageConfig[] => {
    const pages = loadLocal<BookPageConfig[]>(KEYS.BOOK_PAGES, initialBookPages);
    return pages.sort((a, b) => a.display_order - b.display_order);
  },
  updateBookPages: async (pages: BookPageConfig[], adminName = 'Admin'): Promise<BookPageConfig[]> => {
    saveLocal(KEYS.BOOK_PAGES, pages);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: 'REORDER_BOOK_PAGES',
      entity: 'BookPages',
      new_value: `Updated ${pages.length} catalogue pages`,
    });

    if (isSupabaseConfigured() && supabase) {
      try {
        await supabase.from('book_pages').upsert(pages);
      } catch (e) {
        console.error('Supabase book pages update error:', e);
      }
    }

    notify();
    return pages;
  },
  toggleBookPage: (pageId: string, isEnabled: boolean, adminName = 'Admin') => {
    const pages = StoreService.getBookPages().map((p) =>
      p.id === pageId ? { ...p, is_enabled: isEnabled } : p
    );
    return StoreService.updateBookPages(pages, adminName);
  },

  // --- BRANDS & CATEGORIES ---
  getBrands: (): Brand[] => {
    return loadLocal<Brand[]>(KEYS.BRANDS, initialBrands).sort(
      (a, b) => a.display_order - b.display_order
    );
  },
  saveBrand: (brand: Brand, adminName = 'Admin') => {
    const brands = StoreService.getBrands();
    const index = brands.findIndex((b) => b.id === brand.id);
    let updated: Brand[];
    if (index >= 0) {
      updated = [...brands];
      updated[index] = brand;
    } else {
      updated = [...brands, brand];
    }
    saveLocal(KEYS.BRANDS, updated);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: index >= 0 ? 'UPDATE_BRAND' : 'CREATE_BRAND',
      entity: 'Brand',
      entity_id: brand.id,
      new_value: brand.name,
    });
    notify();
    return brand;
  },
  deleteBrand: (brandId: string, adminName = 'Admin') => {
    const brands = StoreService.getBrands().filter((b) => b.id !== brandId);
    saveLocal(KEYS.BRANDS, brands);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: 'DELETE_BRAND',
      entity: 'Brand',
      entity_id: brandId,
    });
    notify();
  },

  getCategories: (): Category[] => {
    return loadLocal<Category[]>(KEYS.CATEGORIES, initialCategories).sort(
      (a, b) => a.display_order - b.display_order
    );
  },
  saveCategory: (category: Category, adminName = 'Admin') => {
    const categories = StoreService.getCategories();
    const idx = categories.findIndex((c) => c.id === category.id);
    let updated: Category[];
    if (idx >= 0) {
      updated = [...categories];
      updated[idx] = category;
    } else {
      updated = [...categories, category];
    }
    saveLocal(KEYS.CATEGORIES, updated);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: idx >= 0 ? 'UPDATE_CATEGORY' : 'CREATE_CATEGORY',
      entity: 'Category',
      entity_id: category.id,
      new_value: category.name,
    });
    notify();
    return category;
  },
  deleteCategory: (categoryId: string, adminName = 'Admin') => {
    const categories = StoreService.getCategories().filter((c) => c.id !== categoryId);
    saveLocal(KEYS.CATEGORIES, categories);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: 'DELETE_CATEGORY',
      entity: 'Category',
      entity_id: categoryId,
    });
    notify();
  },

  // --- PRODUCTS ---
  getProducts: (): Product[] => {
    return loadLocal<Product[]>(KEYS.PRODUCTS, initialProducts);
  },
  getProductById: (id: string): Product | undefined => {
    return StoreService.getProducts().find((p) => p.id === id);
  },
  saveProduct: (product: Product, adminName = 'Admin'): Product => {
    const products = StoreService.getProducts();
    const index = products.findIndex((p) => p.id === product.id);
    let updated: Product[];

    // Calculate total stock from variants if available
    let totalStock = product.stock_quantity;
    if (product.variants && product.variants.length > 0) {
      totalStock = product.variants.reduce((acc, v) => acc + (Number(v.stock_quantity) || 0), 0);
    }
    const stockStatus =
      totalStock <= 0 ? 'out_of_stock' : totalStock <= 5 ? 'low_stock' : 'in_stock';

    const normalizedProduct: Product = {
      ...product,
      stock_quantity: totalStock,
      stock_status: stockStatus,
      updated_at: new Date().toISOString(),
    };

    if (index >= 0) {
      updated = [...products];
      updated[index] = normalizedProduct;
    } else {
      updated = [normalizedProduct, ...products];
    }

    saveLocal(KEYS.PRODUCTS, updated);

    StoreService.addAuditLog({
      admin_name: adminName,
      action: index >= 0 ? 'UPDATE_PRODUCT' : 'CREATE_PRODUCT',
      entity: 'Product',
      entity_id: product.id,
      new_value: `${product.name} (₹${product.selling_price})`,
    });

    notify();
    return normalizedProduct;
  },
  deleteProduct: (productId: string, adminName = 'Admin') => {
    const products = StoreService.getProducts().filter((p) => p.id !== productId);
    saveLocal(KEYS.PRODUCTS, products);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: 'DELETE_PRODUCT',
      entity: 'Product',
      entity_id: productId,
    });
    notify();
  },
  adjustInventory: (
    productId: string,
    variantId: string | undefined,
    adjustmentAmount: number,
    reason: string,
    adminName = 'Admin'
  ) => {
    const products = StoreService.getProducts();
    const product = products.find((p) => p.id === productId);
    if (!product) return;

    const prevQty = product.stock_quantity;
    let newQty = prevQty;
    let variantInfo = '';

    if (variantId && product.variants) {
      product.variants = product.variants.map((v) => {
        if (v.id === variantId) {
          variantInfo = `${v.color_name} - ${v.ram || ''}/${v.storage || ''}`;
          const currentVariantStock = v.stock_quantity || 0;
          const adjustedVariantStock = Math.max(0, currentVariantStock + adjustmentAmount);
          return { ...v, stock_quantity: adjustedVariantStock };
        }
        return v;
      });
      newQty = product.variants.reduce((acc, v) => acc + (v.stock_quantity || 0), 0);
    } else {
      newQty = Math.max(0, prevQty + adjustmentAmount);
    }

    product.stock_quantity = newQty;
    product.stock_status = newQty <= 0 ? 'out_of_stock' : newQty <= 5 ? 'low_stock' : 'in_stock';
    product.updated_at = new Date().toISOString();

    saveLocal(KEYS.PRODUCTS, products);

    StoreService.addAuditLog({
      admin_name: adminName,
      action: 'ADJUST_STOCK',
      entity: 'Product',
      entity_id: productId,
      previous_value: `Stock was: ${prevQty}`,
      new_value: `Stock changed by ${adjustmentAmount > 0 ? '+' : ''}${adjustmentAmount} to ${newQty}. Reason: ${reason}. ${variantInfo}`,
    });

    notify();
  },

  // --- CART ---
  getCart: (): CartItem[] => {
    return loadLocal<CartItem[]>(KEYS.CART, []);
  },
  addToCart: (product: Product, variantId?: string, quantity = 1): CartItem[] => {
    const cart = StoreService.getCart();
    // Default to first variant or synthesize variant
    const variant: ProductVariant =
      (variantId && product.variants?.find((v) => v.id === variantId)) ||
      product.variants?.[0] || {
        id: `synth-${product.id}`,
        product_id: product.id,
        sku: product.sku,
        color_name: 'Standard',
        mrp: product.mrp,
        selling_price: product.selling_price,
        stock_quantity: product.stock_quantity,
        is_default: true,
      };

    const existingIndex = cart.findIndex(
      (item) => item.product_id === product.id && item.variant_id === variant.id
    );

    let updated: CartItem[];
    if (existingIndex >= 0) {
      updated = [...cart];
      updated[existingIndex].quantity += quantity;
    } else {
      const newItem: CartItem = {
        id: `cart-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        product_id: product.id,
        product,
        variant_id: variant.id,
        variant,
        quantity,
        added_at: new Date().toISOString(),
      };
      updated = [...cart, newItem];
    }

    saveLocal(KEYS.CART, updated);
    notify();
    return updated;
  },
  updateCartQuantity: (itemId: string, quantity: number): CartItem[] => {
    let cart = StoreService.getCart();
    if (quantity <= 0) {
      cart = cart.filter((i) => i.id !== itemId);
    } else {
      cart = cart.map((i) => (i.id === itemId ? { ...i, quantity } : i));
    }
    saveLocal(KEYS.CART, cart);
    notify();
    return cart;
  },
  clearCart: () => {
    saveLocal(KEYS.CART, []);
    notify();
  },

  // --- WISHLIST ---
  getWishlist: (): WishlistItem[] => {
    return loadLocal<WishlistItem[]>(KEYS.WISHLIST, []);
  },
  toggleWishlist: (product: Product): boolean => {
    const wishlist = StoreService.getWishlist();
    const exists = wishlist.some((item) => item.product_id === product.id);
    let updated: WishlistItem[];
    if (exists) {
      updated = wishlist.filter((item) => item.product_id !== product.id);
    } else {
      updated = [
        ...wishlist,
        {
          id: `w-${Date.now()}`,
          product_id: product.id,
          product,
          added_at: new Date().toISOString(),
        },
      ];
    }
    saveLocal(KEYS.WISHLIST, updated);
    notify();
    return !exists;
  },
  isInWishlist: (productId: string): boolean => {
    return StoreService.getWishlist().some((item) => item.product_id === productId);
  },

  // --- OFFERS & COUPONS ---
  getOffers: (): Offer[] => {
    return loadLocal<Offer[]>(KEYS.OFFERS, initialOffers);
  },
  saveOffer: (offer: Offer, adminName = 'Admin'): Offer => {
    const offers = StoreService.getOffers();
    const idx = offers.findIndex((o) => o.id === offer.id);
    let updated: Offer[];
    if (idx >= 0) {
      updated = [...offers];
      updated[idx] = offer;
    } else {
      updated = [offer, ...offers];
    }
    saveLocal(KEYS.OFFERS, updated);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: idx >= 0 ? 'UPDATE_OFFER' : 'CREATE_OFFER',
      entity: 'Offer',
      entity_id: offer.id,
      new_value: `${offer.name} (${offer.coupon_code || 'No Code'})`,
    });
    notify();
    return offer;
  },
  deleteOffer: (offerId: string, adminName = 'Admin') => {
    const offers = StoreService.getOffers().filter((o) => o.id !== offerId);
    saveLocal(KEYS.OFFERS, offers);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: 'DELETE_OFFER',
      entity: 'Offer',
      entity_id: offerId,
    });
    notify();
  },
  applyCoupon: (code: string, subtotal: number): { valid: boolean; discount: number; message: string; offer?: Offer } => {
    if (!code) return { valid: false, discount: 0, message: 'Please enter a coupon code' };
    const offers = StoreService.getOffers();
    const trimmed = code.trim().toUpperCase();
    const offer = offers.find(
      (o) => o.coupon_code && o.coupon_code.toUpperCase() === trimmed && o.is_active
    );

    if (!offer) {
      return { valid: false, discount: 0, message: 'Invalid or expired coupon code' };
    }

    if (offer.min_order_amount && subtotal < offer.min_order_amount) {
      return {
        valid: false,
        discount: 0,
        message: `This coupon requires minimum order of ₹${offer.min_order_amount.toLocaleString('en-IN')}`,
      };
    }

    let discount = 0;
    if (offer.discount_type === 'percentage') {
      discount = Math.round((subtotal * offer.discount_value) / 100);
    } else {
      discount = offer.discount_value;
    }
    discount = Math.min(discount, subtotal);

    return {
      valid: true,
      discount,
      message: `Coupon "${offer.coupon_code}" applied successfully! You saved ₹${discount.toLocaleString('en-IN')}`,
      offer,
    };
  },

  // --- ORDERS ---
  getOrders: (): Order[] => {
    return loadLocal<Order[]>(KEYS.ORDERS, initialOrders);
  },
  getOrderById: (orderId: string): Order | undefined => {
    return StoreService.getOrders().find(
      (o) => o.id === orderId || o.order_number.toLowerCase() === orderId.toLowerCase()
    );
  },
  createOrder: async (orderData: Omit<Order, 'id' | 'order_number' | 'created_at' | 'updated_at' | 'status_history'>): Promise<Order> => {
    const orderNumber = `MERU-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newOrder: Order = {
      ...orderData,
      id: `ord-${Date.now()}`,
      order_number: orderNumber,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      status_history: [
        {
          id: `hist-${Date.now()}`,
          order_id: `ord-${Date.now()}`,
          status: 'Pending',
          note: 'Order successfully registered at Meru Mobile Shop (सिरनोटा वालों की दुकान)',
          created_at: new Date().toISOString(),
        },
      ],
    };

    const orders = [newOrder, ...StoreService.getOrders()];
    saveLocal(KEYS.ORDERS, orders);

    // Auto reduce stock for ordered items
    newOrder.items.forEach((item) => {
      StoreService.adjustInventory(
        item.product_id,
        item.variant_id,
        -item.quantity,
        `Customer Order ${orderNumber}`
      );
    });

    // Clear cart
    StoreService.clearCart();

    if (isSupabaseConfigured() && supabase) {
      try {
        await supabase.from('orders').insert({
          id: newOrder.id,
          order_number: newOrder.order_number,
          customer_name: newOrder.customer_name,
          customer_phone: newOrder.customer_phone,
          customer_email: newOrder.customer_email,
          shipping_address: newOrder.shipping_address,
          subtotal: newOrder.subtotal,
          discount_amount: newOrder.discount_amount,
          coupon_code: newOrder.coupon_code,
          delivery_charge: newOrder.delivery_charge,
          final_amount: newOrder.final_amount,
          payment_method: newOrder.payment_method,
          payment_status: newOrder.payment_status,
          order_status: newOrder.order_status,
          order_notes: newOrder.order_notes,
        });
      } catch (e) {
        console.error('Supabase order creation error:', e);
      }
    }

    notify();
    return newOrder;
  },
  updateOrderStatus: async (
    orderId: string,
    newStatus: OrderStatus,
    note?: string,
    adminName = 'Maneesh Jain'
  ): Promise<Order | undefined> => {
    const orders = StoreService.getOrders();
    const orderIndex = orders.findIndex((o) => o.id === orderId);
    if (orderIndex === -1) return undefined;

    const order = orders[orderIndex];
    const historyItem = {
      id: `h-${Date.now()}`,
      order_id: order.id,
      status: newStatus,
      note: note || `Status changed to ${newStatus}`,
      created_at: new Date().toISOString(),
      updated_by: adminName,
    };

    const updatedOrder: Order = {
      ...order,
      order_status: newStatus,
      updated_at: new Date().toISOString(),
      status_history: [...order.status_history, historyItem],
    };

    orders[orderIndex] = updatedOrder;
    saveLocal(KEYS.ORDERS, orders);

    StoreService.addAuditLog({
      admin_name: adminName,
      action: 'UPDATE_ORDER_STATUS',
      entity: 'Order',
      entity_id: order.order_number,
      new_value: `Status changed to ${newStatus}`,
    });

    if (isSupabaseConfigured() && supabase) {
      try {
        await supabase.from('orders').update({ order_status: newStatus }).eq('id', orderId);
        await supabase.from('order_status_history').insert({
          order_id: orderId,
          status: newStatus,
          note: note || `Status changed to ${newStatus}`,
          updated_by: adminName,
        });
      } catch (e) {
        console.error('Supabase update order status error:', e);
      }
    }

    notify();
    return updatedOrder;
  },

  // --- LUCKY DRAW ---
  getLuckyPrizes: (): LuckyDrawPrize[] => {
    return loadLocal<LuckyDrawPrize[]>(KEYS.LUCKY_PRIZES, initialLuckyPrizes);
  },
  saveLuckyPrize: (prize: LuckyDrawPrize, adminName = 'Admin'): LuckyDrawPrize => {
    const prizes = StoreService.getLuckyPrizes();
    const idx = prizes.findIndex((p) => p.id === prize.id);
    let updated: LuckyDrawPrize[];
    if (idx >= 0) {
      updated = [...prizes];
      updated[idx] = prize;
    } else {
      updated = [...prizes, prize];
    }
    saveLocal(KEYS.LUCKY_PRIZES, updated);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: idx >= 0 ? 'UPDATE_LUCKY_PRIZE' : 'CREATE_LUCKY_PRIZE',
      entity: 'LuckyDrawPrize',
      entity_id: prize.id,
      new_value: prize.name,
    });
    notify();
    return prize;
  },
  getLuckyWinners: (): LuckyDrawWinner[] => {
    return loadLocal<LuckyDrawWinner[]>(KEYS.LUCKY_WINNERS, initialLuckyWinners);
  },
  playLuckyDraw: (
    customerName: string,
    customerPhone: string
  ): { won: boolean; prize?: LuckyDrawPrize; winner?: LuckyDrawWinner } => {
    const prizes = StoreService.getLuckyPrizes().filter(
      (p) => p.is_active && p.remaining_quantity > 0
    );

    if (prizes.length === 0) {
      return { won: false };
    }

    // Weighted random selection based on prize winning_chance_percent
    const totalWeight = prizes.reduce((acc, p) => acc + (p.winning_chance_percent || 10), 0);
    let randomNum = Math.random() * totalWeight;
    let chosenPrize = prizes[0];

    for (const p of prizes) {
      randomNum -= p.winning_chance_percent || 10;
      if (randomNum <= 0) {
        chosenPrize = p;
        break;
      }
    }

    // Decrement remaining count
    chosenPrize.remaining_quantity = Math.max(0, chosenPrize.remaining_quantity - 1);
    StoreService.saveLuckyPrize(chosenPrize, 'System Lucky Draw Engine');

    const ticketNumber = `MERU-WIN-${Math.floor(100000 + Math.random() * 900000)}`;
    const winner: LuckyDrawWinner = {
      id: `win-${Date.now()}`,
      customer_name: customerName,
      customer_phone: customerPhone,
      prize_id: chosenPrize.id,
      prize_name: chosenPrize.name,
      prize_image: chosenPrize.image_url,
      draw_date: new Date().toISOString(),
      is_delivered: false,
      ticket_number: ticketNumber,
    };

    const winners = [winner, ...StoreService.getLuckyWinners()];
    saveLocal(KEYS.LUCKY_WINNERS, winners);
    notify();

    return { won: true, prize: chosenPrize, winner };
  },
  markPrizeDelivered: (winnerId: string, adminName = 'Admin') => {
    const winners = StoreService.getLuckyWinners().map((w) =>
      w.id === winnerId
        ? { ...w, is_delivered: true, delivery_date: new Date().toISOString().split('T')[0] }
        : w
    );
    saveLocal(KEYS.LUCKY_WINNERS, winners);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: 'DELIVER_LUCKY_PRIZE',
      entity: 'LuckyDrawWinner',
      entity_id: winnerId,
    });
    notify();
  },

  // --- REVIEWS ---
  getReviews: (): Review[] => {
    return loadLocal<Review[]>(KEYS.REVIEWS, initialReviews);
  },
  submitReview: (review: Omit<Review, 'id' | 'is_approved' | 'created_at'>): Review => {
    const newRev: Review = {
      ...review,
      id: `rev-${Date.now()}`,
      is_approved: false, // Moderated by Admin
      created_at: new Date().toISOString(),
    };
    const reviews = [newRev, ...StoreService.getReviews()];
    saveLocal(KEYS.REVIEWS, reviews);
    notify();
    return newRev;
  },
  toggleReviewApproval: (reviewId: string, approved: boolean, adminName = 'Admin') => {
    const reviews = StoreService.getReviews().map((r) =>
      r.id === reviewId ? { ...r, is_approved: approved } : r
    );
    saveLocal(KEYS.REVIEWS, reviews);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: approved ? 'APPROVE_REVIEW' : 'REJECT_REVIEW',
      entity: 'Review',
      entity_id: reviewId,
    });
    notify();
  },
  deleteReview: (reviewId: string, adminName = 'Admin') => {
    const reviews = StoreService.getReviews().filter((r) => r.id !== reviewId);
    saveLocal(KEYS.REVIEWS, reviews);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: 'DELETE_REVIEW',
      entity: 'Review',
      entity_id: reviewId,
    });
    notify();
  },

  // --- BOOKINGS / ENQUIRIES ---
  getBookings: (): BookingEnquiry[] => {
    return loadLocal<BookingEnquiry[]>(KEYS.BOOKINGS, [
      {
        id: 'bk-1',
        customer_name: 'Dinesh Ahirwar',
        customer_phone: '9826543210',
        enquiry_type: 'Finance EMI Enquiry',
        product_name: 'Samsung Galaxy S24 5G',
        preferred_date: '2025-06-15',
        message: 'Need 10-month zero down-payment Bajaj EMI for S24.',
        status: 'Contacted',
        admin_notes: 'Spoke on phone, invited to Tyoda Road shop with Aadhaar & PAN.',
        created_at: '2025-06-10T11:00:00Z',
      },
    ]);
  },
  createBooking: (booking: Omit<BookingEnquiry, 'id' | 'status' | 'created_at'>): BookingEnquiry => {
    const newBooking: BookingEnquiry = {
      ...booking,
      id: `bk-${Date.now()}`,
      status: 'New',
      created_at: new Date().toISOString(),
    };
    const bookings = [newBooking, ...StoreService.getBookings()];
    saveLocal(KEYS.BOOKINGS, bookings);
    notify();
    return newBooking;
  },
  updateBookingStatus: (
    bookingId: string,
    status: BookingEnquiry['status'],
    adminNotes?: string,
    adminName = 'Admin'
  ) => {
    const bookings = StoreService.getBookings().map((b) =>
      b.id === bookingId ? { ...b, status, admin_notes: adminNotes ?? b.admin_notes } : b
    );
    saveLocal(KEYS.BOOKINGS, bookings);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: 'UPDATE_BOOKING_STATUS',
      entity: 'BookingEnquiry',
      entity_id: bookingId,
      new_value: status,
    });
    notify();
  },

  // --- FINANCE PROVIDERS ---
  getFinanceProviders: (): FinanceProvider[] => {
    return loadLocal<FinanceProvider[]>(KEYS.FINANCE, initialFinanceProviders);
  },
  saveFinanceProvider: (provider: FinanceProvider, adminName = 'Admin'): FinanceProvider => {
    const list = StoreService.getFinanceProviders();
    const idx = list.findIndex((f) => f.id === provider.id);
    let updated: FinanceProvider[];
    if (idx >= 0) {
      updated = [...list];
      updated[idx] = provider;
    } else {
      updated = [...list, provider];
    }
    saveLocal(KEYS.FINANCE, updated);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: idx >= 0 ? 'UPDATE_FINANCE_PROVIDER' : 'CREATE_FINANCE_PROVIDER',
      entity: 'FinanceProvider',
      entity_id: provider.id,
      new_value: provider.name,
    });
    notify();
    return provider;
  },

  // --- BANNERS ---
  getBanners: (): Banner[] => {
    return loadLocal<Banner[]>(KEYS.BANNERS, initialBanners).sort(
      (a, b) => a.display_order - b.display_order
    );
  },
  saveBanner: (banner: Banner, adminName = 'Admin'): Banner => {
    const banners = StoreService.getBanners();
    const idx = banners.findIndex((b) => b.id === banner.id);
    let updated: Banner[];
    if (idx >= 0) {
      updated = [...banners];
      updated[idx] = banner;
    } else {
      updated = [...banners, banner];
    }
    saveLocal(KEYS.BANNERS, updated);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: idx >= 0 ? 'UPDATE_BANNER' : 'CREATE_BANNER',
      entity: 'Banner',
      entity_id: banner.id,
      new_value: banner.title,
    });
    notify();
    return banner;
  },
  deleteBanner: (bannerId: string, adminName = 'Admin') => {
    const banners = StoreService.getBanners().filter((b) => b.id !== bannerId);
    saveLocal(KEYS.BANNERS, banners);
    StoreService.addAuditLog({
      admin_name: adminName,
      action: 'DELETE_BANNER',
      entity: 'Banner',
      entity_id: bannerId,
    });
    notify();
  },

  // --- AUDIT LOGS ---
  getAuditLogs: (): AuditLog[] => {
    return loadLocal<AuditLog[]>(KEYS.AUDIT, initialAuditLogs);
  },
  addAuditLog: (log: Omit<AuditLog, 'id' | 'created_at'>) => {
    const newLog: AuditLog = {
      ...log,
      id: `aud-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      created_at: new Date().toISOString(),
    };
    const logs = [newLog, ...StoreService.getAuditLogs()].slice(0, 150);
    saveLocal(KEYS.AUDIT, logs);
  },

  // --- AUTH & ROLES ---
  getCurrentUser: (): Profile | null => {
    return loadLocal<Profile | null>(KEYS.CURRENT_USER, null);
  },
  setCurrentUser: (user: Profile | null) => {
    saveLocal(KEYS.CURRENT_USER, user);
    notify();
  },
  getProfiles: (): Profile[] => {
    return initialProfiles;
  },
  loginWithCredentials: async (
    phoneOrEmail: string,
    role: UserRole = 'customer',
    name = 'Customer'
  ): Promise<Profile> => {
    const profile: Profile = {
      id: `user-${Date.now()}`,
      phone: phoneOrEmail.includes('@') ? '9826000000' : phoneOrEmail,
      email: phoneOrEmail.includes('@') ? phoneOrEmail : undefined,
      full_name: name,
      role: role,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    StoreService.setCurrentUser(profile);
    return profile;
  },
  logout: () => {
    StoreService.setCurrentUser(null);
  },

  // Reset to default seed
  resetToDefaultSeed: () => {
    localStorage.removeItem(KEYS.SETTINGS);
    localStorage.removeItem(KEYS.BOOK_PAGES);
    localStorage.removeItem(KEYS.BRANDS);
    localStorage.removeItem(KEYS.CATEGORIES);
    localStorage.removeItem(KEYS.PRODUCTS);
    localStorage.removeItem(KEYS.OFFERS);
    localStorage.removeItem(KEYS.BANNERS);
    localStorage.removeItem(KEYS.REVIEWS);
    localStorage.removeItem(KEYS.LUCKY_PRIZES);
    localStorage.removeItem(KEYS.LUCKY_WINNERS);
    localStorage.removeItem(KEYS.FINANCE);
    localStorage.removeItem(KEYS.BOOKINGS);
    localStorage.removeItem(KEYS.AUDIT);
    notify();
  },
};
