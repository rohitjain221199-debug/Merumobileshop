export type UserRole = 'super_admin' | 'admin' | 'manager' | 'staff' | 'customer';

export type OrderStatus =
  | 'Pending'
  | 'Confirmed'
  | 'Processing'
  | 'Packed'
  | 'Shipped'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Cancelled'
  | 'Returned'
  | 'Refunded';

export type PaymentMethod = 'COD' | 'UPI_QR' | 'STORE_PICKUP_PAY';
export type PaymentStatus = 'pending' | 'completed' | 'failed' | 'refunded';

export interface Profile {
  id: string;
  email?: string;
  phone: string;
  full_name: string;
  role: UserRole;
  avatar_url?: string;
  created_at: string;
  updated_at: string;
}

export interface Brand {
  id: string;
  name: string;
  slug: string;
  logo_url: string;
  display_order: number;
  is_active: boolean;
  featured: boolean;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  icon_name?: string;
  image_url?: string;
  display_order: number;
  is_active: boolean;
}

export interface ProductVariant {
  id: string;
  product_id: string;
  sku: string;
  color_name: string;
  color_hex?: string;
  ram?: string;
  storage?: string;
  mrp: number;
  selling_price: number;
  stock_quantity: number;
  image_url?: string;
  is_default?: boolean;
}

export interface ProductImage {
  id: string;
  product_id: string;
  image_url: string;
  display_order: number;
  is_primary: boolean;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  brand_id: string;
  brand_name?: string;
  category_id: string;
  category_name?: string;
  model: string;
  description: string;
  short_description: string;
  specifications: Record<string, string>;
  mrp: number;
  selling_price: number;
  offer_price?: number;
  discount_percent: number;
  stock_quantity: number;
  stock_status: 'in_stock' | 'low_stock' | 'out_of_stock';
  sku: string;
  barcode?: string;
  warranty: string;
  is_5g: boolean;
  network_type?: string;
  primary_image: string;
  images: ProductImage[];
  variants: ProductVariant[];
  is_featured: boolean;
  is_new_arrival: boolean;
  is_bestseller: boolean;
  is_offer_product: boolean;
  is_active: boolean;
  seo_title?: string;
  seo_description?: string;
  seo_keywords?: string;
  created_at: string;
  updated_at: string;
}

export interface InventoryTransaction {
  id: string;
  product_id: string;
  product_name: string;
  variant_id?: string;
  variant_info?: string;
  previous_quantity: number;
  new_quantity: number;
  change_amount: number;
  reason: string;
  admin_name: string;
  created_at: string;
}

export interface CartItem {
  id: string;
  product_id: string;
  product: Product;
  variant_id: string;
  variant: ProductVariant;
  quantity: number;
  added_at: string;
}

export interface WishlistItem {
  id: string;
  product_id: string;
  product: Product;
  added_at: string;
}

export interface Address {
  id: string;
  user_id?: string;
  full_name: string;
  phone: string;
  alternate_phone?: string;
  address_line1: string;
  landmark?: string;
  city: string;
  state: string;
  pincode: string;
  is_default?: boolean;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product_name: string;
  variant_id?: string;
  variant_description?: string;
  image_url: string;
  price: number;
  mrp: number;
  quantity: number;
  subtotal: number;
}

export interface OrderStatusHistoryItem {
  id: string;
  order_id: string;
  status: OrderStatus;
  note?: string;
  created_at: string;
  updated_by?: string;
}

export interface Order {
  id: string;
  order_number: string;
  user_id?: string;
  customer_name: string;
  customer_phone: string;
  customer_email?: string;
  items: OrderItem[];
  shipping_address: Address;
  subtotal: number;
  discount_amount: number;
  coupon_code?: string;
  delivery_charge: number;
  final_amount: number;
  payment_method: PaymentMethod;
  payment_status: PaymentStatus;
  order_status: OrderStatus;
  status_history: OrderStatusHistoryItem[];
  order_notes?: string;
  created_at: string;
  updated_at: string;
}

export interface Offer {
  id: string;
  name: string;
  description: string;
  discount_type: 'percentage' | 'flat';
  discount_value: number;
  coupon_code?: string;
  min_order_amount: number;
  applicable_category_id?: string;
  applicable_product_id?: string;
  start_date: string;
  end_date: string;
  usage_limit?: number;
  usage_count: number;
  is_active: boolean;
  banner_badge?: string;
}

export interface Banner {
  id: string;
  title: string;
  subtitle?: string;
  image_url: string;
  button_text: string;
  button_destination: string;
  display_order: number;
  is_active: boolean;
  start_date?: string;
  end_date?: string;
}

export interface Review {
  id: string;
  product_id: string;
  product_name?: string;
  customer_name: string;
  customer_phone?: string;
  rating: number;
  title: string;
  comment: string;
  image_url?: string;
  is_approved: boolean;
  created_at: string;
}

export interface BookingEnquiry {
  id: string;
  customer_name: string;
  customer_phone: string;
  enquiry_type: 'Phone Enquiry' | 'Product Reservation' | 'Store Visit' | 'Finance EMI Enquiry' | 'Callback Request';
  product_name?: string;
  preferred_date?: string;
  message?: string;
  status: 'New' | 'Contacted' | 'Processing' | 'Completed' | 'Cancelled';
  admin_notes?: string;
  created_at: string;
}

export interface LuckyDrawPrize {
  id: string;
  name: string;
  image_url: string;
  total_quantity: number;
  remaining_quantity: number;
  winning_chance_percent: number;
  is_active: boolean;
}

export interface LuckyDrawWinner {
  id: string;
  customer_name: string;
  customer_phone: string;
  prize_id: string;
  prize_name: string;
  prize_image: string;
  draw_date: string;
  is_delivered: boolean;
  delivery_date?: string;
  ticket_number: string;
}

export interface FinanceProvider {
  id: string;
  name: string;
  logo_url: string;
  is_active: boolean;
  tagline: string;
  interest_rate_from: string;
  tenure_options: string;
  documents_required: string[];
  eligibility_notes: string;
  terms: string;
  cta_text: string;
}

export interface BookPageConfig {
  id: string;
  page_number: number;
  slug: string;
  title: string;
  subtitle: string;
  chapter_name: string;
  icon_name: string;
  is_enabled: boolean;
  display_order: number;
  background_style?: string;
  cta_label?: string;
  cta_target_page?: number;
}

export interface SiteSettings {
  shop_name: string;
  brand_tagline: string;
  owner_name: string;
  phone: string;
  whatsapp_number: string;
  email: string;
  address_street: string;
  address_area: string;
  address_city: string;
  address_district: string;
  address_state: string;
  address_pincode: string;
  landmark: string;
  google_maps_url: string;
  opening_hours: string;
  facebook_url?: string;
  instagram_url?: string;
  youtube_url?: string;
  about_text: string;
  announcement_bar_text: string;
  free_delivery_above: number;
  cod_available: boolean;
}

export interface AuditLog {
  id: string;
  admin_name: string;
  action: string;
  entity: string;
  entity_id?: string;
  previous_value?: string;
  new_value?: string;
  created_at: string;
}

export interface AppNotification {
  id: string;
  type: 'order' | 'booking' | 'stock' | 'lucky_draw' | 'system';
  title: string;
  message: string;
  created_at: string;
  is_read: boolean;
  link?: string;
}
