import React, { useState, useEffect, useMemo } from 'react';
import { StoreService, subscribeToStore } from './services/storeService';
import {
  Product,
  Brand,
  Category,
  Offer,
  Banner,
  FinanceProvider,
  Review,
  CartItem,
  WishlistItem,
  Order,
  BookPageConfig,
  LuckyDrawPrize,
  LuckyDrawWinner,
  BookingEnquiry,
  SiteSettings,
  AuditLog,
  Profile,
} from './types/database';

// Navigation & Layout
import { Navbar } from './components/navigation/Navbar';
import { Footer } from './components/navigation/Footer';
import { WhatsAppButton } from './components/common/WhatsAppButton';

// Main Customer Views
import { HomeView } from './components/home/HomeView';
import { ProductListingView } from './components/products/ProductListingView';
import { ProductDetailPage } from './components/products/ProductDetailPage';
import { CartView } from './components/cart/CartView';
import { CheckoutView } from './components/checkout/CheckoutView';
import { FinanceView } from './components/finance/FinanceView';
import { LuckyDrawView } from './components/luckydraw/LuckyDrawView';
import { OffersView } from './components/offers/OffersView';
import { ReviewsView } from './components/reviews/ReviewsView';
import { TrackingView } from './components/tracking/TrackingView';
import { AboutView } from './components/info/AboutView';
import { ContactView } from './components/info/ContactView';
import { AccountView } from './components/account/AccountView';
import { WishlistView } from './components/products/WishlistView';

// Modals
import { SearchModal } from './components/common/SearchModal';
import { BookingModal } from './components/common/BookingModal';

// Admin System
import { AdminLayout } from './components/admin/AdminLayout';

export default function App() {
  // Navigation & View State
  const [route, setRoute] = useState<string>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [viewMode, setViewMode] = useState<'store' | 'admin'>('store');

  // Modals state
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isBookingOpen, setIsBookingOpen] = useState<boolean>(false);
  const [bookingType, setBookingType] = useState<BookingEnquiry['enquiry_type']>('Product Reservation');
  const [bookingProduct, setBookingProduct] = useState<string>('');

  // Live state from StoreService
  const [settings, setSettings] = useState<SiteSettings>(StoreService.getSettings());
  const [bookPages, setBookPages] = useState<BookPageConfig[]>(StoreService.getBookPages());
  const [products, setProducts] = useState<Product[]>(StoreService.getProducts());
  const [brands, setBrands] = useState<Brand[]>(StoreService.getBrands());
  const [categories, setCategories] = useState<Category[]>(StoreService.getCategories());
  const [offers, setOffers] = useState<Offer[]>(StoreService.getOffers());
  const [banners, setBanners] = useState<Banner[]>(StoreService.getBanners());
  const [financeProviders, setFinanceProviders] = useState<FinanceProvider[]>(StoreService.getFinanceProviders());
  const [reviews, setReviews] = useState<Review[]>(StoreService.getReviews());
  const [cart, setCart] = useState<CartItem[]>(StoreService.getCart());
  const [wishlist, setWishlist] = useState<WishlistItem[]>(StoreService.getWishlist());
  const [orders, setOrders] = useState<Order[]>(StoreService.getOrders());
  const [luckyPrizes, setLuckyPrizes] = useState<LuckyDrawPrize[]>(StoreService.getLuckyPrizes());
  const [luckyWinners, setLuckyWinners] = useState<LuckyDrawWinner[]>(StoreService.getLuckyWinners());
  const [bookings, setBookings] = useState<BookingEnquiry[]>(StoreService.getBookings());
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(StoreService.getAuditLogs());
  const [currentUser, setCurrentUser] = useState<Profile | null>(StoreService.getCurrentUser());

  // Subscribe to real-time store updates
  useEffect(() => {
    const unsubscribe = subscribeToStore(() => {
      setSettings(StoreService.getSettings());
      setBookPages(StoreService.getBookPages());
      setProducts(StoreService.getProducts());
      setBrands(StoreService.getBrands());
      setCategories(StoreService.getCategories());
      setOffers(StoreService.getOffers());
      setBanners(StoreService.getBanners());
      setFinanceProviders(StoreService.getFinanceProviders());
      setReviews(StoreService.getReviews());
      setCart(StoreService.getCart());
      setWishlist(StoreService.getWishlist());
      setOrders(StoreService.getOrders());
      setLuckyPrizes(StoreService.getLuckyPrizes());
      setLuckyWinners(StoreService.getLuckyWinners());
      setBookings(StoreService.getBookings());
      setAuditLogs(StoreService.getAuditLogs());
      setCurrentUser(StoreService.getCurrentUser());
    });
    return () => unsubscribe();
  }, []);

  // Browser History & URL Navigation support
  useEffect(() => {
    const handlePopState = (e: PopStateEvent) => {
      if (e.state && e.state.route) {
        setRoute(e.state.route);
        if (e.state.productId) {
          const prod = StoreService.getProductById(e.state.productId);
          setSelectedProduct(prod || null);
        } else {
          setSelectedProduct(null);
        }
      } else {
        const hash = window.location.hash.replace('#', '');
        if (hash) {
          setRoute(hash);
        } else {
          setRoute('home');
        }
        setSelectedProduct(null);
      }
    };

    window.addEventListener('popstate', handlePopState);

    // Initial route check from hash
    const initialHash = window.location.hash.replace('#', '');
    if (initialHash) {
      if (initialHash === 'admin') {
        setViewMode('admin');
      } else {
        setRoute(initialHash);
      }
    }

    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Route Navigation Handler with History Push
  const navigateTo = (newRoute: string, prod?: Product) => {
    if (newRoute === 'admin') {
      setViewMode('admin');
      window.history.pushState({ route: 'admin' }, '', '#admin');
      return;
    }

    setViewMode('store');
    setRoute(newRoute);

    if (prod) {
      setSelectedProduct(prod);
      window.history.pushState({ route: newRoute, productId: prod.id }, '', `#product-${prod.id}`);
    } else {
      setSelectedProduct(null);
      window.history.pushState({ route: newRoute }, '', `#${newRoute}`);
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenProduct = (product: Product) => {
    navigateTo('product', product);
  };

  const handleBackFromProduct = () => {
    setSelectedProduct(null);
    navigateTo('home');
  };

  // Cart & Wishlist Actions
  const handleAddToCart = (product: Product, variantId?: string) => {
    StoreService.addToCart(product, variantId, 1);
  };

  const handleBuyNow = (product: Product, variantId?: string) => {
    StoreService.addToCart(product, variantId, 1);
    setSelectedProduct(null);
    navigateTo('checkout');
  };

  const handleToggleWishlist = (product: Product) => {
    StoreService.toggleWishlist(product);
  };

  const handleUpdateCartQty = (itemId: string, qty: number) => {
    StoreService.updateCartQuantity(itemId, qty);
  };

  const handleOpenEnquiry = (type: BookingEnquiry['enquiry_type'] = 'Product Reservation', product = '') => {
    setBookingType(type);
    setBookingProduct(product);
    setIsBookingOpen(true);
  };

  const wishlistIds = useMemo(() => {
    return new Set(wishlist.map((w) => w.product_id));
  }, [wishlist]);

  const totalCartCount = useMemo(() => {
    return cart.reduce((acc, item) => acc + item.quantity, 0);
  }, [cart]);

  // If in Admin Mode, render the full professional Admin Management panel
  if (viewMode === 'admin') {
    return (
      <AdminLayout
        currentUser={currentUser}
        onLogin={(profile) => StoreService.setCurrentUser(profile)}
        onLogout={() => StoreService.logout()}
        onReturnToStore={() => {
          setViewMode('store');
          navigateTo('home');
        }}
        products={products}
        orders={orders}
        offers={offers}
        brands={brands}
        categories={categories}
        bookPages={bookPages}
        luckyPrizes={luckyPrizes}
        luckyWinners={luckyWinners}
        reviews={reviews}
        bookings={bookings}
        settings={settings}
        auditLogs={auditLogs}
      />
    );
  }

  // Render the Main View based on current route or selected product
  const renderCurrentView = () => {
    // 1. Product Detail Page
    if (selectedProduct) {
      return (
        <ProductDetailPage
          product={selectedProduct}
          settings={settings}
          onBack={handleBackFromProduct}
          onAddToCart={handleAddToCart}
          onBuyNow={handleBuyNow}
          onToggleWishlist={handleToggleWishlist}
          isInWishlist={wishlistIds.has(selectedProduct.id)}
        />
      );
    }

    // 2. Dynamic Brand Route (e.g., 'brand-samsung')
    if (route.startsWith('brand-')) {
      const brandSlug = route.replace('brand-', '');
      const brand = brands.find((b) => b.slug === brandSlug);
      return (
        <ProductListingView
          title={brand ? `${brand.name} Smartphones` : 'Brand Showcase'}
          subtitle={brand ? `Original sealed-pack ${brand.name} phones with official brand warranty` : undefined}
          initialBrandSlug={brandSlug}
          products={products}
          brands={brands}
          categories={categories}
          onOpenProduct={handleOpenProduct}
          onAddToCart={handleAddToCart}
          onToggleWishlist={handleToggleWishlist}
          wishlistIds={wishlistIds}
        />
      );
    }

    // 3. Dynamic Category Route (e.g., 'category-earbuds')
    if (route.startsWith('category-')) {
      const catSlug = route.replace('category-', '');
      const cat = categories.find((c) => c.slug === catSlug);
      return (
        <ProductListingView
          title={cat ? cat.name : 'Accessories'}
          subtitle={cat ? cat.description : undefined}
          initialCategorySlug={catSlug}
          products={products}
          brands={brands}
          categories={categories}
          onOpenProduct={handleOpenProduct}
          onAddToCart={handleAddToCart}
          onToggleWishlist={handleToggleWishlist}
          wishlistIds={wishlistIds}
        />
      );
    }

    // 4. Standard App Routes
    switch (route) {
      case 'mobiles':
        return (
          <ProductListingView
            title="All Smartphones & Mobile Phones"
            subtitle="Explore latest 5G flagships, camera specialists, and budget champions in Ganj Basoda"
            initialCategorySlug="cat-smartphones"
            products={products}
            brands={brands}
            categories={categories}
            onOpenProduct={handleOpenProduct}
            onAddToCart={handleAddToCart}
            onToggleWishlist={handleToggleWishlist}
            wishlistIds={wishlistIds}
          />
        );

      case 'accessories':
        return (
          <ProductListingView
            title="Genuine Mobile Accessories"
            subtitle="Original earbuds, fast chargers, neckbands, smartwatches, and protection accessories"
            initialCategorySlug="all"
            products={products.filter((p) => p.category_id !== 'cat-smartphones')}
            brands={brands}
            categories={categories.filter((c) => c.id !== 'cat-smartphones')}
            onOpenProduct={handleOpenProduct}
            onAddToCart={handleAddToCart}
            onToggleWishlist={handleToggleWishlist}
            wishlistIds={wishlistIds}
          />
        );

      case 'offers':
        return <OffersView offers={offers} onNavigate={navigateTo} />;

      case 'lucky-draw':
      case 'luckydraw':
        return <LuckyDrawView settings={settings} onNavigate={navigateTo} />;

      case 'finance':
        return (
          <FinanceView
            providers={financeProviders}
            onOpenEnquiry={() => handleOpenEnquiry('Finance EMI Enquiry')}
            onNavigate={navigateTo}
          />
        );

      case 'reviews':
        return (
          <ReviewsView
            reviews={reviews}
            products={products}
            onReviewSubmitted={() => {}}
          />
        );

      case 'about':
        return (
          <AboutView
            settings={settings}
            onNavigate={navigateTo}
            onOpenEnquiry={() => handleOpenEnquiry('Store Visit')}
          />
        );

      case 'contact':
        return (
          <ContactView
            settings={settings}
            onOpenEnquiry={() => handleOpenEnquiry('Store Visit')}
          />
        );

      case 'cart':
        return (
          <CartView
            cart={cart}
            settings={settings}
            onUpdateQty={handleUpdateCartQty}
            onProceedToCheckout={() => navigateTo('checkout')}
            onContinueShopping={() => navigateTo('mobiles')}
          />
        );

      case 'checkout':
        return (
          <CheckoutView
            cart={cart}
            settings={settings}
            onOrderSuccess={(order) => navigateTo('tracking')}
            onNavigate={navigateTo}
          />
        );

      case 'tracking':
        return <TrackingView onNavigate={navigateTo} />;

      case 'account':
        return (
          <AccountView
            settings={settings}
            orders={orders}
            onNavigate={navigateTo}
            onTrackOrder={() => navigateTo('tracking')}
          />
        );

      case 'wishlist':
        return (
          <WishlistView
            wishlist={wishlist}
            onOpenProduct={handleOpenProduct}
            onAddToCart={handleAddToCart}
            onRemoveFromWishlist={handleToggleWishlist}
            onNavigate={navigateTo}
          />
        );

      case 'home':
      default:
        return (
          <HomeView
            settings={settings}
            banners={banners}
            brands={brands}
            categories={categories}
            products={products}
            financeProviders={financeProviders}
            reviews={reviews}
            onNavigate={navigateTo}
            onOpenProduct={handleOpenProduct}
            onAddToCart={handleAddToCart}
            onToggleWishlist={handleToggleWishlist}
            wishlistIds={wishlistIds}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col selection:bg-blue-600 selection:text-white">
      {/* 1. Global Navigation Bar */}
      <Navbar
        settings={settings}
        categories={categories}
        brands={brands}
        currentRoute={route}
        onNavigate={navigateTo}
        cartCount={totalCartCount}
        wishlistCount={wishlist.length}
        onOpenSearch={() => setIsSearchOpen(true)}
      />

      {/* 2. Main Content View with Page Transition */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
        <div key={selectedProduct ? selectedProduct.id : route} className="animate-page-enter">
          {renderCurrentView()}
        </div>
      </main>

      {/* 3. Global Footer */}
      <Footer settings={settings} onNavigate={navigateTo} />

      {/* 4. Floating WhatsApp Support Button */}
      <WhatsAppButton
        whatsappNumber={settings.whatsapp_number}
        shopName={settings.shop_name}
        defaultMessage="Hello Meru Mobile Shop, mujhe smartphones aur showroom offers ke baare mein jankari chahiye."
      />

      {/* 5. Real-Time Search & Filter Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        products={products}
        brands={brands}
        categories={categories}
        onSelectProduct={(p) => {
          setIsSearchOpen(false);
          handleOpenProduct(p);
        }}
      />

      {/* 6. Booking & Store Callback Modal */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        defaultType={bookingType}
        defaultProduct={bookingProduct}
        whatsappNumber={settings.whatsapp_number}
      />
    </div>
  );
}
