import React from 'react';
import { MapPin, Phone, MessageCircle, ShieldCheck, Heart, Clock, ArrowRight, ExternalLink } from 'lucide-react';
import { SiteSettings } from '../../types/database';
import { createWhatsAppUrl } from '../../utils/formatters';

interface FooterProps {
  settings: SiteSettings;
  onNavigate: (route: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ settings, onNavigate }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 pt-12 pb-8 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 pb-10 border-b border-slate-800">
          {/* Col 1: Brand & Tagline */}
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center font-bold text-white text-lg font-serif-display">
                M
              </div>
              <div>
                <h3 className="font-black text-white text-base tracking-tight">
                  {settings.shop_name}
                </h3>
                <p className="text-amber-400 font-hindi font-bold text-xs">
                  {settings.brand_tagline}
                </p>
              </div>
            </div>

            <p className="text-slate-400 leading-relaxed text-xs">
              Ganj Basoda's trusted mobile showroom for 15+ years. 100% genuine sealed pack smartphones, official brand warranty, 15-minute 0% EMI finance, and friendly local service.
            </p>

            <div className="pt-1 flex items-center gap-2 text-slate-400">
              <span className="font-semibold text-white">Owner:</span>
              <span>{settings.owner_name}</span>
            </div>
          </div>

          {/* Col 2: Quick Shop Links */}
          <div className="space-y-3">
            <h4 className="font-bold text-white text-sm uppercase tracking-wider">
              Showroom Catalogue
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button
                  onClick={() => onNavigate('mobiles')}
                  className="hover:text-blue-400 transition-colors"
                >
                  Latest 5G Smartphones
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('accessories')}
                  className="hover:text-blue-400 transition-colors"
                >
                  boAt Earbuds & Neckbands
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('accessories')}
                  className="hover:text-blue-400 transition-colors"
                >
                  Noise Smart Watches
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('accessories')}
                  className="hover:text-blue-400 transition-colors"
                >
                  GaN 65W Chargers & Cables
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('offers')}
                  className="hover:text-blue-400 transition-colors text-emerald-400 font-semibold"
                >
                  Festival Coupons & Discounts
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('lucky-draw')}
                  className="hover:text-amber-400 transition-colors text-amber-400 font-semibold"
                >
                  🎁 Festive Lucky Draw
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Customer Care & Schemes */}
          <div className="space-y-3">
            <h4 className="font-bold text-white text-sm uppercase tracking-wider">
              Customer Services
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button
                  onClick={() => onNavigate('finance')}
                  className="hover:text-blue-400 transition-colors"
                >
                  0% Easy EMI Finance (Bajaj, HDB, IDFC)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('tracking')}
                  className="hover:text-blue-400 transition-colors"
                >
                  Track Device Order Status
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('reviews')}
                  className="hover:text-blue-400 transition-colors"
                >
                  Verified Customer Reviews
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('about')}
                  className="hover:text-blue-400 transition-colors"
                >
                  About सिरनोटा वालों की दुकान
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-blue-400 transition-colors"
                >
                  Store Directions & Hours
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('admin')}
                  className="hover:text-amber-400 text-amber-300 font-medium"
                >
                  Admin & Inventory Login
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Store Location & Timings */}
          <div className="space-y-3">
            <h4 className="font-bold text-white text-sm uppercase tracking-wider">
              Showroom Location
            </h4>
            <div className="space-y-2 text-slate-400">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <span>
                  {settings.address_street}, {settings.landmark}, {settings.address_city}, Dist. {settings.address_district} (MP) – {settings.address_pincode}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{settings.opening_hours}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-blue-400 shrink-0" />
                <a href={`tel:${settings.phone}`} className="hover:text-white font-mono">
                  {settings.phone}
                </a>
              </div>
            </div>

            <div className="pt-1 flex gap-2">
              <a
                href={settings.google_maps_url}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <span>Get Directions</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>

        {/* Regulatory Disclaimer & Copyright */}
        <div className="pt-6 flex flex-col md:flex-row items-center justify-between gap-3 text-slate-500 text-[11px]">
          <div>
            © {new Date().getFullYear()} {settings.shop_name} • सिरनोटा वालों की दुकान (Ganj Basoda). All Rights Reserved.
          </div>
          <div className="text-center md:text-right text-[10px]">
            * 0% EMI schemes subject to provider verification. Final eligibility and approval are subject to the finance provider's rules.
          </div>
        </div>
      </div>
    </footer>
  );
};
