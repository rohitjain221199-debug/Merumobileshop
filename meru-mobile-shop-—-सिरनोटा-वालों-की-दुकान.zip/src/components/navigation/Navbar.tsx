import React, { useState } from 'react';
import {
  Smartphone,
  ShoppingBag,
  Heart,
  Search,
  MapPin,
  Phone,
  ShieldCheck,
  User,
  Menu,
  X,
  Tag,
  Gift,
  CreditCard,
  ChevronDown,
} from 'lucide-react';
import { SiteSettings, Category, Brand } from '../../types/database';

interface NavbarProps {
  settings: SiteSettings;
  categories: Category[];
  brands: Brand[];
  currentRoute: string;
  onNavigate: (route: string) => void;
  cartCount: number;
  wishlistCount: number;
  onOpenSearch: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  settings,
  categories,
  brands,
  currentRoute,
  onNavigate,
  cartCount,
  wishlistCount,
  onOpenSearch,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobilesDropdown, setMobilesDropdown] = useState(false);
  const [accessoriesDropdown, setAccessoriesDropdown] = useState(false);

  const handleNavClick = (route: string) => {
    onNavigate(route);
    setMobileMenuOpen(false);
    setMobilesDropdown(false);
    setAccessoriesDropdown(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top Announcement Bar */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 text-white text-xs py-1.5 px-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 overflow-hidden whitespace-nowrap">
            <span className="bg-amber-400 text-blue-950 font-extrabold px-1.5 py-0.5 rounded text-[10px] uppercase tracking-wider">
              Showroom
            </span>
            <span className="truncate text-xs font-medium text-blue-50">
              {settings.announcement_bar_text}
            </span>
          </div>

          <div className="hidden md:flex items-center gap-4 text-blue-100 shrink-0 text-xs">
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-blue-300" />
              Tyoda Road, Ganj Basoda
            </span>
            <a
              href={`tel:${settings.phone}`}
              className="flex items-center gap-1 hover:text-white font-medium"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-300" />
              {settings.phone}
            </a>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-18 flex items-center justify-between gap-4">
        {/* Mobile Hamburger Button */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2 text-slate-700 hover:text-blue-600 rounded-xl lg:hidden focus:outline-none"
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>

        {/* Brand Logo & Tagline */}
        <div
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-3 cursor-pointer group shrink-0"
        >
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-700 via-blue-600 to-indigo-600 p-0.5 shadow-md shadow-blue-500/20 flex items-center justify-center font-bold text-white text-xl">
            <span className="font-serif-display">M</span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black text-base sm:text-lg tracking-tight text-slate-900 uppercase group-hover:text-blue-600 transition-colors">
                {settings.shop_name}
              </span>
              <span className="hidden sm:inline-block bg-blue-50 text-blue-700 text-[10px] font-bold px-1.5 py-0.5 rounded border border-blue-200">
                Ganj Basoda
              </span>
            </div>
            <p className="text-xs text-amber-600 font-hindi font-semibold flex items-center gap-1">
              <span>★</span> {settings.brand_tagline}
            </p>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-xs font-semibold text-slate-700">
          <button
            onClick={() => handleNavClick('home')}
            className={`px-3 py-2 rounded-xl transition-colors ${
              currentRoute === 'home' ? 'text-blue-600 bg-blue-50 font-bold' : 'hover:text-blue-600 hover:bg-slate-50'
            }`}
          >
            Home
          </button>

          {/* Mobiles Dropdown Trigger */}
          <div
            className="relative"
            onMouseEnter={() => setMobilesDropdown(true)}
            onMouseLeave={() => setMobilesDropdown(false)}
          >
            <button
              onClick={() => handleNavClick('mobiles')}
              className={`px-3 py-2 rounded-xl flex items-center gap-1 transition-colors ${
                currentRoute === 'mobiles' ? 'text-blue-600 bg-blue-50 font-bold' : 'hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              <span>Mobiles</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-60" />
            </button>

            {mobilesDropdown && (
              <div className="absolute top-full left-0 w-56 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 py-2.5 z-50 animate-in fade-in slide-in-from-top-1">
                <button
                  onClick={() => handleNavClick('mobiles')}
                  className="w-full text-left px-3 py-2 rounded-xl hover:bg-blue-50 hover:text-blue-600 text-xs font-bold text-slate-800"
                >
                  All Smartphones
                </button>
                <div className="h-[1px] bg-slate-100 my-1" />
                <div className="text-[10px] text-slate-400 font-bold px-3 py-1 uppercase tracking-wider">
                  Top Brands
                </div>
                {brands.slice(0, 6).map((b) => (
                  <button
                    key={b.id}
                    onClick={() => handleNavClick(`brand-${b.slug}`)}
                    className="w-full text-left px-3 py-1.5 rounded-lg hover:bg-slate-50 hover:text-blue-600 text-xs text-slate-600"
                  >
                    {b.name} Phones
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Accessories Dropdown Trigger */}
          <div
            className="relative"
            onMouseEnter={() => setAccessoriesDropdown(true)}
            onMouseLeave={() => setAccessoriesDropdown(false)}
          >
            <button
              onClick={() => handleNavClick('accessories')}
              className={`px-3 py-2 rounded-xl flex items-center gap-1 transition-colors ${
                currentRoute === 'accessories' ? 'text-blue-600 bg-blue-50 font-bold' : 'hover:text-blue-600 hover:bg-slate-50'
              }`}
            >
              <span>Accessories</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-60" />
            </button>

            {accessoriesDropdown && (
              <div className="absolute top-full left-0 w-60 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 py-2.5 z-50 animate-in fade-in slide-in-from-top-1">
                <button
                  onClick={() => handleNavClick('accessories')}
                  className="w-full text-left px-3 py-2 rounded-xl hover:bg-blue-50 hover:text-blue-600 text-xs font-bold text-slate-800"
                >
                  All Genuine Accessories
                </button>
                <div className="h-[1px] bg-slate-100 my-1" />
                {categories
                  .filter((c) => c.id !== 'cat-smartphones')
                  .map((c) => (
                    <button
                      key={c.id}
                      onClick={() => handleNavClick(`category-${c.slug}`)}
                      className="w-full text-left px-3 py-1.5 rounded-lg hover:bg-slate-50 hover:text-blue-600 text-xs text-slate-600"
                    >
                      {c.name}
                    </button>
                  ))}
              </div>
            )}
          </div>

          <button
            onClick={() => handleNavClick('offers')}
            className={`px-3 py-2 rounded-xl flex items-center gap-1 transition-colors ${
              currentRoute === 'offers' ? 'text-blue-600 bg-blue-50 font-bold' : 'hover:text-blue-600 hover:bg-slate-50'
            }`}
          >
            <Tag className="w-3.5 h-3.5 text-emerald-500" />
            <span>Offers</span>
          </button>

          <button
            onClick={() => handleNavClick('lucky-draw')}
            className={`px-3 py-2 rounded-xl flex items-center gap-1 transition-colors ${
              currentRoute === 'lucky-draw' ? 'text-amber-600 bg-amber-50 font-bold' : 'text-amber-600 hover:bg-amber-50'
            }`}
          >
            <Gift className="w-3.5 h-3.5 text-amber-500" />
            <span>Lucky Draw</span>
          </button>

          <button
            onClick={() => handleNavClick('finance')}
            className={`px-3 py-2 rounded-xl flex items-center gap-1 transition-colors ${
              currentRoute === 'finance' ? 'text-blue-600 bg-blue-50 font-bold' : 'hover:text-blue-600 hover:bg-slate-50'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5 text-blue-500" />
            <span>0% EMI</span>
          </button>

          <button
            onClick={() => handleNavClick('contact')}
            className={`px-3 py-2 rounded-xl transition-colors ${
              currentRoute === 'contact' ? 'text-blue-600 bg-blue-50 font-bold' : 'hover:text-blue-600 hover:bg-slate-50'
            }`}
          >
            Contact
          </button>
        </nav>

        {/* Right Action Icons: Search, Wishlist, Bag, Admin */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Search Button */}
          <button
            onClick={onOpenSearch}
            className="p-2.5 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-colors flex items-center gap-1.5 text-xs font-semibold"
            title="Search phones & accessories"
          >
            <Search className="w-4 h-4 text-slate-500" />
            <span className="hidden xl:inline text-slate-500">Search</span>
          </button>

          {/* Wishlist Button */}
          <button
            onClick={() => handleNavClick('wishlist')}
            className="relative p-2.5 text-slate-600 hover:text-pink-600 hover:bg-pink-50 rounded-xl transition-colors"
            title="Wishlist"
          >
            <Heart className="w-4 h-4" />
            {wishlistCount > 0 && (
              <span className="absolute top-1 right-1 bg-pink-500 text-white text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
          </button>

          {/* Cart Button */}
          <button
            onClick={() => handleNavClick('cart')}
            className="relative flex items-center gap-2 px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-600/20 transition-all active:scale-95"
            title="View Shopping Bag"
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="hidden sm:inline">Bag</span>
            <span className="bg-white/20 text-white font-extrabold text-[11px] px-1.5 py-0.2 rounded-full">
              {cartCount}
            </span>
          </button>

          {/* Customer Account Button */}
          <button
            onClick={() => handleNavClick('account')}
            className="p-2.5 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-colors hidden sm:block"
            title="Customer Account & Orders"
          >
            <User className="w-4 h-4" />
          </button>

          {/* Admin Management Portal Trigger */}
          <button
            onClick={() => handleNavClick('admin')}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-xl transition-colors font-bold"
            title="Admin Management"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
            <span className="hidden sm:inline">Admin</span>
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex bg-black/60 backdrop-blur-xs">
          <div className="w-72 max-w-[80vw] bg-white h-full p-4 flex flex-col justify-between shadow-2xl overflow-y-auto">
            <div className="space-y-4">
              {/* Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div>
                  <h3 className="font-black text-slate-900 text-sm">MERU MOBILE SHOP</h3>
                  <p className="text-[11px] text-amber-600 font-hindi">सिरनोटा वालों की दुकान</p>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 text-slate-400 hover:text-slate-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Links */}
              <div className="space-y-1 text-xs font-semibold text-slate-700">
                <button
                  onClick={() => handleNavClick('home')}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-blue-50 hover:text-blue-600 flex items-center justify-between"
                >
                  <span>Home</span>
                </button>
                <button
                  onClick={() => handleNavClick('mobiles')}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-blue-50 hover:text-blue-600 flex items-center justify-between"
                >
                  <span>Smartphones</span>
                  <span className="text-[10px] text-blue-600 font-bold bg-blue-50 px-2 py-0.5 rounded">
                    5G Ready
                  </span>
                </button>
                <button
                  onClick={() => handleNavClick('accessories')}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-blue-50 hover:text-blue-600"
                >
                  Genuine Accessories
                </button>
                <button
                  onClick={() => handleNavClick('offers')}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-blue-50 hover:text-blue-600 flex items-center gap-2"
                >
                  <Tag className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Today's Offers</span>
                </button>
                <button
                  onClick={() => handleNavClick('lucky-draw')}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-amber-50 text-amber-600 flex items-center gap-2 font-bold"
                >
                  <Gift className="w-3.5 h-3.5" />
                  <span>Festive Lucky Draw</span>
                </button>
                <button
                  onClick={() => handleNavClick('finance')}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-blue-50 hover:text-blue-600 flex items-center gap-2"
                >
                  <CreditCard className="w-3.5 h-3.5 text-blue-500" />
                  <span>0% EMI Finance</span>
                </button>
                <button
                  onClick={() => handleNavClick('tracking')}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-blue-50 hover:text-blue-600"
                >
                  Track My Order
                </button>
                <button
                  onClick={() => handleNavClick('reviews')}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-blue-50 hover:text-blue-600"
                >
                  Customer Reviews
                </button>
                <button
                  onClick={() => handleNavClick('about')}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-blue-50 hover:text-blue-600"
                >
                  About Meru Mobile
                </button>
                <button
                  onClick={() => handleNavClick('contact')}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-blue-50 hover:text-blue-600"
                >
                  Contact & Location
                </button>
                <button
                  onClick={() => handleNavClick('account')}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-blue-50 hover:text-blue-600 flex items-center gap-2"
                >
                  <User className="w-3.5 h-3.5" />
                  <span>My Account</span>
                </button>
              </div>
            </div>

            {/* Bottom Admin link & phone */}
            <div className="pt-4 border-t border-slate-100 space-y-2">
              <button
                onClick={() => handleNavClick('admin')}
                className="w-full py-2.5 px-3 bg-amber-50 border border-amber-200 text-amber-800 rounded-xl text-xs font-bold flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-4 h-4 text-amber-600" />
                <span>Shop Admin Panel</span>
              </button>
              <div className="text-[11px] text-slate-500 text-center">
                Tyoda Road, Ganj Basoda (MP)
              </div>
            </div>
          </div>

          <div className="flex-1" onClick={() => setMobileMenuOpen(false)} />
        </div>
      )}
    </header>
  );
};
