import React, { useState } from 'react';
import { CreditCard, Calculator, FileText, CheckCircle2, ShieldAlert, PhoneCall, ArrowRight } from 'lucide-react';
import { FinanceProvider } from '../../types/database';
import { formatPrice } from '../../utils/formatters';

interface FinanceViewProps {
  providers: FinanceProvider[];
  onOpenEnquiry: () => void;
  onNavigate: (route: string) => void;
}

export const FinanceView: React.FC<FinanceViewProps> = ({
  providers,
  onOpenEnquiry,
  onNavigate,
}) => {
  const [devicePrice, setDevicePrice] = useState<number>(30000);
  const [tenure, setTenure] = useState<number>(6);
  const [downPayment, setDownPayment] = useState<number>(0);

  const loanAmount = Math.max(0, devicePrice - downPayment);
  const estimatedEmi = Math.round(loanAmount / tenure);

  return (
    <div className="space-y-8 animate-page-enter max-w-5xl mx-auto">
      {/* Header */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-2 shadow-xs">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold border border-blue-200 uppercase">
          <CreditCard className="w-3.5 h-3.5" />
          <span>Paperless In-Store Finance</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 font-serif-display">
          0% Easy EMI Finance Schemes
        </h1>
        <p className="text-xs text-slate-500 max-w-xl">
          Buy your favourite smartphone today and pay in easy monthly installments. Paperless sanction in just 15 minutes at Meru Mobile Shop showroom.
        </p>
      </div>

      {/* Interactive EMI Calculator */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Calculator className="w-5 h-5 text-blue-600" />
            <span>Showroom EMI Calculator</span>
          </h2>
          <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full">
            0% Interest Schemes Available
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-slate-600 font-semibold">Device Price:</span>
                <span className="font-bold text-slate-900">{formatPrice(devicePrice)}</span>
              </div>
              <input
                type="range"
                min="8000"
                max="150000"
                step="1000"
                value={devicePrice}
                onChange={(e) => setDevicePrice(Number(e.target.value))}
                className="w-full accent-blue-600 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-slate-600 font-semibold">Down Payment (₹):</span>
                <span className="font-bold text-slate-900">{formatPrice(downPayment)}</span>
              </div>
              <input
                type="range"
                min="0"
                max={devicePrice * 0.7}
                step="500"
                value={downPayment}
                onChange={(e) => setDownPayment(Number(e.target.value))}
                className="w-full accent-blue-600 cursor-pointer"
              />
            </div>

            <div>
              <span className="text-xs font-semibold text-slate-600 block mb-2">Select Tenure (Months):</span>
              <div className="grid grid-cols-4 gap-2">
                {[3, 6, 8, 12].map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setTenure(m)}
                    className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                      tenure === m
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {m} Months
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Calculator Output Result Card */}
          <div className="p-6 bg-gradient-to-br from-blue-900 to-indigo-950 text-white rounded-3xl space-y-4 shadow-lg">
            <span className="text-[11px] text-blue-200 font-bold uppercase tracking-wider block">
              Estimated Monthly Installment
            </span>
            <div className="text-3xl sm:text-4xl font-black">
              {formatPrice(estimatedEmi)}
              <span className="text-xs font-normal text-blue-200"> / month</span>
            </div>
            <p className="text-xs text-blue-100 leading-relaxed">
              For a loan amount of <strong>{formatPrice(loanAmount)}</strong> over <strong>{tenure} months</strong> with 0% No Cost EMI on select Samsung, Vivo, and Oppo models.
            </p>

            <button
              onClick={onOpenEnquiry}
              className="w-full py-3 bg-white hover:bg-blue-50 text-blue-900 rounded-xl text-xs font-bold transition-all shadow-md active:scale-95"
            >
              Consult In-Store Finance Desk
            </button>
          </div>
        </div>
      </div>

      {/* Authorized Finance Partners Cards */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-slate-900 font-serif-display">
          Authorized Showroom Finance Partners
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {providers.map((p) => (
            <div
              key={p.id}
              className="p-5 bg-white rounded-3xl border border-slate-200 hover:shadow-md transition-shadow flex flex-col justify-between space-y-3"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-slate-900">{p.name}</h3>
                  <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Active Desk
                  </span>
                </div>
                <p className="text-xs text-blue-600 font-semibold">{p.tagline}</p>
                <div className="text-xs text-slate-600 space-y-1 pt-1">
                  <div>Interest: <strong className="text-slate-900">{p.interest_rate_from}</strong></div>
                  <div>Tenure: <strong className="text-slate-900">{p.tenure_options}</strong></div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 space-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase">Documents Required:</span>
                <ul className="text-[11px] text-slate-600 space-y-0.5">
                  {p.documents_required?.slice(0, 3).map((doc, idx) => (
                    <li key={idx} className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3 h-3 text-blue-600 shrink-0" />
                      <span>{doc}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button
                onClick={onOpenEnquiry}
                className="w-full py-2 bg-slate-100 hover:bg-blue-600 hover:text-white text-slate-800 rounded-xl text-xs font-bold transition-colors"
              >
                {p.cta_text || 'Enquire at Showroom'}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Regulatory Notice (As strictly required in prompt) */}
      <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-3 text-xs text-amber-900">
        <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Important Notice:</span> Final eligibility, tenure approval, down payment, and interest subvention are subject strictly to the finance provider's credit bureau rules and underwriting criteria. Meru Mobile Shop facilitates direct authorized paperless applications at our Tyoda Road showroom.
        </div>
      </div>
    </div>
  );
};
