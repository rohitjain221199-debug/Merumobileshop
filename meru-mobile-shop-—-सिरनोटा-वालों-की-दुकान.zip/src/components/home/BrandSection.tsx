import React from 'react';
import { ChevronRight, ShieldCheck } from 'lucide-react';
import { Brand, Product } from '../../types/database';

interface BrandSectionProps {
  brands: Brand[];
  products: Product[];
  onSelectBrand: (brandSlug: string) => void;
}

export const BrandSection: React.FC<BrandSectionProps> = ({
  brands,
  products,
  onSelectBrand,
}) => {
  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-serif-display">
              Shop by Brand
            </h2>
            <span className="text-[11px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
              Authorized Partner
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Original warranty-backed handsets from top global smartphone makers
          </p>
        </div>

        <button
          onClick={() => onSelectBrand('all')}
          className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
        >
          <span>View All</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
        {brands.map((brand) => {
          const count = products.filter((p) => p.brand_id === brand.id && p.is_active).length;
          return (
            <div
              key={brand.id}
              onClick={() => onSelectBrand(brand.slug)}
              className="p-4 bg-white rounded-2xl border border-slate-200 hover:border-blue-400 hover:shadow-md cursor-pointer transition-all duration-200 flex flex-col items-center justify-center text-center space-y-2 group"
            >
              <div className="w-14 h-14 rounded-2xl bg-slate-50 p-2 flex items-center justify-center border border-slate-100 group-hover:scale-105 transition-transform overflow-hidden">
                <img
                  src={brand.logo_url}
                  alt={brand.name}
                  className="w-full h-full object-cover rounded-xl"
                  loading="lazy"
                />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  {brand.name}
                </h4>
                <p className="text-[11px] text-slate-400">
                  {count > 0 ? `${count} Models Available` : 'Authorized Stock'}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
