import React from 'react';
import { Smartphone, Headphones, Volume2, Watch, BatteryCharging, Zap, ShieldCheck, ChevronRight } from 'lucide-react';
import { Category } from '../../types/database';

interface CategorySectionProps {
  categories: Category[];
  onSelectCategory: (categorySlug: string) => void;
}

export const CategorySection: React.FC<CategorySectionProps> = ({
  categories,
  onSelectCategory,
}) => {
  const customCards = [
    {
      title: '5G Smartphones',
      desc: 'Next-gen speed with Jio & Airtel 5G ready bands',
      icon: Smartphone,
      slug: '5g-phones',
      color: 'bg-blue-50 text-blue-600',
    },
    {
      title: 'Budget Smartphones',
      desc: 'Under ₹15,000 top value daily performers',
      icon: Smartphone,
      slug: 'budget-phones',
      color: 'bg-emerald-50 text-emerald-600',
    },
    {
      title: 'Earbuds & Audio',
      desc: 'boAt, Realme, OnePlus ANC true wireless earbuds',
      icon: Headphones,
      slug: 'earbuds-headphones',
      color: 'bg-purple-50 text-purple-600',
    },
    {
      title: 'Smart Watches',
      desc: 'Bluetooth calling, AMOLED displays & fitness suites',
      icon: Watch,
      slug: 'smart-watches',
      color: 'bg-cyan-50 text-cyan-600',
    },
    {
      title: 'GaN Chargers & Cables',
      desc: '65W fast adapters, SuperVOOC & heavy-duty cables',
      icon: Zap,
      slug: 'chargers-cables',
      color: 'bg-amber-50 text-amber-600',
    },
    {
      title: 'Laser Tempered Glass',
      desc: 'In-store UV cutting & military drop cases in Basoda',
      icon: ShieldCheck,
      slug: 'covers-glass',
      color: 'bg-rose-50 text-rose-600',
    },
  ];

  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-serif-display">
            Browse by Category
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Everything you need for your mobile lifestyle under one trusted roof
          </p>
        </div>

        <button
          onClick={() => onSelectCategory('all')}
          className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
        >
          <span>All Categories</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {customCards.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.title}
              onClick={() => onSelectCategory(item.slug)}
              className="p-4 bg-white rounded-2xl border border-slate-200 hover:border-blue-400 hover:shadow-md cursor-pointer transition-all duration-200 flex flex-col justify-between group space-y-3"
            >
              <div className={`w-11 h-11 rounded-xl ${item.color} flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform`}>
                <Icon className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  {item.title}
                </h4>
                <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">
                  {item.desc}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
