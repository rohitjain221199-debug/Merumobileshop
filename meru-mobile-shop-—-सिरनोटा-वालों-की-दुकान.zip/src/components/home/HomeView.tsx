import React from 'react';
import { Smartphone, Gift, CreditCard, Star, ChevronRight, MapPin, Sparkles, Phone, ShieldCheck } from 'lucide-react';
import {
  Product,
  Brand,
  Category,
  Banner,
  SiteSettings,
  FinanceProvider,
  Review,
} from '../../types/database';
import { HeroBanner } from './HeroBanner';
import { TrustFeatures } from './TrustFeatures';
import { BrandSection } from './BrandSection';
import { CategorySection } from './CategorySection';
import { ProductCard } from '../products/ProductCard';
import { formatPrice } from '../../utils/formatters';

interface HomeViewProps {
  settings: SiteSettings;
  banners: Banner[];
  brands: Brand[];
  categories: Category[];
  products: Product[];
  financeProviders: FinanceProvider[];
  reviews: Review[];
  onNavigate: (route: string) => void;
  onOpenProduct: (product: Product) => void;
  onAddToCart: (product: Product, variantId?: string) => void;
  onToggleWishlist: (product: Product) => void;
  wishlistIds: Set<string>;
}

export const HomeView: React.FC<HomeViewProps> = ({
  settings,
  banners,
  brands,
  categories,
  products,
  financeProviders,
  reviews,
  onNavigate,
  onOpenProduct,
  onAddToCart,
  onToggleWishlist,
  wishlistIds,
}) => {
  const featuredSmartphones = products.filter(
    (p) => p.category_id === 'cat-smartphones' && p.is_active
  ).slice(0, 4);

  const trendingAccessories = products.filter(
    (p) => p.category_id !== 'cat-smartphones' && p.is_active
  ).slice(0, 4);

  return (
    <div className="space-y-10 sm:space-y-12 animate-page-enter">
      {/* 1. Hero Banner */}
      <HeroBanner
        banners={banners}
        settings={settings}
        onNavigate={onNavigate}
      />

      {/* 2. Trust Assurance Badges */}
      <TrustFeatures />

      {/* 3. Shop by Brand */}
      <BrandSection
        brands={brands}
        products={products}
        onSelectBrand={(brandSlug) => onNavigate(`brand-${brandSlug}`)}
      />

      {/* 4. Browse by Category */}
      <CategorySection
        categories={categories}
        onSelectCategory={(slug) => onNavigate(`category-${slug}`)}
      />

      {/* 5. Featured Smartphones Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-serif-display">
                Featured Smartphones
              </h2>
              <span className="text-[10px] bg-amber-50 text-amber-700 font-bold px-2 py-0.5 rounded border border-amber-200">
                Top Picks
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Best camera, 5G performance, and high battery handsets in Ganj Basoda
            </p>
          </div>

          <button
            onClick={() => onNavigate('mobiles')}
            className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
          >
            <span>View All Mobiles</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {featuredSmartphones.map((prod) => (
            <ProductCard
              key={prod.id}
              product={prod}
              onOpenProduct={onOpenProduct}
              onAddToCart={onAddToCart}
              onToggleWishlist={onToggleWishlist}
              isInWishlist={wishlistIds.has(prod.id)}
            />
          ))}
        </div>
      </section>

      {/* 6. Festive Lucky Draw Teaser Card */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 p-6 sm:p-8 text-slate-950 shadow-xl shadow-amber-500/10 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center md:text-left">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950 text-amber-300 text-xs font-bold uppercase tracking-wider">
            <Gift className="w-3.5 h-3.5" />
            <span>Meru Festive Bumper Scheme</span>
          </div>
          <h3 className="text-2xl sm:text-3xl font-black font-serif-display tracking-tight text-slate-950">
            Buy Any Smartphone & Win Assured Gifts!
          </h3>
          <p className="text-xs sm:text-sm text-slate-900 max-w-xl font-medium">
            Every customer gets a lucky draw ticket to win VIP Travel Trolley Bags, Induction Cooktops, Noise AMOLED Calling Watches, boAt Earbuds, and Power Banks!
          </p>
        </div>

        <button
          onClick={() => onNavigate('lucky-draw')}
          className="px-6 py-3.5 bg-slate-950 hover:bg-slate-900 text-white rounded-2xl font-black text-xs sm:text-sm shadow-xl transition-all active:scale-95 shrink-0 flex items-center gap-2"
        >
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>TRY LUCKY DRAW TICKET</span>
        </button>
      </div>

      {/* 7. Trending Audio & Genuine Accessories */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-serif-display">
              Trending Genuine Accessories
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              100% original boAt earphones, Noise smartwatches, and 65W GaN chargers
            </p>
          </div>

          <button
            onClick={() => onNavigate('accessories')}
            className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
          >
            <span>All Accessories</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {trendingAccessories.map((prod) => (
            <ProductCard
              key={prod.id}
              product={prod}
              onOpenProduct={onOpenProduct}
              onAddToCart={onAddToCart}
              onToggleWishlist={onToggleWishlist}
              isInWishlist={wishlistIds.has(prod.id)}
            />
          ))}
        </div>
      </section>

      {/* 8. 0% EMI Finance Partners Strip */}
      <div className="p-6 sm:p-8 bg-white rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-blue-600" />
              <h3 className="text-lg sm:text-xl font-bold text-slate-900 font-serif-display">
                0% Easy Finance & Instant In-Store EMI
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Get paperless approval in 15 minutes with Aadhaar Card, PAN Card & Bank Details
            </p>
          </div>

          <button
            onClick={() => onNavigate('finance')}
            className="px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl text-xs font-bold transition-colors self-start sm:self-auto"
          >
            Check EMI Calculator →
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5 pt-2">
          {financeProviders.map((fp) => (
            <div
              key={fp.id}
              className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-center space-y-1"
            >
              <div className="font-bold text-xs text-slate-900">{fp.name}</div>
              <div className="text-[10px] text-emerald-600 font-semibold">{fp.interest_rate_from}</div>
            </div>
          ))}
        </div>

        <p className="text-[10px] text-slate-400 text-center sm:text-left">
          * Final eligibility and approval are subject to the finance provider's rules.
        </p>
      </div>

      {/* 9. Verified Customer Reviews Strip */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-serif-display">
              What Customers Say About सिरनोटा वालों की दुकान
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Real reviews from verified residents of Ganj Basoda and Vidisha district
            </p>
          </div>

          <button
            onClick={() => onNavigate('reviews')}
            className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
          >
            <span>View All Reviews</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {reviews.slice(0, 3).map((rev) => (
            <div
              key={rev.id}
              className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2"
            >
              <div className="flex items-center justify-between">
                <div className="font-bold text-xs text-slate-900">{rev.title}</div>
                <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded text-amber-700 text-xs font-bold">
                  <span>{rev.rating}</span>
                  <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                </div>
              </div>

              <p className="text-xs text-slate-600 leading-relaxed italic">
                "{rev.comment}"
              </p>

              <div className="pt-1 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-100">
                <span className="font-semibold text-slate-700">{rev.customer_name}</span>
                <span className="text-emerald-600 font-medium">Verified Buyer</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 10. Showroom Visit Banner */}
      <div className="p-6 sm:p-8 bg-slate-900 text-white rounded-3xl border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-2">
            <MapPin className="w-5 h-5 text-blue-400" />
            <span className="text-sm font-bold text-amber-400 font-hindi">
              सिरनोटा वालों की दुकान — गंज बासोदा
            </span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold font-serif-display">
            Visit Our Showroom on Tyoda Road
          </h3>
          <p className="text-xs text-slate-400 max-w-xl">
            Near Pawan Auto Mobile / Old Bus Stand, Ganj Basoda. Open 7 days a week from 9:30 AM to 9:30 PM with live demo handsets, free phone data transfer, and instant EMI desk.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onNavigate('contact')}
            className="px-5 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs transition-colors"
          >
            Showroom Directions
          </button>
          <a
            href={`tel:${settings.phone}`}
            className="px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl text-xs transition-colors"
          >
            Call {settings.phone}
          </a>
        </div>
      </div>
    </div>
  );
};
