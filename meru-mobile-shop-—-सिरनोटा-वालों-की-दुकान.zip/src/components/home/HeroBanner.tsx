import React from 'react';
import { Smartphone, Tag, ArrowRight, ShieldCheck, Zap, Sparkles } from 'lucide-react';
import { Banner, SiteSettings } from '../../types/database';

interface HeroBannerProps {
  banners: Banner[];
  settings: SiteSettings;
  onNavigate: (route: string) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  banners,
  settings,
  onNavigate,
}) => {
  const activeBanner = banners.find((b) => b.is_active) || banners[0];

  return (
    <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-950 text-white shadow-xl shadow-blue-900/10 border border-blue-700/30">
      {/* Background Subtle Overlay Pattern */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(59,130,246,0.3),transparent_60%)] pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-12 sm:py-16 md:py-20 lg:py-24 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left Text Column */}
        <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
          {/* Top Tagline Pill */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-semibold text-blue-100">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span className="font-hindi text-amber-300 font-bold">
              ★ {settings.brand_tagline}
            </span>
            <span className="text-white/40">•</span>
            <span>Ganj Basoda Showroom</span>
          </div>

          <div className="space-y-2">
            <h1 className="text-3xl sm:text-5xl md:text-6xl font-black tracking-tight text-white font-serif-display leading-tight">
              {settings.shop_name}
            </h1>
            <h2 className="text-xl sm:text-2xl md:text-3xl font-bold font-hindi text-amber-300">
              सिरनोटा वालों की दुकान
            </h2>
          </div>

          <p className="text-sm sm:text-base text-blue-100 max-w-xl mx-auto lg:mx-0 leading-relaxed font-normal">
            Latest Smartphones • 100% Genuine Sealed Pack • 15-Minute 0% Easy EMI Finance • Best After-Sale Service in Vidisha District
          </p>

          {/* Action Buttons */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3">
            <button
              onClick={() => onNavigate('mobiles')}
              className="w-full sm:w-auto px-7 py-3.5 bg-white hover:bg-blue-50 text-blue-900 font-black text-xs sm:text-sm rounded-xl shadow-lg transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              <Smartphone className="w-4 h-4 text-blue-600" />
              <span>SHOP MOBILES</span>
              <ArrowRight className="w-4 h-4 text-blue-600" />
            </button>

            <button
              onClick={() => onNavigate('offers')}
              className="w-full sm:w-auto px-7 py-3.5 bg-blue-700/60 hover:bg-blue-600 text-white font-bold text-xs sm:text-sm rounded-xl border border-blue-400/40 transition-all flex items-center justify-center gap-2"
            >
              <Tag className="w-4 h-4 text-amber-300" />
              <span>TODAY'S OFFERS</span>
            </button>
          </div>

          {/* Micro assurances */}
          <div className="pt-4 flex items-center justify-center lg:justify-start gap-4 text-[11px] text-blue-200">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" /> Official Warranty
            </span>
            <span className="flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-300" /> 0% Bajaj / HDB EMI
            </span>
            <span className="flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-pink-300" /> Festive Lucky Draw
            </span>
          </div>
        </div>

        {/* Right Feature Device / Banner Display */}
        <div className="lg:col-span-5 flex justify-center">
          <div className="relative w-full max-w-sm rounded-2xl bg-white/10 backdrop-blur-md p-3 border border-white/20 shadow-2xl">
            <div className="aspect-[4/3] rounded-xl overflow-hidden bg-slate-900 flex items-center justify-center relative">
              <img
                src={activeBanner?.image_url || 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=800&auto=format&fit=crop'}
                alt="Meru Showroom Showcase"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
              <div className="absolute bottom-3 left-3 right-3 text-left">
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-blue-600 text-white">
                  Trending Now
                </span>
                <h4 className="text-sm font-bold text-white mt-1 line-clamp-1">
                  {activeBanner?.title || 'Vivo V30 Pro & Galaxy S24 5G'}
                </h4>
                <p className="text-[11px] text-slate-300 line-clamp-1">
                  {activeBanner?.subtitle || 'Zero down-payment schemes available at Tyoda Road showroom'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
