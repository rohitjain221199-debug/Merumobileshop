import React from 'react';
import { ShieldCheck, Zap, Gift, HeartHandshake } from 'lucide-react';

export const TrustFeatures: React.FC = () => {
  const features = [
    {
      icon: ShieldCheck,
      title: '100% Genuine Brand Bill',
      desc: 'Sealed pack units with official company warranty & GST invoice.',
      color: 'text-blue-600 bg-blue-50',
    },
    {
      icon: Zap,
      title: '15-Minute 0% EMI Approval',
      desc: 'Paperless in-store verification with Bajaj, HDB & IDFC First Bank.',
      color: 'text-amber-600 bg-amber-50',
    },
    {
      icon: Gift,
      title: 'Assured Festive Lucky Draw',
      desc: 'Win Trolley Bag, Induction, Smart Watch or Earbuds with every phone.',
      color: 'text-pink-600 bg-pink-50',
    },
    {
      icon: HeartHandshake,
      title: 'Local Trust & Care',
      desc: 'Free phone setup, data transfer & lifetime friendly support on Tyoda Road.',
      color: 'text-emerald-600 bg-emerald-50',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
      {features.map((f, i) => {
        const Icon = f.icon;
        return (
          <div
            key={i}
            className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-start gap-3.5 hover:shadow-md transition-shadow"
          >
            <div className={`p-2.5 rounded-xl ${f.color} shrink-0`}>
              <Icon className="w-5 h-5" />
            </div>
            <div className="space-y-0.5">
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                {f.title}
              </h4>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                {f.desc}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
};
