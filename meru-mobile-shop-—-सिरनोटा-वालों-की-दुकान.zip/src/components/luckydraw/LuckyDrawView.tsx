import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Gift, Sparkles, Phone, User, MessageCircle, Share2, Check, AlertCircle } from 'lucide-react';
import { StoreService } from '../../services/storeService';
import { LuckyDrawPrize, LuckyDrawWinner, SiteSettings } from '../../types/database';
import { createWhatsAppUrl } from '../../utils/formatters';

interface LuckyDrawViewProps {
  settings: SiteSettings;
  onNavigate: (route: string) => void;
}

export const LuckyDrawView: React.FC<LuckyDrawViewProps> = ({ settings, onNavigate }) => {
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [isSpinning, setIsSpinning] = useState(false);
  const [result, setResult] = useState<{
    won: boolean;
    prize?: LuckyDrawPrize;
    winner?: LuckyDrawWinner;
  } | null>(null);

  const prizes = StoreService.getLuckyPrizes().filter((p) => p.is_active);
  const recentWinners = StoreService.getLuckyWinners().slice(0, 6);

  const handlePlayDraw = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim()) return;

    setIsSpinning(true);
    setTimeout(() => {
      const outcome = StoreService.playLuckyDraw(customerName, customerPhone);
      setResult(outcome);
      setIsSpinning(false);

      if (outcome.won) {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#2563eb', '#f59e0b', '#10b981', '#ec4899'],
        });
      }
    }, 1200);
  };

  const handleClaimViaWhatsApp = () => {
    if (!result?.winner || !result?.prize) return;
    const msg = `Hello Maneesh Bhaiya, maine online Meru Lucky Draw me "${result.prize.name}" jeeta hai. Meri Ticket No: ${result.winner.ticket_number} hai. Name: ${customerName}, Mobile: ${customerPhone}.`;
    const url = createWhatsAppUrl(settings.whatsapp_number, msg);
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-6 animate-page-enter max-w-5xl mx-auto">
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-2 shadow-xs">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-800 text-xs font-bold border border-amber-200 uppercase">
          <Gift className="w-3.5 h-3.5" />
          <span>Festive Scheme 2025-2026</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 font-serif-display">
          Meru Festive Bumper Lucky Draw
        </h1>
        <p className="text-xs text-slate-500 max-w-xl">
          Purchase any smartphone at Meru Mobile Shop (सिरनोटा वालों की दुकान, Ganj Basoda) and get an assured lucky coupon to win premium electronics!
        </p>
      </div>

      {result?.won && result.prize && result.winner ? (
        /* Winner Congratulations Screen */
        <div className="p-8 bg-gradient-to-b from-amber-50 via-white to-white border-2 border-amber-300 rounded-3xl text-center space-y-4 shadow-sm animate-in zoom-in-95">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 text-amber-900 border border-amber-300 text-xs font-extrabold uppercase">
            <Sparkles className="w-4 h-4 text-amber-600" />
            <span>CONGRATULATIONS!</span>
          </div>

          <div className="space-y-1">
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
              {customerName}, You Won!
            </h2>
            <p className="text-base sm:text-lg font-bold text-amber-700">
              {result.prize.name}
            </p>
          </div>

          <div className="w-32 h-32 mx-auto rounded-2xl bg-white border border-amber-200 p-3 flex items-center justify-center overflow-hidden shadow-sm">
            <img
              src={result.prize.image_url}
              alt={result.prize.name}
              className="max-h-full max-w-full object-contain"
            />
          </div>

          <div className="bg-slate-50 max-w-xs mx-auto p-3.5 rounded-2xl border border-slate-200 space-y-1">
            <div className="text-[11px] text-slate-500">Official Claim Ticket:</div>
            <div className="font-mono text-base font-black text-blue-700 tracking-wider">
              {result.winner.ticket_number}
            </div>
          </div>

          <p className="text-xs text-slate-600 max-w-md mx-auto">
            Please show this ticket number at <span className="font-bold text-slate-900">Meru Mobile Shop, Tyoda Road, Ganj Basoda</span> during your mobile purchase or pickup to collect your prize.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={handleClaimViaWhatsApp}
              className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Claim on WhatsApp</span>
            </button>

            <button
              onClick={() => onNavigate('mobiles')}
              className="px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold"
            >
              Shop Smartphones →
            </button>
          </div>

          <div className="text-[10px] text-slate-400">
            * WhatsApp notifications are sent upon manual verification or when connected to Meta Business Cloud API.
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Draw Entry Form */}
          <div className="md:col-span-6 bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-xs">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Enter Details to Draw Your Festive Ticket</span>
            </h2>
            <p className="text-xs text-slate-500">
              Customers planning to buy or reserve a phone can check their lucky prize ticket.
            </p>

            <form onSubmit={handlePlayDraw} className="space-y-3.5 pt-1">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Customer Name *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Rahul Sharma"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  WhatsApp Mobile Number *
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="10-digit mobile number"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSpinning}
                className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 disabled:opacity-50 text-slate-950 font-black text-xs rounded-xl flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
              >
                <Gift className="w-4 h-4" />
                <span>{isSpinning ? 'Generating Lucky Draw Ticket...' : 'SPIN FOR FESTIVE GIFT'}</span>
              </button>
            </form>

            <div className="pt-2 text-[10px] text-slate-400 text-center">
              * Gifts are honored in-person at our Tyoda Road showroom with any phone purchase.
            </div>
          </div>

          {/* Available Prize Pool & Recent Winners */}
          <div className="md:col-span-6 space-y-4">
            <div className="bg-white rounded-3xl border border-slate-200 p-5 space-y-3 shadow-xs">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Prizes in Stock Pool
              </h3>

              <div className="grid grid-cols-3 gap-2.5">
                {prizes.slice(0, 6).map((prz) => (
                  <div
                    key={prz.id}
                    className="p-2.5 bg-slate-50 rounded-2xl border border-slate-100 text-center space-y-1"
                  >
                    <div className="w-10 h-10 mx-auto rounded-lg bg-white p-1 flex items-center justify-center">
                      <img src={prz.image_url} alt="" className="max-h-full max-w-full object-contain" />
                    </div>
                    <div className="text-[10px] font-bold text-slate-900 line-clamp-1">
                      {prz.name}
                    </div>
                    <div className="text-[9px] text-emerald-600 font-semibold">
                      {prz.remaining_quantity} Left
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Winners */}
            <div className="bg-white rounded-3xl border border-slate-200 p-5 space-y-2.5 shadow-xs">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Recent Ganj Basoda Winners
              </h3>
              <div className="space-y-1.5">
                {recentWinners.map((win) => (
                  <div
                    key={win.id}
                    className="p-2 bg-slate-50 rounded-xl flex items-center justify-between text-xs"
                  >
                    <span className="font-semibold text-slate-800">{win.customer_name}</span>
                    <span className="text-amber-700 font-bold text-[11px]">{win.prize_name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
