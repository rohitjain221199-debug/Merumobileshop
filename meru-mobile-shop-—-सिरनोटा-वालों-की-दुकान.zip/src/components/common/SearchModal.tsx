import React, { useState, useMemo } from 'react';
import { Search, X, Filter, Smartphone, Check, ArrowUpDown, SlidersHorizontal } from 'lucide-react';
import { Product, Brand, Category } from '../../types/database';
import { formatPrice } from '../../utils/formatters';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  brands: Brand[];
  categories: Category[];
  onSelectProduct: (product: Product) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  products,
  brands,
  categories,
  onSelectProduct,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBrand, setSelectedBrand] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [only5G, setOnly5G] = useState(false);
  const [onlyInStock, setOnlyInStock] = useState(false);
  const [sortBy, setSortBy] = useState<'featured' | 'price_low' | 'price_high' | 'newest'>('featured');

  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => {
        if (!p.is_active) return false;

        const term = searchTerm.toLowerCase().trim();
        const matchesTerm =
          !term ||
          p.name.toLowerCase().includes(term) ||
          p.model.toLowerCase().includes(term) ||
          (p.brand_name && p.brand_name.toLowerCase().includes(term)) ||
          p.description.toLowerCase().includes(term);

        const matchesBrand = selectedBrand === 'all' || p.brand_id === selectedBrand;
        const matchesCategory = selectedCategory === 'all' || p.category_id === selectedCategory;
        const matches5G = !only5G || p.is_5g;
        const matchesStock = !onlyInStock || p.stock_status !== 'out_of_stock';

        return matchesTerm && matchesBrand && matchesCategory && matches5G && matchesStock;
      })
      .sort((a, b) => {
        if (sortBy === 'price_low') return a.selling_price - b.selling_price;
        if (sortBy === 'price_high') return b.selling_price - a.selling_price;
        if (sortBy === 'newest') return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
        return (b.is_bestseller ? 1 : 0) - (a.is_bestseller ? 1 : 0);
      });
  }, [products, searchTerm, selectedBrand, selectedCategory, only5G, onlyInStock, sortBy]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden my-6 flex flex-col max-h-[88vh]">
        {/* Top Search Input Bar */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-blue-400 shrink-0" />
          <input
            type="text"
            autoFocus
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search smartphones, 5G models, audio, chargers in Ganj Basoda..."
            className="flex-1 bg-transparent text-sm sm:text-base text-white placeholder-slate-500 focus:outline-none"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="text-slate-500 hover:text-white text-xs px-2"
            >
              Clear
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filters Bar */}
        <div className="p-3 bg-slate-900/90 border-b border-slate-800 text-xs flex flex-wrap items-center gap-2">
          {/* Brand select */}
          <select
            value={selectedBrand}
            onChange={(e) => setSelectedBrand(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white focus:outline-none"
          >
            <option value="all">All Brands</option>
            {brands.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>

          {/* Category select */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white focus:outline-none"
          >
            <option value="all">All Categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          {/* Sort By */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white focus:outline-none"
          >
            <option value="featured">Featured / Best Sellers</option>
            <option value="price_low">Price: Low to High</option>
            <option value="price_high">Price: High to Low</option>
            <option value="newest">New Arrivals</option>
          </select>

          {/* 5G Checkbox */}
          <button
            type="button"
            onClick={() => setOnly5G(!only5G)}
            className={`px-2.5 py-1.5 rounded-lg border flex items-center gap-1.5 transition-colors ${
              only5G
                ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                : 'bg-slate-950 border-slate-750 text-slate-400'
            }`}
          >
            <Check className={`w-3.5 h-3.5 ${only5G ? 'opacity-100' : 'opacity-0'}`} />
            5G Only
          </button>

          {/* In Stock Only */}
          <button
            type="button"
            onClick={() => setOnlyInStock(!onlyInStock)}
            className={`px-2.5 py-1.5 rounded-lg border flex items-center gap-1.5 transition-colors ${
              onlyInStock
                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold'
                : 'bg-slate-950 border-slate-750 text-slate-400'
            }`}
          >
            <Check className={`w-3.5 h-3.5 ${onlyInStock ? 'opacity-100' : 'opacity-0'}`} />
            In Stock Only
          </button>
        </div>

        {/* Results count & items list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span>Showing {filteredProducts.length} matching products</span>
            <span className="font-hindi text-amber-400">सिरनोटा वालों की दुकान</span>
          </div>

          {filteredProducts.length === 0 ? (
            <div className="py-16 text-center text-slate-400 space-y-2">
              <Smartphone className="w-12 h-12 mx-auto text-slate-600" />
              <p className="text-sm font-medium">No matching products found.</p>
              <p className="text-xs text-slate-500">
                Try searching with a broader keyword or resetting filters.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  onClick={() => {
                    onSelectProduct(product);
                    onClose();
                  }}
                  className="p-3 bg-slate-950 rounded-xl border border-slate-800 hover:border-blue-500/60 cursor-pointer transition-all flex flex-col justify-between group"
                >
                  <div className="space-y-2">
                    <div className="relative aspect-[4/3] bg-slate-900 rounded-lg overflow-hidden flex items-center justify-center p-2">
                      <img
                        src={product.primary_image}
                        alt={product.name}
                        className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform"
                      />
                      {product.is_5g && (
                        <span className="absolute top-2 left-2 bg-amber-500 text-slate-950 text-[10px] font-black px-1.5 py-0.5 rounded">
                          5G
                        </span>
                      )}
                    </div>
                    <div>
                      <span className="text-[10px] text-blue-400 font-semibold uppercase">
                        {product.brand_name}
                      </span>
                      <h4 className="text-xs font-bold text-white group-hover:text-blue-300 transition-colors line-clamp-1">
                        {product.name}
                      </h4>
                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                        {product.short_description}
                      </p>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-900 flex items-center justify-between">
                    <div>
                      <div className="font-extrabold text-sm text-white">
                        {formatPrice(product.selling_price)}
                      </div>
                      {product.mrp > product.selling_price && (
                        <div className="text-[10px] text-slate-500 line-through">
                          {formatPrice(product.mrp)}
                        </div>
                      )}
                    </div>
                    <span className="text-[11px] font-semibold text-blue-400 group-hover:translate-x-1 transition-transform">
                      View →
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
