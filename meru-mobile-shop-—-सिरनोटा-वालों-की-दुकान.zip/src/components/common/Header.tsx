import React, { useState } from 'react';
import {
  BookOpen,
  ShoppingBag,
  Heart,
  Search,
  MapPin,
  Phone,
  ShieldCheck,
  User,
  SlidersHorizontal,
  X,
  Compass,
} from 'lucide-react';
import { SiteSettings, BookPageConfig } from '../../types/database';
import { formatPrice } from '../../utils/formatters';

interface HeaderProps {
  settings: SiteSettings;
  bookPages: BookPageConfig[];
  currentPage: number;
  onPageSelect: (pageNumber: number) => void;
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenAdmin: () => void;
  onOpenTracking: () => void;
  onOpenSearch: () => void;
  isCoverView?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  bookPages,
  currentPage,
  onPageSelect,
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onOpenAdmin,
  onOpenTracking,
  onOpenSearch,
  isCoverView = false,
}) => {
  const [isTocOpen, setIsTocOpen] = useState(false);

  return (
    <>
      {/* Top Announcement Bar */}
      <div className="bg-gradient-to-r from-blue-950 via-blue-900 to-indigo-950 text-blue-100 text-xs py-1.5 px-3 border-b border-blue-800/40">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 overflow-hidden whitespace-nowrap">
            <span className="bg-amber-400 text-blue-950 font-bold px-1.5 py-0.5 rounded text-[10px] uppercase tracking-wider">
              Special
            </span>
            <span className="truncate text-xs font-medium">
              {settings.announcement_bar_text}
            </span>
          </div>

          <div className="hidden md:flex items-center gap-4 text-blue-200 shrink-0 text-xs">
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-blue-400" />
              Tyoda Road, Ganj Basoda
            </span>
            <a
              href={`tel:${settings.phone}`}
              className="flex items-center gap-1 hover:text-white transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              {settings.phone}
            </a>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 shadow-lg">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-3">
          {/* Brand Logo & Tagline */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onPageSelect(1)}
              className="flex items-center gap-2.5 text-left group"
              title="Return to Cover"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-900 p-0.5 shadow-md shadow-blue-900/40 flex items-center justify-center font-bold text-white text-lg">
                <span className="font-serif-display tracking-tighter">M</span>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-black text-sm sm:text-base tracking-wider text-white uppercase group-hover:text-blue-400 transition-colors">
                    {settings.shop_name}
                  </span>
                  <span className="hidden sm:inline-block bg-blue-900/70 text-blue-300 text-[10px] font-semibold px-1.5 py-0.5 rounded border border-blue-700/50">
                    Est. Basoda
                  </span>
                </div>
                <p className="text-[11px] sm:text-xs text-amber-400 font-hindi font-medium flex items-center gap-1">
                  <span>★</span> {settings.brand_tagline}
                </p>
              </div>
            </button>
          </div>

          {/* Center Navigation Shortcuts */}
          <div className="hidden lg:flex items-center gap-1 bg-slate-900/80 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setIsTocOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all font-medium"
            >
              <Compass className="w-4 h-4 text-blue-400" />
              Catalogue Index ({currentPage}/26)
            </button>
            <button
              onClick={() => onPageSelect(5)}
              className={`px-3 py-1.5 rounded-lg transition-all font-medium ${
                currentPage >= 5 && currentPage <= 9
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
              }`}
            >
              Smartphones
            </button>
            <button
              onClick={() => onPageSelect(10)}
              className={`px-3 py-1.5 rounded-lg transition-all font-medium ${
                currentPage >= 10 && currentPage <= 16
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
              }`}
            >
              Accessories
            </button>
            <button
              onClick={() => onPageSelect(17)}
              className={`px-3 py-1.5 rounded-lg transition-all font-medium ${
                currentPage === 17
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'text-amber-400 hover:text-amber-300 hover:bg-slate-800/80'
              }`}
            >
              🎁 Lucky Draw
            </button>
            <button
              onClick={() => onPageSelect(18)}
              className={`px-3 py-1.5 rounded-lg transition-all font-medium ${
                currentPage === 18 || currentPage === 19
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
              }`}
            >
              0% EMI Finance
            </button>
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Search */}
            <button
              onClick={onOpenSearch}
              className="p-2 sm:px-2.5 sm:py-2 text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-lg transition-colors flex items-center gap-1 text-xs"
              title="Search Phones & Accessories"
            >
              <Search className="w-4 h-4 text-slate-400" />
              <span className="hidden md:inline">Search</span>
            </button>

            {/* Catalogue Index Drawer button on Mobile/Tablet */}
            <button
              onClick={() => setIsTocOpen(true)}
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-lg transition-colors lg:hidden flex items-center gap-1 text-xs"
              title="Table of Contents"
            >
              <BookOpen className="w-4 h-4 text-blue-400" />
              <span className="text-[11px] font-semibold">{currentPage}/26</span>
            </button>

            {/* Wishlist */}
            <button
              onClick={onOpenWishlist}
              className="relative p-2 text-slate-300 hover:text-pink-400 hover:bg-slate-800/80 rounded-lg transition-colors"
              title="Wishlist"
            >
              <Heart className="w-4 h-4" />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-pink-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Cart Button */}
            <button
              onClick={onOpenCart}
              className="relative flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold shadow-md shadow-blue-900/30 transition-all active:scale-95"
              title="View Cart"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Bag</span>
              {cartCount > 0 ? (
                <span className="bg-white text-blue-900 font-extrabold text-[11px] px-1.5 py-0.2 rounded-full">
                  {cartCount}
                </span>
              ) : (
                <span className="text-[11px] opacity-80">0</span>
              )}
            </button>

            {/* Order Tracking */}
            <button
              onClick={onOpenTracking}
              className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-lg transition-colors border border-slate-800"
              title="Track Order"
            >
              <span>Track</span>
            </button>

            {/* Admin Portal Shortcut */}
            <button
              onClick={onOpenAdmin}
              className="flex items-center gap-1 p-2 sm:px-2.5 sm:py-1.5 text-xs text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition-colors border border-slate-800/60"
              title="Shop Admin Management"
            >
              <ShieldCheck className="w-4 h-4 text-amber-500" />
              <span className="hidden sm:inline font-medium">Admin</span>
            </button>
          </div>
        </div>
      </header>

      {/* Table of Contents Modal / Sidebar Drawer */}
      {isTocOpen && (
        <div className="fixed inset-0 z-50 flex bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md bg-slate-900 h-full border-r border-slate-800 p-5 flex flex-col overflow-hidden shadow-2xl">
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div>
                <h3 className="font-bold text-white text-base flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-blue-400" />
                  Catalogue Table of Contents
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Browse all 26 chapters of Meru Mobile Shop
                </p>
              </div>
              <button
                onClick={() => setIsTocOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Pages List */}
            <div className="flex-1 overflow-y-auto py-3 space-y-1 pr-1">
              {bookPages.map((page) => {
                const isActive = page.page_number === currentPage;
                return (
                  <button
                    key={page.id}
                    onClick={() => {
                      onPageSelect(page.page_number);
                      setIsTocOpen(false);
                    }}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left text-xs transition-all ${
                      isActive
                        ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-900/40'
                        : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span
                        className={`w-6 h-6 rounded-lg flex items-center justify-center text-[11px] font-bold ${
                          isActive
                            ? 'bg-white text-blue-900'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {page.page_number}
                      </span>
                      <div>
                        <div className="font-medium text-xs truncate max-w-[240px]">
                          {page.title}
                        </div>
                        <div
                          className={`text-[10px] truncate max-w-[220px] ${
                            isActive ? 'text-blue-100' : 'text-slate-500'
                          }`}
                        >
                          {page.subtitle}
                        </div>
                      </div>
                    </div>
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded ${
                        isActive
                          ? 'bg-blue-700 text-white'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {page.chapter_name}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Quick Admin & Store Info Footer */}
            <div className="pt-3 border-t border-slate-800 text-xs flex items-center justify-between text-slate-400">
              <span className="font-hindi text-amber-400">सिरनोटा वालों की दुकान</span>
              <button
                onClick={() => {
                  setIsTocOpen(false);
                  onOpenAdmin();
                }}
                className="text-blue-400 hover:underline flex items-center gap-1 font-medium"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                Admin Dashboard
              </button>
            </div>
          </div>

          <div
            className="flex-1 cursor-pointer"
            onClick={() => setIsTocOpen(false)}
          />
        </div>
      )}
    </>
  );
};
