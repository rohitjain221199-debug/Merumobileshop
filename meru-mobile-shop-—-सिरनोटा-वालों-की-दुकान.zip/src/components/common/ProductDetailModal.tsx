import React, { useState } from 'react';
import {
  X,
  Star,
  Check,
  Shield,
  Truck,
  CreditCard,
  Heart,
  ShoppingBag,
  MessageCircle,
  Zap,
  Info,
  Layers,
  ChevronRight,
} from 'lucide-react';
import { Product, ProductVariant } from '../../types/database';
import { formatPrice, createWhatsAppUrl } from '../../utils/formatters';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, variantId?: string) => void;
  onBuyNow: (product: Product, variantId?: string) => void;
  onToggleWishlist: (product: Product) => void;
  isInWishlist: boolean;
  whatsappNumber: string;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onBuyNow,
  onToggleWishlist,
  isInWishlist,
  whatsappNumber,
}) => {
  if (!product) return null;

  const defaultVariant = product.variants?.[0];
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | undefined>(defaultVariant);
  const [activeImage, setActiveImage] = useState<string>(product.primary_image);

  // Dynamic values based on variant selection
  const currentSellingPrice = selectedVariant ? selectedVariant.selling_price : product.selling_price;
  const currentMrp = selectedVariant ? selectedVariant.mrp : product.mrp;
  const currentStock = selectedVariant ? selectedVariant.stock_quantity : product.stock_quantity;
  const isOutOfStock = currentStock <= 0;

  const discountPercent =
    currentMrp > currentSellingPrice
      ? Math.round(((currentMrp - currentSellingPrice) / currentMrp) * 100)
      : product.discount_percent;

  const emiPerMonth = Math.round(currentSellingPrice / 6);

  const handleWhatsAppInquiry = () => {
    const variantDesc = selectedVariant
      ? ` (${selectedVariant.color_name}, ${selectedVariant.ram || ''} ${selectedVariant.storage || ''})`
      : '';
    const message = `Hello Meru Mobile Shop, mujhe ${product.name}${variantDesc} ke baare mein jankari chahiye. Kya yeh available hai?`;
    window.open(createWhatsAppUrl(whatsappNumber, message), '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header bar */}
        <div className="px-5 py-3.5 bg-slate-950/70 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-blue-900/60 text-blue-300 border border-blue-700/50">
              {product.brand_name || 'Brand Authorized'}
            </span>
            {product.is_5g && (
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                5G Dual VoLTE
              </span>
            )}
            <span className="text-xs text-slate-400 font-hindi">
              सिरनोटा वालों की दुकान
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left Column: Image Gallery */}
          <div className="space-y-4">
            <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center p-4">
              <img
                src={activeImage}
                alt={product.name}
                className="max-h-full max-w-full object-contain transition-all duration-300 hover:scale-105"
              />
              {discountPercent > 0 && (
                <div className="absolute top-3 left-3 bg-red-600 text-white text-xs font-black px-2.5 py-1 rounded-lg shadow-md">
                  {discountPercent}% OFF
                </div>
              )}
              {isOutOfStock && (
                <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center">
                  <span className="bg-red-500 text-white font-bold text-sm px-4 py-2 rounded-xl">
                    Out of Stock in Showroom
                  </span>
                </div>
              )}
            </div>

            {/* Thumbnails */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              <button
                onClick={() => setActiveImage(product.primary_image)}
                className={`w-14 h-14 rounded-xl border-2 p-1 bg-slate-950 shrink-0 overflow-hidden ${
                  activeImage === product.primary_image ? 'border-blue-500' : 'border-slate-800 opacity-60'
                }`}
              >
                <img src={product.primary_image} alt="main" className="w-full h-full object-contain" />
              </button>
              {product.images?.map((img) => (
                <button
                  key={img.id}
                  onClick={() => setActiveImage(img.image_url)}
                  className={`w-14 h-14 rounded-xl border-2 p-1 bg-slate-950 shrink-0 overflow-hidden ${
                    activeImage === img.image_url ? 'border-blue-500' : 'border-slate-800 opacity-60'
                  }`}
                >
                  <img src={img.image_url} alt="sub" className="w-full h-full object-contain" />
                </button>
              ))}
              {selectedVariant?.image_url && (
                <button
                  onClick={() => setActiveImage(selectedVariant.image_url!)}
                  className={`w-14 h-14 rounded-xl border-2 p-1 bg-slate-950 shrink-0 overflow-hidden ${
                    activeImage === selectedVariant.image_url ? 'border-blue-500' : 'border-slate-800 opacity-60'
                  }`}
                >
                  <img src={selectedVariant.image_url} alt="variant" className="w-full h-full object-contain" />
                </button>
              )}
            </div>

            {/* EMI Banner */}
            <div className="p-3.5 bg-blue-950/40 border border-blue-800/40 rounded-xl flex items-center gap-3 text-xs text-blue-200">
              <div className="w-8 h-8 rounded-lg bg-blue-600/30 text-blue-400 flex items-center justify-center shrink-0">
                <CreditCard className="w-4 h-4" />
              </div>
              <div>
                <p className="font-semibold text-white">
                  0% No-Cost EMI starting from {formatPrice(emiPerMonth)}/month
                </p>
                <p className="text-[11px] text-blue-300">
                  Instant paperless sanction with Bajaj Finserv, HDB & IDFC First Bank in store.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Product Details & Variant Selection */}
          <div className="space-y-4 text-slate-200">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-white leading-tight">
                {product.name}
              </h2>
              <p className="text-xs text-slate-400 mt-1">{product.short_description}</p>

              {/* Rating */}
              <div className="flex items-center gap-2 mt-2">
                <div className="flex items-center gap-1 bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded text-xs font-bold">
                  <span>4.9</span>
                  <Star className="w-3 h-3 fill-emerald-400" />
                </div>
                <span className="text-xs text-slate-400">Verified Ganj Basoda Buyers</span>
              </div>
            </div>

            {/* Pricing Section */}
            <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 flex items-baseline gap-3">
              <span className="text-2xl sm:text-3xl font-black text-white">
                {formatPrice(currentSellingPrice)}
              </span>
              {currentMrp > currentSellingPrice && (
                <span className="text-sm text-slate-500 line-through">
                  {formatPrice(currentMrp)}
                </span>
              )}
              {discountPercent > 0 && (
                <span className="text-xs font-bold text-emerald-400">
                  Save {formatPrice(currentMrp - currentSellingPrice)} ({discountPercent}% off)
                </span>
              )}
            </div>

            {/* Variants Selector */}
            {product.variants && product.variants.length > 0 && (
              <div className="space-y-2 pt-1">
                <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                  <span>Choose Color & Storage Variant:</span>
                  {selectedVariant && (
                    <span className="text-blue-400 font-normal">
                      SKU: {selectedVariant.sku}
                    </span>
                  )}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {product.variants.map((v) => {
                    const isSelected = selectedVariant?.id === v.id;
                    return (
                      <button
                        key={v.id}
                        type="button"
                        onClick={() => {
                          setSelectedVariant(v);
                          if (v.image_url) setActiveImage(v.image_url);
                        }}
                        className={`p-2.5 rounded-xl border text-left text-xs transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-blue-950/80 border-blue-500 text-white ring-1 ring-blue-500'
                            : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          {v.color_hex && (
                            <span
                              className="w-3.5 h-3.5 rounded-full border border-white/20 shrink-0"
                              style={{ backgroundColor: v.color_hex }}
                            />
                          )}
                          <div>
                            <div className="font-semibold text-white">{v.color_name}</div>
                            <div className="text-[11px] text-slate-400">
                              {v.ram ? `${v.ram} / ` : ''}{v.storage || ''}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-blue-300">{formatPrice(v.selling_price)}</div>
                          <div className="text-[10px] text-slate-500">
                            {v.stock_quantity > 0 ? `${v.stock_quantity} left` : 'Out of stock'}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Delivery & Warranty perks */}
            <div className="grid grid-cols-2 gap-2 py-2 text-xs">
              <div className="p-2.5 bg-slate-950/60 rounded-xl border border-slate-800/80 flex items-center gap-2">
                <Truck className="w-4 h-4 text-blue-400 shrink-0" />
                <div>
                  <div className="font-semibold text-white text-[11px]">Local Ganj Basoda Delivery</div>
                  <div className="text-[10px] text-slate-400">Free on orders above ₹999</div>
                </div>
              </div>
              <div className="p-2.5 bg-slate-950/60 rounded-xl border border-slate-800/80 flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <div className="font-semibold text-white text-[11px]">100% Genuine Brand Bill</div>
                  <div className="text-[10px] text-slate-400">{product.warranty}</div>
                </div>
              </div>
            </div>

            {/* Specifications Accordion / List */}
            {product.specifications && Object.keys(product.specifications).length > 0 && (
              <div className="space-y-1.5 pt-1">
                <h4 className="text-xs font-bold text-slate-300">Technical Highlights:</h4>
                <div className="bg-slate-950 rounded-xl p-3 border border-slate-800 text-xs space-y-1.5">
                  {Object.entries(product.specifications).map(([key, val]) => (
                    <div key={key} className="flex justify-between border-b border-slate-800/60 pb-1 last:border-0 last:pb-0">
                      <span className="text-slate-400">{key}:</span>
                      <span className="text-white font-medium text-right ml-2">{val}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-2 pt-2">
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  disabled={isOutOfStock}
                  onClick={() => {
                    onAddToCart(product, selectedVariant?.id);
                    onClose();
                  }}
                  className="py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-900/30 transition-all active:scale-95"
                >
                  <ShoppingBag className="w-4 h-4" />
                  {isOutOfStock ? 'Out of Stock' : 'Add to Bag'}
                </button>

                <button
                  type="button"
                  disabled={isOutOfStock}
                  onClick={() => {
                    onBuyNow(product, selectedVariant?.id);
                    onClose();
                  }}
                  className="py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 disabled:from-slate-800 disabled:to-slate-800 disabled:text-slate-500 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-950/40 transition-all active:scale-95"
                >
                  <Zap className="w-4 h-4" />
                  Buy Now (Reserve)
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onToggleWishlist(product)}
                  className={`flex-1 py-2.5 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                    isInWishlist
                      ? 'bg-pink-950/50 border-pink-700 text-pink-400'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <Heart className={`w-3.5 h-3.5 ${isInWishlist ? 'fill-pink-400' : ''}`} />
                  {isInWishlist ? 'In Wishlist' : 'Add to Wishlist'}
                </button>

                <button
                  type="button"
                  onClick={handleWhatsAppInquiry}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-950/60 border border-emerald-700/60 hover:bg-emerald-900/60 text-emerald-400 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  Ask on WhatsApp
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
