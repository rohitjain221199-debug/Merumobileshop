import React, { useState } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';
import { createWhatsAppUrl } from '../../utils/formatters';

interface WhatsAppButtonProps {
  whatsappNumber: string;
  shopName: string;
  defaultMessage?: string;
  productName?: string;
}

export const WhatsAppButton: React.FC<WhatsAppButtonProps> = ({
  whatsappNumber,
  shopName,
  defaultMessage = 'Hello Meru Mobile Shop, mujhe mobile aur offers ke baare mein information chahiye.',
  productName,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [customMsg, setCustomMsg] = useState(
    productName
      ? `Hello Meru Mobile Shop, mujhe ${productName} ke baare mein information chahiye.`
      : defaultMessage
  );

  const handleSend = () => {
    const url = createWhatsAppUrl(whatsappNumber, customMsg);
    window.open(url, '_blank');
    setIsOpen(false);
  };

  return (
    <div className="fixed bottom-5 right-5 z-40">
      {/* Popover Dialogue */}
      {isOpen && (
        <div className="mb-3 w-80 bg-slate-900 border border-slate-700/80 rounded-2xl p-4 shadow-2xl animate-in slide-in-from-bottom-2 text-slate-100">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <MessageCircle className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">{shopName}</h4>
                <p className="text-[10px] text-emerald-400 font-medium">● Online Support (Ganj Basoda)</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 text-slate-400 hover:text-white rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="py-3">
            <p className="text-[11px] text-slate-300 mb-2">
              Send a direct WhatsApp message to Maneesh Jain at Meru Mobile Shop:
            </p>
            <textarea
              value={customMsg}
              onChange={(e) => setCustomMsg(e.target.value)}
              rows={3}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 resize-none"
            />
          </div>

          <button
            onClick={handleSend}
            className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/30 transition-all"
          >
            <Send className="w-3.5 h-3.5" />
            Start WhatsApp Chat
          </button>
        </div>
      )}

      {/* Floating Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-13 h-13 rounded-full bg-gradient-to-tr from-emerald-600 to-green-500 hover:from-emerald-500 hover:to-green-400 text-white flex items-center justify-center shadow-xl shadow-emerald-950/60 transition-transform hover:scale-105 active:scale-95 group relative"
        title="Chat on WhatsApp"
        aria-label="Chat on WhatsApp"
      >
        <MessageCircle className="w-6 h-6 group-hover:rotate-12 transition-transform" />
        <span className="absolute -top-1 -right-1 w-3 h-3 bg-white rounded-full flex items-center justify-center">
          <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
        </span>
      </button>
    </div>
  );
};
