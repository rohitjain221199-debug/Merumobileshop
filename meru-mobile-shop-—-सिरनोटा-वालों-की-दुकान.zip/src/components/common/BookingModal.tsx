import React, { useState } from 'react';
import { X, Calendar, Phone, User, MessageSquare, CheckCircle2, Send } from 'lucide-react';
import { StoreService } from '../../services/storeService';
import { BookingEnquiry } from '../../types/database';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultType?: BookingEnquiry['enquiry_type'];
  defaultProduct?: string;
  whatsappNumber: string;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  defaultType = 'Product Reservation',
  defaultProduct = '',
  whatsappNumber,
}) => {
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [enquiryType, setEnquiryType] = useState<BookingEnquiry['enquiry_type']>(defaultType);
  const [productName, setProductName] = useState(defaultProduct);
  const [preferredDate, setPreferredDate] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [bookingRef, setBookingRef] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone) return;

    const newBooking = StoreService.createBooking({
      customer_name: customerName,
      customer_phone: customerPhone,
      enquiry_type: enquiryType,
      product_name: productName || undefined,
      preferred_date: preferredDate || undefined,
      message: message || undefined,
    });

    setBookingRef(newBooking.id);
    setIsSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden p-6 text-slate-100">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="font-bold text-white text-base">
              Meru Shop Enquiry & Reservation
            </h3>
            <p className="text-xs text-amber-400 font-hindi mt-0.5">
              सिरनोटा वालों की दुकान — गंज बासोदा
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSubmitted ? (
          <div className="py-8 text-center space-y-4">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div>
              <h4 className="text-lg font-bold text-white">
                Request Registered Successfully!
              </h4>
              <p className="text-xs text-slate-300 mt-1 max-w-sm mx-auto">
                Thank you, <span className="text-white font-semibold">{customerName}</span>. Maneesh Jain or our store executive will call you shortly on{' '}
                <span className="text-emerald-400 font-mono">{customerPhone}</span>.
              </p>
              <div className="mt-3 inline-block bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-[11px] text-slate-400">
                Reference ID: <span className="text-blue-400 font-mono font-bold">{bookingRef}</span>
              </div>
            </div>

            <div className="pt-2 flex justify-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5 pt-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Your Full Name *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Ramesh Sharma"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Mobile Number (WhatsApp) *
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="10-digit mobile number"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Enquiry Type
                </label>
                <select
                  value={enquiryType}
                  onChange={(e) => setEnquiryType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="Product Reservation">Device Reservation</option>
                  <option value="Finance EMI Enquiry">Finance / 0% EMI Enquiry</option>
                  <option value="Store Visit">Plan Showroom Visit</option>
                  <option value="Phone Enquiry">Phone Price & Stock Enquiry</option>
                  <option value="Callback Request">Request Owner Callback</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Preferred Date (Optional)
                </label>
                <input
                  type="date"
                  value={preferredDate}
                  onChange={(e) => setPreferredDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Product or Model of Interest
              </label>
              <input
                type="text"
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                placeholder="e.g. Samsung S24 5G / Vivo V30 Pro / boAt Earbuds"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Message / Query (Optional)
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={2}
                placeholder="Write any questions regarding price, exchange, or Bajaj finance..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-blue-500 resize-none"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-blue-900/30 transition-all"
              >
                <Send className="w-3.5 h-3.5" />
                Submit Enquiry to Meru Mobile Shop
              </button>
              <p className="text-[10px] text-slate-400 text-center mt-2">
                Tyoda Road, Ganj Basoda, Dist. Vidisha (MP)
              </p>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
