import React, { useState } from 'react';
import { Tag, Copy, Check, Sparkles, Clock, AlertCircle, ArrowRight } from 'lucide-react';
import { Offer, Banner } from '../../../types/database';
import { formatPrice } from '../../../utils/formatters';

interface OffersPageProps {
  offers: Offer[];
  banners: Banner[];
  onClaimOffer: () => void;
}

export const OffersPage: React.FC<OffersPageProps> = ({
  offers,
  banners,
  onClaimOffer,
}) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const activeOffers = offers.filter((o) => o.is_active);

  return (
    <div className="min-h-[600px] flex flex-col justify-between p-5 sm:p-8 bg-slate-900/90 text-slate-100 rounded-2xl border border-slate-800 space-y-6">
      {/* Chapter Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-emerald-600/30 text-emerald-400 font-bold flex items-center justify-center text-xs">
            03
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
            Chapter II • Festive Offers & Coupons
          </span>
        </div>
        <span className="text-xs font-hindi text-amber-400 font-medium">
          सिरनोटा वालों की दुकान
        </span>
      </div>

      <div className="space-y-4">
        <div>
          <h2 className="text-2xl font-black text-white font-serif-display flex items-center gap-2">
            <Tag className="w-6 h-6 text-amber-400" />
            Today's Exclusive Offers
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Apply these limited-period coupons during checkout or mention them in-store at Tyoda Road showroom.
          </p>
        </div>

        {/* Coupons List */}
        <div className="space-y-3">
          {activeOffers.map((offer) => (
            <div
              key={offer.id}
              className="relative p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-blue-500/50 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 group shadow-md"
            >
              {/* Left Offer Details */}
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    {offer.banner_badge || `${offer.discount_value}${offer.discount_type === 'percentage' ? '%' : '₹'} OFF`}
                  </span>
                  <span className="text-xs font-bold text-white">{offer.name}</span>
                </div>
                <p className="text-xs text-slate-400">{offer.description}</p>
                <div className="flex items-center gap-3 text-[11px] text-slate-500 pt-0.5">
                  <span>Min Order: {formatPrice(offer.min_order_amount)}</span>
                  <span>•</span>
                  <span className="flex items-center gap-1 text-amber-400/80">
                    <Clock className="w-3 h-3" />
                    Valid till Dec 2027
                  </span>
                </div>
              </div>

              {/* Right Coupon Code Box */}
              {offer.coupon_code && (
                <div className="flex items-center gap-2 shrink-0">
                  <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-dashed border-blue-500/60 font-mono text-xs font-bold text-blue-300 tracking-wider">
                    {offer.coupon_code}
                  </div>
                  <button
                    onClick={() => handleCopy(offer.coupon_code!)}
                    className="p-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/40 text-blue-300 hover:text-white border border-blue-600/40 transition-all flex items-center gap-1 text-xs"
                    title="Copy Coupon Code"
                  >
                    {copiedCode === offer.coupon_code ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400 text-[11px] font-bold">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span className="text-[11px]">Copy</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* In-Store Bonus Notice */}
        <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-200 flex items-start gap-2.5">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-amber-300">
              In-Store Exchange Bonus & Free Cover:
            </span>{' '}
            Bring your old phone in any working condition for additional trade-in discount up to ₹3,000 + free tempered glass applied on the spot.
          </div>
        </div>
      </div>

      {/* Footer Navigation CTA */}
      <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
        <span className="text-xs text-slate-400">
          Showing {activeOffers.length} active coupons
        </span>
        <button
          onClick={onClaimOffer}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-900/30 transition-all active:scale-95"
        >
          <span>Shop Eligible Phones</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
