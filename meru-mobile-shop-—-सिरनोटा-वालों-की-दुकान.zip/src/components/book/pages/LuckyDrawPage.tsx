import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Gift, Sparkles, Award, Phone, User, CheckCircle2, AlertCircle, Share2, MessageCircle } from 'lucide-react';
import { StoreService } from '../../../services/storeService';
import { LuckyDrawPrize, LuckyDrawWinner, SiteSettings } from '../../../types/database';
import { createWhatsAppUrl } from '../../../utils/formatters';

interface LuckyDrawPageProps {
  settings: SiteSettings;
  onExplorePhones: () => void;
}

export const LuckyDrawPage: React.FC<LuckyDrawPageProps> = ({
  settings,
  onExplorePhones,
}) => {
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [isSpinning, setIsSpinning] = useState(false);
  const [result, setResult] = useState<{
    won: boolean;
    prize?: LuckyDrawPrize;
    winner?: LuckyDrawWinner;
  } | null>(null);

  const prizes = StoreService.getLuckyPrizes().filter((p) => p.is_active);
  const recentWinners = StoreService.getLuckyWinners().slice(0, 5);

  const handlePlayDraw = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim()) return;

    setIsSpinning(true);
    setTimeout(() => {
      const outcome = StoreService.playLuckyDraw(customerName, customerPhone);
      setResult(outcome);
      setIsSpinning(false);

      if (outcome.won) {
        // Trigger celebratory confetti
        confetti({
          particleCount: 90,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#3b82f6', '#f59e0b', '#10b981', '#ec4899'],
        });
      }
    }, 1200);
  };

  const handleShareOnWhatsApp = () => {
    if (!result?.winner || !result?.prize) return;
    const msg = `🎉 Hey! Maine Meru Mobile Shop (सिरनोटा वालों की दुकान, Ganj Basoda) ke Lucky Draw me "${result.prize.name}" jeeta hai! Ticket No: ${result.winner.ticket_number}. Aap bhi check karein!`;
    const url = `https://wa.me/?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  const handleClaimViaShopWhatsApp = () => {
    if (!result?.winner || !result?.prize) return;
    const msg = `Hello Maneesh Bhaiya, maine online Meru Lucky Draw me "${result.prize.name}" jeeta hai. Meri Ticket No: ${result.winner.ticket_number} hai. Name: ${customerName}, Mobile: ${customerPhone}.`;
    const url = createWhatsAppUrl(settings.whatsapp_number, msg);
    window.open(url, '_blank');
  };

  return (
    <div className="min-h-[600px] flex flex-col justify-between p-5 sm:p-8 bg-slate-900/90 text-slate-100 rounded-2xl border border-slate-800 space-y-6">
      {/* Chapter Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-amber-500/30 text-amber-400 font-bold flex items-center justify-center text-xs">
            17
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
            Chapter V • Festive Lucky Draw
          </span>
        </div>
        <span className="text-xs font-hindi text-amber-400 font-medium">
          सिरनोटा वालों की दुकान
        </span>
      </div>

      <div className="space-y-5">
        <div>
          <h2 className="text-2xl font-black text-white font-serif-display flex items-center gap-2">
            <Gift className="w-6 h-6 text-amber-400" />
            Meru Festive Lucky Draw Scheme
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Every smartphone purchased at Meru Mobile Shop gets an assured lucky coupon ticket to win premium electronic gadgets!
          </p>
        </div>

        {/* Lucky Draw Box or Winner Screen */}
        {result?.won && result.prize && result.winner ? (
          <div className="p-6 bg-gradient-to-b from-amber-950/40 via-slate-950 to-slate-950 border-2 border-amber-500/60 rounded-2xl text-center space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-amber-400" />
              Bumper Congratulations!
            </div>

            <div className="space-y-1">
              <h3 className="text-xl sm:text-2xl font-black text-white">
                {customerName}, You Won!
              </h3>
              <p className="text-sm font-bold text-amber-400">
                {result.prize.name}
              </p>
            </div>

            <div className="w-28 h-28 mx-auto rounded-2xl bg-slate-900 border border-amber-500/40 p-2 flex items-center justify-center overflow-hidden shadow-lg">
              <img
                src={result.prize.image_url}
                alt={result.prize.name}
                className="max-h-full max-w-full object-contain"
              />
            </div>

            <div className="bg-slate-900/90 max-w-xs mx-auto p-3 rounded-xl border border-slate-800 space-y-1">
              <div className="text-[11px] text-slate-400">Official Ticket Number:</div>
              <div className="font-mono text-base font-extrabold text-blue-400 tracking-wider">
                {result.winner.ticket_number}
              </div>
            </div>

            <p className="text-xs text-slate-300 max-w-md mx-auto">
              Please present this ticket number at <span className="text-white font-semibold">Meru Mobile Shop, Tyoda Road, Ganj Basoda</span> during phone purchase or delivery to claim your prize!
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5 pt-2">
              <button
                onClick={handleClaimViaShopWhatsApp}
                className="w-full sm:w-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/30"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Claim On WhatsApp</span>
              </button>

              <button
                onClick={handleShareOnWhatsApp}
                className="w-full sm:w-auto px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-2"
              >
                <Share2 className="w-4 h-4" />
                <span>Share with Friends</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Draw Entry Form */}
            <div className="p-4 sm:p-5 bg-slate-950 rounded-2xl border border-slate-800 space-y-3.5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                Enter Mobile Number to Spin / Draw
              </h3>
              <p className="text-xs text-slate-400">
                Customers visiting showroom or reserving phones can check their luck instantly.
              </p>

              <form onSubmit={handlePlayDraw} className="space-y-3 pt-1">
                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1">
                    Customer Name *
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1">
                    WhatsApp Mobile Number *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="10-digit mobile number"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSpinning}
                  className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 disabled:opacity-50 text-slate-950 font-black text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-amber-950/40 transition-all cursor-pointer"
                >
                  <Gift className="w-4 h-4" />
                  {isSpinning ? 'Drawing Lucky Ticket...' : 'SPIN FOR FESTIVE GIFT'}
                </button>
              </form>

              <p className="text-[10px] text-slate-500 text-center">
                * Note: Gifts are honored at Tyoda Road showroom with any phone purchase.
              </p>
            </div>

            {/* Showcase of Active Prizes */}
            <div className="p-4 sm:p-5 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center justify-between">
                <span>Festive Prizes in Stock</span>
                <span className="text-[11px] text-amber-400 font-hindi">
                  सिरनोटा लकी ड्रॉ
                </span>
              </h3>

              <div className="grid grid-cols-3 gap-2">
                {prizes.slice(0, 6).map((prize) => (
                  <div
                    key={prize.id}
                    className="p-2 bg-slate-900 rounded-xl border border-slate-800 text-center space-y-1"
                  >
                    <div className="w-10 h-10 mx-auto rounded-lg overflow-hidden bg-slate-950 flex items-center justify-center p-1">
                      <img
                        src={prize.image_url}
                        alt={prize.name}
                        className="max-h-full max-w-full object-contain"
                      />
                    </div>
                    <div className="text-[10px] font-bold text-white line-clamp-1">
                      {prize.name}
                    </div>
                    <div className="text-[9px] text-emerald-400">
                      {prize.remaining_quantity} Left
                    </div>
                  </div>
                ))}
              </div>

              {/* Recent Winners Ticker */}
              <div className="pt-2 border-t border-slate-900">
                <div className="text-[11px] font-bold text-slate-400 mb-1.5">
                  Recent Ganj Basoda Winners:
                </div>
                <div className="space-y-1 max-h-24 overflow-y-auto pr-1">
                  {recentWinners.map((win) => (
                    <div
                      key={win.id}
                      className="text-[10px] text-slate-300 flex items-center justify-between bg-slate-900/60 px-2 py-1 rounded"
                    >
                      <span className="font-semibold text-white">{win.customer_name}</span>
                      <span className="text-amber-400">{win.prize_name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Navigation CTA */}
      <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
        <span className="text-xs text-slate-400 font-hindi">
          हर स्मार्टफोन पर लकी ड्रॉ कूपन सुनिश्चित
        </span>
        <button
          onClick={onExplorePhones}
          className="text-xs text-blue-400 hover:text-white font-semibold"
        >
          Browse Eligible Smartphones →
        </button>
      </div>
    </div>
  );
};
