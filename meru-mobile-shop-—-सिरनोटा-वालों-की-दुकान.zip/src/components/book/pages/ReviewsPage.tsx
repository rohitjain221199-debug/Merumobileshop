import React, { useState } from 'react';
import { Star, MessageSquare, Plus, CheckCircle2, ShieldCheck } from 'lucide-react';
import { Review, Product } from '../../../types/database';
import { StoreService } from '../../../services/storeService';
import { formatDate } from '../../../utils/formatters';

interface ReviewsPageProps {
  reviews: Review[];
  products: Product[];
  onReviewSubmitted: () => void;
}

export const ReviewsPage: React.FC<ReviewsPageProps> = ({
  reviews,
  products,
  onReviewSubmitted,
}) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [productId, setProductId] = useState(products[0]?.id || '');
  const [rating, setRating] = useState(5);
  const [title, setTitle] = useState('');
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const approvedReviews = reviews.filter((r) => r.is_approved);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !title || !comment) return;

    const prod = products.find((p) => p.id === productId);
    StoreService.submitReview({
      product_id: productId,
      product_name: prod ? prod.name : 'Store Experience',
      customer_name: customerName,
      customer_phone: customerPhone || undefined,
      rating,
      title,
      comment,
    });

    setSubmitted(true);
    setIsFormOpen(false);
    onReviewSubmitted();
  };

  return (
    <div className="min-h-[600px] flex flex-col justify-between p-5 sm:p-8 bg-slate-900/90 text-slate-100 rounded-2xl border border-slate-800 space-y-6">
      {/* Chapter Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs">
            22
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
            Chapter X • Customer Feedback & Ratings
          </span>
        </div>
        <span className="text-xs font-hindi text-amber-400 font-medium">
          सिरनोटा वालों की दुकान
        </span>
      </div>

      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-2xl font-black text-white font-serif-display">
              Verified Customer Reviews
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Read real feedback from customers in Ganj Basoda and Vidisha district.
            </p>
          </div>

          <button
            onClick={() => setIsFormOpen(!isFormOpen)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 self-start shadow-md"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Write a Review</span>
          </button>
        </div>

        {submitted && (
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center gap-2 text-xs text-emerald-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              Thank you! Your review has been submitted and will appear publicly once verified by our store team.
            </span>
          </div>
        )}

        {/* Write Review Form */}
        {isFormOpen && (
          <form
            onSubmit={handleSubmit}
            className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3 animate-in fade-in"
          >
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Share Your Meru Mobile Experience
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Your Name *</label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Deepak Raghuwanshi"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Mobile Number (Optional)</label>
                <input
                  type="tel"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="For purchase verification"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Product Purchased</label>
                <select
                  value={productId}
                  onChange={(e) => setProductId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Rating</label>
                <div className="flex items-center gap-1.5 pt-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className="p-1 text-slate-600 hover:text-amber-400"
                    >
                      <Star
                        className={`w-5 h-5 ${
                          star <= rating
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-slate-700'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs text-amber-400 font-bold ml-2">{rating} Stars</span>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-slate-300 mb-1">Review Headline *</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Best mobile price and genuine GST invoice"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-[11px] text-slate-300 mb-1">Detailed Feedback *</label>
              <textarea
                required
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                rows={2}
                placeholder="Write about phone performance, Maneesh Jain's service, or Bajaj finance..."
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-blue-500 resize-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="px-3 py-1.5 text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold"
              >
                Submit Review
              </button>
            </div>
          </form>
        )}

        {/* Reviews List */}
        <div className="space-y-3">
          {approvedReviews.map((rev) => (
            <div
              key={rev.id}
              className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2 shadow-sm"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white">{rev.title}</h4>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[11px] text-slate-400">{rev.customer_name}</span>
                    <span className="text-slate-600">•</span>
                    <span className="text-[10px] text-slate-500">{formatDate(rev.created_at)}</span>
                    <span className="text-emerald-400 text-[10px] flex items-center gap-0.5">
                      <ShieldCheck className="w-3 h-3" /> Verified Buyer
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-0.5 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  <span className="text-xs font-bold text-amber-400">{rev.rating}</span>
                  <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">{rev.comment}</p>

              {rev.product_name && (
                <div className="text-[10px] text-blue-400 font-medium pt-1">
                  Product: {rev.product_name}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Footer Info */}
      <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
        <span>Average Customer Rating: 4.9 / 5.0</span>
        <span className="font-hindi text-amber-400">सिरनोटा वालों की दुकान — गंज बासोदा</span>
      </div>
    </div>
  );
};
