import React, { useState } from 'react';
import { ShoppingBag, Trash2, Plus, Minus, Tag, Check, ArrowRight, ShieldCheck, Truck } from 'lucide-react';
import { CartItem, SiteSettings } from '../../../types/database';
import { formatPrice } from '../../../utils/formatters';
import { StoreService } from '../../../services/storeService';

interface CartPageProps {
  cart: CartItem[];
  settings: SiteSettings;
  onUpdateQty: (itemId: string, qty: number) => void;
  onProceedToCheckout: () => void;
  onContinueShopping: () => void;
}

export const CartPage: React.FC<CartPageProps> = ({
  cart,
  settings,
  onUpdateQty,
  onProceedToCheckout,
  onContinueShopping,
}) => {
  const [couponCode, setCouponCode] = useState('');
  const [couponError, setCouponError] = useState<string | null>(null);
  const [appliedCoupon, setAppliedCoupon] = useState<{
    code: string;
    discount: number;
    message: string;
  } | null>(null);

  const subtotal = cart.reduce((acc, item) => acc + item.variant.selling_price * item.quantity, 0);
  const discountAmount = appliedCoupon ? appliedCoupon.discount : 0;
  const isFreeDelivery = subtotal >= settings.free_delivery_above || subtotal === 0;
  const deliveryCharge = isFreeDelivery ? 0 : 50;
  const finalTotal = Math.max(0, subtotal - discountAmount + deliveryCharge);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError(null);
    const res = StoreService.applyCoupon(couponCode, subtotal);
    if (!res.valid) {
      setCouponError(res.message);
      setAppliedCoupon(null);
    } else {
      setAppliedCoupon({
        code: couponCode.toUpperCase(),
        discount: res.discount,
        message: res.message,
      });
    }
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode('');
    setCouponError(null);
  };

  return (
    <div className="min-h-[600px] flex flex-col justify-between p-5 sm:p-8 bg-slate-900/90 text-slate-100 rounded-2xl border border-slate-800 space-y-6">
      {/* Chapter Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs">
            20
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
            Chapter VIII • Shopping Bag & Order Summary
          </span>
        </div>
        <span className="text-xs font-hindi text-amber-400 font-medium">
          सिरनोटा वालों की दुकान
        </span>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-black text-white font-serif-display flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-blue-400" />
            Your Shopping Bag
          </h2>
          <span className="text-xs text-slate-400">
            {cart.reduce((a, b) => a + b.quantity, 0)} Items
          </span>
        </div>

        {cart.length === 0 ? (
          <div className="py-16 text-center text-slate-400 space-y-3">
            <ShoppingBag className="w-12 h-12 mx-auto text-slate-600" />
            <h3 className="text-base font-bold text-white">Your bag is currently empty</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Explore our smartphones, 5G devices, genuine chargers, and audio collection from Ganj Basoda.
            </p>
            <button
              onClick={onContinueShopping}
              className="mt-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all shadow-md"
            >
              Browse Smartphones
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Items List */}
            <div className="lg:col-span-2 space-y-3">
              {cart.map((item) => (
                <div
                  key={item.id}
                  className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between gap-3 shadow-sm"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-16 h-16 rounded-xl bg-slate-900 border border-slate-800 p-1 flex items-center justify-center shrink-0">
                      <img
                        src={item.variant.image_url || item.product.primary_image}
                        alt={item.product.name}
                        className="max-h-full max-w-full object-contain"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-blue-400 font-bold uppercase">
                        {item.product.brand_name}
                      </span>
                      <h4 className="text-xs sm:text-sm font-bold text-white line-clamp-1">
                        {item.product.name}
                      </h4>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {item.variant.color_name} {item.variant.ram ? `• ${item.variant.ram} / ${item.variant.storage}` : ''}
                      </div>
                      <div className="text-xs font-extrabold text-white mt-1">
                        {formatPrice(item.variant.selling_price)}
                      </div>
                    </div>
                  </div>

                  {/* Quantity controls */}
                  <div className="flex items-center gap-2 shrink-0">
                    <div className="flex items-center bg-slate-900 rounded-xl border border-slate-800 p-1">
                      <button
                        type="button"
                        onClick={() => onUpdateQty(item.id, item.quantity - 1)}
                        className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-2.5 text-xs font-bold text-white">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => onUpdateQty(item.id, item.quantity + 1)}
                        className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => onUpdateQty(item.id, 0)}
                      className="p-2 text-slate-500 hover:text-red-400 transition-colors"
                      title="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Price & Summary Sidebar */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-4 h-fit">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Order Breakdown
              </h3>

              {/* Coupon Input */}
              <form onSubmit={handleApplyCoupon} className="space-y-1.5">
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                    placeholder="Coupon code (e.g. FESTIVE500)"
                    disabled={Boolean(appliedCoupon)}
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white uppercase font-mono placeholder:normal-case placeholder-slate-500 focus:outline-none focus:border-blue-500"
                  />
                  {appliedCoupon ? (
                    <button
                      type="button"
                      onClick={handleRemoveCoupon}
                      className="px-2.5 py-1.5 bg-red-950/60 border border-red-800 text-red-300 rounded-xl text-xs font-semibold"
                    >
                      Remove
                    </button>
                  ) : (
                    <button
                      type="submit"
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold"
                    >
                      Apply
                    </button>
                  )}
                </div>

                {appliedCoupon && (
                  <p className="text-[11px] text-emerald-400 font-medium">
                    ✓ {appliedCoupon.message}
                  </p>
                )}
                {couponError && (
                  <p className="text-[11px] text-red-400 font-medium">
                    ✕ {couponError}
                  </p>
                )}
              </form>

              {/* Price Details */}
              <div className="space-y-2 text-xs border-t border-slate-900 pt-3">
                <div className="flex justify-between text-slate-400">
                  <span>Subtotal:</span>
                  <span className="font-semibold text-white">{formatPrice(subtotal)}</span>
                </div>

                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Coupon Discount:</span>
                    <span className="font-bold">-{formatPrice(discountAmount)}</span>
                  </div>
                )}

                <div className="flex justify-between text-slate-400">
                  <span>Local Ganj Basoda Delivery:</span>
                  <span className={isFreeDelivery ? 'text-emerald-400 font-semibold' : 'text-white'}>
                    {isFreeDelivery ? 'FREE' : formatPrice(deliveryCharge)}
                  </span>
                </div>

                <div className="border-t border-slate-800 pt-2 flex justify-between text-sm font-black text-white">
                  <span>Total Payable:</span>
                  <span className="text-base text-blue-400">{formatPrice(finalTotal)}</span>
                </div>
              </div>

              <button
                type="button"
                onClick={onProceedToCheckout}
                className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-blue-900/30 transition-all active:scale-95 cursor-pointer"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="text-[10px] text-slate-500 text-center flex items-center justify-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Verified & packed at Meru Mobile Showroom
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Navigation CTA */}
      <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
        <button
          onClick={onContinueShopping}
          className="text-slate-400 hover:text-white"
        >
          ← Continue Shopping
        </button>

        {cart.length > 0 && (
          <button
            onClick={onProceedToCheckout}
            className="text-blue-400 hover:text-white font-semibold flex items-center gap-1"
          >
            <span>Go to Address & Checkout (Page 21)</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
