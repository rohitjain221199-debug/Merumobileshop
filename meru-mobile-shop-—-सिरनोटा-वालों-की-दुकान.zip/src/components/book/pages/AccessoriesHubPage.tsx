import React from 'react';
import { Headphones, Volume2, BatteryCharging, Zap, Watch, ShieldCheck, ChevronRight, Sparkles } from 'lucide-react';
import { Category } from '../../../types/database';

interface AccessoriesHubPageProps {
  categories: Category[];
  onNavigateToPage: (pageNumber: number) => void;
}

export const AccessoriesHubPage: React.FC<AccessoriesHubPageProps> = ({
  categories,
  onNavigateToPage,
}) => {
  const sections = [
    {
      title: 'Earbuds & Headphones',
      desc: 'TWS earbuds, wireless neckbands & ANC over-ear headphones',
      icon: Headphones,
      page: 11,
      color: 'from-blue-600 to-indigo-600',
    },
    {
      title: 'Bluetooth Speakers',
      desc: 'Deep bass party & travel speakers with long playtime',
      icon: Volume2,
      page: 12,
      color: 'from-purple-600 to-indigo-700',
    },
    {
      title: 'Fast Power Banks',
      desc: '10000mAh & 20000mAh fast charge backup batteries',
      icon: BatteryCharging,
      page: 13,
      color: 'from-emerald-600 to-teal-700',
    },
    {
      title: 'GaN Chargers & Cables',
      desc: '65W GaN adapters, SuperVOOC & heavy-duty braided cords',
      icon: Zap,
      page: 14,
      color: 'from-amber-600 to-orange-700',
    },
    {
      title: 'Smartwatches',
      desc: 'Bluetooth calling, AMOLED displays & fitness suites',
      icon: Watch,
      page: 15,
      color: 'from-cyan-600 to-blue-700',
    },
    {
      title: 'Covers & Laser Tempered Glass',
      desc: 'Precision laser cut tempered glass & military grade cases',
      icon: ShieldCheck,
      page: 16,
      color: 'from-rose-600 to-pink-700',
    },
  ];

  return (
    <div className="min-h-[600px] flex flex-col justify-between p-5 sm:p-8 bg-slate-900/90 text-slate-100 rounded-2xl border border-slate-800 space-y-6">
      {/* Chapter Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs">
            10
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
            Chapter IV • Genuine Accessories Hub
          </span>
        </div>
        <span className="text-xs font-hindi text-amber-400 font-medium">
          सिरनोटा वालों की दुकान
        </span>
      </div>

      <div className="space-y-4">
        <div>
          <h2 className="text-2xl font-black text-white font-serif-display">
            Original Accessories & Audio Hub
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Browse genuine lifestyle accessories from boAt, Noise, Realme, Samsung, Xiaomi, and Apple with full replacement guarantees.
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {sections.map((sec) => {
            const Icon = sec.icon;
            return (
              <div
                key={sec.title}
                onClick={() => onNavigateToPage(sec.page)}
                className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-blue-500/60 cursor-pointer transition-all flex flex-col justify-between group shadow-sm space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${sec.color} flex items-center justify-center text-white shadow-md group-hover:scale-105 transition-transform`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">
                    Page {sec.page}
                  </span>
                </div>

                <div>
                  <h4 className="text-sm font-bold text-white group-hover:text-blue-300 transition-colors">
                    {sec.title}
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">
                    {sec.desc}
                  </p>
                </div>

                <div className="flex items-center justify-between text-xs text-blue-400 font-semibold pt-1 border-t border-slate-900">
                  <span>Explore Items</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>

        {/* Special in-store perk */}
        <div className="p-3.5 bg-blue-950/40 border border-blue-800/40 rounded-xl text-xs text-blue-200 flex items-center gap-3">
          <Sparkles className="w-4 h-4 text-blue-400 shrink-0" />
          <div>
            <span className="font-bold text-white">In-Store UV Laser Cutting Machine:</span>{' '}
            Get customized edge-to-edge unbreakable tempered glass & stylish back skins cut and applied within 3 minutes for any phone model in Ganj Basoda.
          </div>
        </div>
      </div>

      {/* Footer Navigation CTA */}
      <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
        <span>Genuine Branded Quality</span>
        <button
          onClick={() => onNavigateToPage(11)}
          className="inline-flex items-center gap-1.5 text-blue-400 hover:text-white font-semibold"
        >
          <span>Go to Audio & Earbuds (Page 11)</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
