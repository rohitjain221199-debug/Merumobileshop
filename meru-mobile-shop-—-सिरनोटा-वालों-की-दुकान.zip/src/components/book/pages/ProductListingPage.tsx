import React, { useState } from 'react';
import { Smartphone, ShoppingBag, Zap, Star, ShieldCheck, Eye } from 'lucide-react';
import { Product, Brand } from '../../../types/database';
import { formatPrice } from '../../../utils/formatters';

interface ProductListingPageProps {
  title: string;
  subtitle: string;
  products: Product[];
  brands: Brand[];
  onOpenProduct: (product: Product) => void;
  onAddToCart: (product: Product, variantId?: string) => void;
  onBuyNow: (product: Product, variantId?: string) => void;
}

export const ProductListingPage: React.FC<ProductListingPageProps> = ({
  title,
  subtitle,
  products,
  brands,
  onOpenProduct,
  onAddToCart,
  onBuyNow,
}) => {
  const [selectedBrand, setSelectedBrand] = useState<string>('all');

  const filteredProducts = products.filter((p) => {
    if (!p.is_active) return false;
    if (selectedBrand !== 'all' && p.brand_id !== selectedBrand) return false;
    return true;
  });

  return (
    <div className="min-h-[600px] flex flex-col justify-between p-4 sm:p-6 bg-slate-900/90 text-slate-100 rounded-2xl border border-slate-800 space-y-4">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl sm:text-2xl font-black text-white font-serif-display">
              {title}
            </h2>
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-blue-900/60 text-blue-300 font-bold border border-blue-700/50">
              {filteredProducts.length} Items
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">{subtitle}</p>
        </div>

        {/* Brand quick filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
          <button
            onClick={() => setSelectedBrand('all')}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold shrink-0 transition-colors ${
              selectedBrand === 'all'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            All
          </button>
          {brands.map((b) => (
            <button
              key={b.id}
              onClick={() => setSelectedBrand(b.id)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold shrink-0 transition-colors ${
                selectedBrand === b.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {b.name}
            </button>
          ))}
        </div>
      </div>

      {/* Products Grid */}
      <div className="flex-1">
        {filteredProducts.length === 0 ? (
          <div className="py-16 text-center text-slate-400 space-y-2">
            <Smartphone className="w-10 h-10 mx-auto text-slate-600" />
            <p className="text-xs font-medium">No items found in this section right now.</p>
            <p className="text-[11px] text-slate-500">
              Try selecting "All" brands or visit our showroom on Tyoda Road.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
            {filteredProducts.map((product) => {
              const defaultVariant = product.variants?.[0];
              const isOutOfStock = product.stock_status === 'out_of_stock';
              const discountPercent =
                product.mrp > product.selling_price
                  ? Math.round(((product.mrp - product.selling_price) / product.mrp) * 100)
                  : product.discount_percent;

              return (
                <div
                  key={product.id}
                  className="p-3 bg-slate-950 rounded-2xl border border-slate-800/90 hover:border-blue-500/50 transition-all flex flex-col justify-between group shadow-sm relative overflow-hidden"
                >
                  <div className="space-y-2.5">
                    {/* Image Area */}
                    <div
                      onClick={() => onOpenProduct(product)}
                      className="relative aspect-[4/3] bg-slate-900/80 rounded-xl overflow-hidden flex items-center justify-center p-2 cursor-pointer group-hover:scale-102 transition-transform"
                    >
                      <img
                        src={product.primary_image}
                        alt={product.name}
                        className="max-h-full max-w-full object-contain"
                      />

                      {/* Badges */}
                      <div className="absolute top-2 left-2 flex flex-col gap-1">
                        {product.is_5g && (
                          <span className="bg-amber-500 text-slate-950 text-[10px] font-black px-1.5 py-0.5 rounded shadow">
                            5G
                          </span>
                        )}
                        {discountPercent > 0 && (
                          <span className="bg-red-600 text-white text-[10px] font-extrabold px-1.5 py-0.5 rounded shadow">
                            {discountPercent}% OFF
                          </span>
                        )}
                      </div>

                      {product.is_bestseller && (
                        <span className="absolute bottom-2 right-2 bg-blue-600/90 text-white text-[9px] font-bold px-1.5 py-0.5 rounded backdrop-blur-xs">
                          Bestseller
                        </span>
                      )}

                      {isOutOfStock && (
                        <div className="absolute inset-0 bg-slate-950/80 flex items-center justify-center text-xs font-bold text-red-400">
                          Out of Stock
                        </div>
                      )}
                    </div>

                    {/* Meta & Title */}
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-blue-400 font-bold uppercase tracking-wider">
                          {product.brand_name}
                        </span>
                        <span className="text-[10px] text-slate-500 font-hindi">
                          वारंटी सहित
                        </span>
                      </div>
                      <h4
                        onClick={() => onOpenProduct(product)}
                        className="text-xs sm:text-sm font-bold text-white group-hover:text-blue-300 transition-colors line-clamp-1 cursor-pointer mt-0.5"
                      >
                        {product.name}
                      </h4>
                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                        {product.short_description}
                      </p>

                      {/* Available variants teaser */}
                      {product.variants && product.variants.length > 0 && (
                        <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                          {product.variants.slice(0, 3).map((v) => (
                            <span
                              key={v.id}
                              className="text-[9px] bg-slate-900 text-slate-300 border border-slate-800 px-1.5 py-0.5 rounded"
                            >
                              {v.ram ? `${v.ram}/` : ''}{v.storage || v.color_name}
                            </span>
                          ))}
                          {product.variants.length > 3 && (
                            <span className="text-[9px] text-slate-500">
                              +{product.variants.length - 3} more
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Price & Action Buttons */}
                  <div className="pt-3 border-t border-slate-900 mt-2 space-y-2">
                    <div className="flex items-baseline justify-between">
                      <div>
                        <span className="text-base font-black text-white">
                          {formatPrice(product.selling_price)}
                        </span>
                        {product.mrp > product.selling_price && (
                          <span className="text-[11px] text-slate-500 line-through ml-1.5">
                            {formatPrice(product.mrp)}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-emerald-400 font-semibold">
                        0% EMI Avail.
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-1.5">
                      <button
                        type="button"
                        disabled={isOutOfStock}
                        onClick={() => onAddToCart(product, defaultVariant?.id)}
                        className="py-2 px-2.5 rounded-xl bg-slate-800 hover:bg-blue-600 disabled:opacity-40 text-white text-xs font-semibold flex items-center justify-center gap-1 transition-colors"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        <span>Bag</span>
                      </button>

                      <button
                        type="button"
                        disabled={isOutOfStock}
                        onClick={() => onBuyNow(product, defaultVariant?.id)}
                        className="py-2 px-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-xs font-bold flex items-center justify-center gap-1 transition-colors shadow-sm"
                      >
                        <Zap className="w-3.5 h-3.5" />
                        <span>Buy Now</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
        <span className="font-hindi text-amber-400">सिरनोटा वालों की दुकान — गंज बासोदा</span>
        <span className="flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          100% Brand Sealed Pack
        </span>
      </div>
    </div>
  );
};
