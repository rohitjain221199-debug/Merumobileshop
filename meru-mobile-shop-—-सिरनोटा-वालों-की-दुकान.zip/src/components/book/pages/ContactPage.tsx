import React from 'react';
import { MapPin, Phone, MessageCircle, Clock, ExternalLink, Calendar, Mail, Compass } from 'lucide-react';
import { SiteSettings } from '../../../types/database';
import { createWhatsAppUrl } from '../../../utils/formatters';

interface ContactPageProps {
  settings: SiteSettings;
  onOpenEnquiry: () => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({
  settings,
  onOpenEnquiry,
}) => {
  const handleOpenWhatsApp = () => {
    const msg = `Hello Meru Mobile Shop, mujhe aapki Tyoda Road Ganj Basoda showroom visit karni hai.`;
    window.open(createWhatsAppUrl(settings.whatsapp_number, msg), '_blank');
  };

  return (
    <div className="min-h-[600px] flex flex-col justify-between p-5 sm:p-8 bg-slate-900/90 text-slate-100 rounded-2xl border border-slate-800 space-y-6">
      {/* Chapter Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs">
            24
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
            Chapter XII • Showroom Location & Contact
          </span>
        </div>
        <span className="text-xs font-hindi text-amber-400 font-medium">
          सिरनोटा वालों की दुकान
        </span>
      </div>

      <div className="space-y-4">
        <div>
          <h2 className="text-2xl font-black text-white font-serif-display">
            Visit Meru Mobile Showroom
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Conveniently situated in the heart of Ganj Basoda on Tyoda Road, right near Pawan Auto Mobile.
          </p>
        </div>

        {/* Address & Store Info Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-blue-400" />
              Store Address & Landmark
            </h3>

            <div className="text-xs space-y-1 text-slate-300">
              <div className="font-bold text-white text-sm">{settings.shop_name}</div>
              <div className="text-amber-400 font-hindi font-medium">{settings.brand_tagline}</div>
              <div>{settings.address_street}</div>
              <div>{settings.landmark}</div>
              <div>{settings.address_city}, Dist. {settings.address_district}</div>
              <div>{settings.address_state} – {settings.address_pincode}</div>
            </div>

            <div className="pt-2 border-t border-slate-900 space-y-2 text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <Clock className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Opening Hours: {settings.opening_hours}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Phone className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Call Owner: {settings.phone} ({settings.owner_name})</span>
              </div>
            </div>

            <div className="pt-2 flex gap-2">
              <a
                href={settings.google_maps_url}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-2 px-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-sm"
              >
                <Compass className="w-3.5 h-3.5" />
                <span>Open in Google Maps</span>
              </a>

              <button
                type="button"
                onClick={handleOpenWhatsApp}
                className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-sm"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Chat WhatsApp</span>
              </button>
            </div>
          </div>

          {/* Interactive Map Visualizer / Directions Card */}
          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col justify-between space-y-3">
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-amber-400" />
                How to Reach Us
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Coming from Old Bus Stand or Railway Station? Take the Tyoda Road turn towards Pawan Auto Mobile. Meru Mobile Shop's prominent showroom board ("सिरनोटा वालों की दुकान") is located right on the main commercial road with ample parking for two-wheelers and cars.
              </p>
            </div>

            {/* Map Preview Frame */}
            <div className="aspect-[16/9] rounded-xl overflow-hidden bg-slate-900 border border-slate-800 relative flex items-center justify-center group">
              <img
                src="https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=800&auto=format&fit=crop"
                alt="Ganj Basoda Location Map"
                className="w-full h-full object-cover opacity-40 group-hover:scale-105 transition-transform"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
              <div className="absolute text-center p-3">
                <MapPin className="w-8 h-8 text-blue-400 mx-auto drop-shadow-lg animate-bounce" />
                <span className="text-xs font-bold text-white block mt-1">
                  Tyoda Road, Ganj Basoda
                </span>
                <span className="text-[10px] text-amber-300 font-hindi">
                  सिरनोटा वालों की दुकान
                </span>
              </div>
            </div>

            <button
              onClick={onOpenEnquiry}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <Calendar className="w-3.5 h-3.5 text-blue-400" />
              <span>Schedule Showroom Visit / Reserve Device</span>
            </button>
          </div>
        </div>
      </div>

      {/* Footer Navigation CTA */}
      <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
        <span>Ganj Basoda (District Vidisha, MP)</span>
        <span className="font-hindi text-amber-400">हमेशा आपकी सेवा में समर्पित</span>
      </div>
    </div>
  );
};
