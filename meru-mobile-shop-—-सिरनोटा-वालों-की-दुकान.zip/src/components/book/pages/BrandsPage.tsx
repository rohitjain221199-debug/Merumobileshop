import React from 'react';
import { ShieldCheck, ChevronRight, Award } from 'lucide-react';
import { Brand, Product } from '../../../types/database';

interface BrandsPageProps {
  brands: Brand[];
  products: Product[];
  onSelectBrand: (brandId: string) => void;
  onOpenProduct: (product: Product) => void;
}

export const BrandsPage: React.FC<BrandsPageProps> = ({
  brands,
  products,
  onSelectBrand,
  onOpenProduct,
}) => {
  return (
    <div className="min-h-[600px] flex flex-col justify-between p-5 sm:p-8 bg-slate-900/90 text-slate-100 rounded-2xl border border-slate-800 space-y-6">
      {/* Chapter Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs">
            04
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
            Chapter III • Authorized Tech Brands
          </span>
        </div>
        <span className="text-xs font-hindi text-amber-400 font-medium">
          सिरनोटा वालों की दुकान
        </span>
      </div>

      <div className="space-y-4">
        <div>
          <h2 className="text-2xl font-black text-white font-serif-display">
            Official Brand Partnerships
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Meru Mobile Shop is an authorized retail partner for leading global brands. All devices come with standard brand warranty, verified IMEI, and GST invoice.
          </p>
        </div>

        {/* Brands Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {brands.map((brand) => {
            const count = products.filter((p) => p.brand_id === brand.id).length;
            return (
              <div
                key={brand.id}
                onClick={() => onSelectBrand(brand.id)}
                className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-blue-500/60 cursor-pointer transition-all flex flex-col items-center justify-center text-center space-y-2 group shadow-sm"
              >
                <div className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-800 p-1.5 flex items-center justify-center overflow-hidden group-hover:scale-105 transition-transform">
                  <img
                    src={brand.logo_url}
                    alt={brand.name}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-blue-400 transition-colors">
                    {brand.name}
                  </h4>
                  <p className="text-[10px] text-slate-500 mt-0.5">
                    {count > 0 ? `${count} In Showroom` : 'Authorized Stock'}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Local Verification Notice */}
        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center gap-2.5 text-xs text-slate-300">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            Every brand product sold at Meru Mobile Shop includes 100% genuine sealed pack warranty with local Ganj Basoda service support.
          </span>
        </div>
      </div>

      {/* Footer Navigation CTA */}
      <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
        <span className="text-xs text-slate-400 font-hindi">
          गंज बासोदा की अपनी दुकान
        </span>
        <button
          onClick={() => onSelectBrand('all')}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-900/30 transition-all active:scale-95"
        >
          <span>View All Smartphones</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
