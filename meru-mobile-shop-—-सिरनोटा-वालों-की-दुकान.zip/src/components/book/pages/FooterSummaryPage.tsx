import React from 'react';
import { BookOpen, Phone, MapPin, MessageCircle, Heart, ShieldCheck, Award, ArrowUp, Calendar } from 'lucide-react';
import { SiteSettings } from '../../../types/database';
import { createWhatsAppUrl } from '../../../utils/formatters';

interface FooterSummaryPageProps {
  settings: SiteSettings;
  onNavigateToPage: (page: number) => void;
  onOpenEnquiryModal: (type?: any) => void;
}

export const FooterSummaryPage: React.FC<FooterSummaryPageProps> = ({
  settings,
  onNavigateToPage,
  onOpenEnquiryModal,
}) => {
  return (
    <div className="min-h-[600px] flex flex-col justify-between p-5 sm:p-8 bg-slate-950 text-slate-100 rounded-2xl border border-slate-800 space-y-6">
      {/* Chapter Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs">
            26
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
            Chapter XIV • Store Summary & Directory
          </span>
        </div>
        <span className="text-xs font-hindi text-amber-400 font-medium">
          सिरनोटा वालों की दुकान
        </span>
      </div>

      <div className="space-y-5">
        <div className="text-center space-y-2 max-w-lg mx-auto">
          <div className="w-12 h-12 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center mx-auto text-xl font-bold font-serif-display border border-blue-500/40">
            M
          </div>
          <h2 className="text-2xl font-black text-white font-serif-display">
            {settings.shop_name}
          </h2>
          <p className="text-sm font-bold text-amber-400 font-hindi">
            {settings.brand_tagline}
          </p>
          <p className="text-xs text-slate-400">
            Tyoda Road, Near Pawan Auto Mobile / Old Bus Stand, Ganj Basoda, District Vidisha (MP) – 464221
          </p>
        </div>

        {/* Quick Directory Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800/80 space-y-1">
            <h4 className="font-bold text-white uppercase text-[11px] text-blue-400">
              Smartphones
            </h4>
            <ul className="space-y-1 text-slate-400 text-[11px]">
              <li onClick={() => onNavigateToPage(6)} className="hover:text-white cursor-pointer">Featured Phones</li>
              <li onClick={() => onNavigateToPage(8)} className="hover:text-white cursor-pointer">5G Handsets</li>
              <li onClick={() => onNavigateToPage(7)} className="hover:text-white cursor-pointer">Budget Under 15k</li>
              <li onClick={() => onNavigateToPage(9)} className="hover:text-white cursor-pointer">Premium Flagships</li>
            </ul>
          </div>

          <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800/80 space-y-1">
            <h4 className="font-bold text-white uppercase text-[11px] text-emerald-400">
              Accessories
            </h4>
            <ul className="space-y-1 text-slate-400 text-[11px]">
              <li onClick={() => onNavigateToPage(11)} className="hover:text-white cursor-pointer">Earbuds & Audio</li>
              <li onClick={() => onNavigateToPage(14)} className="hover:text-white cursor-pointer">GaN Fast Chargers</li>
              <li onClick={() => onNavigateToPage(13)} className="hover:text-white cursor-pointer">Power Banks</li>
              <li onClick={() => onNavigateToPage(15)} className="hover:text-white cursor-pointer">Calling Watches</li>
            </ul>
          </div>

          <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800/80 space-y-1">
            <h4 className="font-bold text-white uppercase text-[11px] text-amber-400">
              Schemes & EMI
            </h4>
            <ul className="space-y-1 text-slate-400 text-[11px]">
              <li onClick={() => onNavigateToPage(18)} className="hover:text-white cursor-pointer">Bajaj 0% EMI</li>
              <li onClick={() => onNavigateToPage(18)} className="hover:text-white cursor-pointer">HDB & IDFC First</li>
              <li onClick={() => onNavigateToPage(17)} className="hover:text-white cursor-pointer">Festive Lucky Draw</li>
              <li onClick={() => onNavigateToPage(3)} className="hover:text-white cursor-pointer">Coupons & Offers</li>
            </ul>
          </div>

          <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800/80 space-y-1">
            <h4 className="font-bold text-white uppercase text-[11px] text-purple-400">
              Customer Desk
            </h4>
            <ul className="space-y-1 text-slate-400 text-[11px]">
              <li onClick={() => onNavigateToPage(25)} className="hover:text-white cursor-pointer">Track My Order</li>
              <li onClick={() => onNavigateToPage(22)} className="hover:text-white cursor-pointer">Read Reviews</li>
              <li onClick={() => onNavigateToPage(24)} className="hover:text-white cursor-pointer">Showroom Map</li>
              <li onClick={() => onOpenEnquiryModal('Store Visit')} className="hover:text-white cursor-pointer">Book Visit</li>
            </ul>
          </div>
        </div>

        {/* Action Banner */}
        <div className="p-4 bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 rounded-2xl border border-blue-800/50 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div>
            <h3 className="text-sm font-bold text-white">Have a Question or Need Phone Advice?</h3>
            <p className="text-xs text-slate-300">
              Call Maneesh Jain directly or book an in-store callback.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={`tel:${settings.phone}`}
              className="py-2 px-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all"
            >
              Call {settings.phone}
            </a>
            <button
              onClick={() => onOpenEnquiryModal('Callback Request')}
              className="py-2 px-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-medium transition-all"
            >
              Request Callback
            </button>
          </div>
        </div>
      </div>

      {/* Return to Cover CTA */}
      <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
        <span>© Meru Mobile Shop • Maneesh Jain</span>
        <button
          onClick={() => onNavigateToPage(1)}
          className="inline-flex items-center gap-1.5 text-amber-400 hover:text-amber-300 font-semibold cursor-pointer"
        >
          <BookOpen className="w-4 h-4" />
          <span>Close & Return to Cover (Page 1)</span>
          <ArrowUp className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
