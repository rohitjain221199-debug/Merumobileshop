import React from 'react';
import { CheckCircle2, FileText, Clock, UserCheck, ShieldCheck, ChevronRight, PhoneCall } from 'lucide-react';

interface HowFinanceWorksPageProps {
  onExplorePhones: () => void;
  onOpenEnquiry: () => void;
}

export const HowFinanceWorksPage: React.FC<HowFinanceWorksPageProps> = ({
  onExplorePhones,
  onOpenEnquiry,
}) => {
  const steps = [
    {
      num: '01',
      title: 'Pick Your Phone & Variant',
      desc: 'Browse through our catalogue or visit our Tyoda Road showroom to select your desired smartphone model and storage.',
      icon: CheckCircle2,
    },
    {
      num: '02',
      title: 'Bring Simple KYC Documents',
      desc: 'Just carry your original Aadhaar Card (linked with active mobile OTP), PAN Card, and Bank ATM card/Passbook.',
      icon: FileText,
    },
    {
      num: '03',
      title: '15-Minute Paperless Sanction',
      desc: 'Our in-store finance executive processes paperless online verification with Bajaj, HDB, IDFC, or TVS Credit.',
      icon: Clock,
    },
    {
      num: '04',
      title: 'Walk Away with Sealed Phone',
      desc: 'Sign the e-mandate, get your original GST bill, collect your Festive Lucky Draw gift, and take your phone home immediately!',
      icon: UserCheck,
    },
  ];

  return (
    <div className="min-h-[600px] flex flex-col justify-between p-5 sm:p-8 bg-slate-900/90 text-slate-100 rounded-2xl border border-slate-800 space-y-6">
      {/* Chapter Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs">
            19
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
            Chapter VII • Finance Process Guide
          </span>
        </div>
        <span className="text-xs font-hindi text-amber-400 font-medium">
          सिरनोटा वालों की दुकान
        </span>
      </div>

      <div className="space-y-5">
        <div>
          <h2 className="text-2xl font-black text-white font-serif-display">
            How In-Store 0% EMI Works
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Getting a brand new smartphone on EMI in Ganj Basoda has never been easier or faster.
          </p>
        </div>

        {/* 4 Step Timeline */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {steps.map((st) => {
            const Icon = st.icon;
            return (
              <div
                key={st.num}
                className="p-4 bg-slate-950 rounded-2xl border border-slate-800/90 space-y-2 relative overflow-hidden"
              >
                <div className="flex items-center justify-between">
                  <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center">
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-mono font-black text-blue-400/60">
                    STEP {st.num}
                  </span>
                </div>
                <h4 className="text-xs font-bold text-white">{st.title}</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">{st.desc}</p>
              </div>
            );
          })}
        </div>

        {/* FAQ note on eligibility */}
        <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5 text-xs">
          <div className="font-bold text-white flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Eligibility Requirements:</span>
          </div>
          <p className="text-[11px] text-slate-300">
            • Resident of Ganj Basoda, Tyoda, Kurwai, Vidisha, or nearby Madhya Pradesh villages.
          </p>
          <p className="text-[11px] text-slate-300">
            • Minimum age 21 years (Salaried, Self-employed, Farmers, or Business owners).
          </p>
        </div>
      </div>

      {/* Footer Navigation CTA */}
      <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
        <button
          onClick={onOpenEnquiry}
          className="text-xs text-blue-400 hover:text-white font-medium flex items-center gap-1"
        >
          <PhoneCall className="w-3.5 h-3.5" />
          Request Finance Callback
        </button>

        <button
          onClick={onExplorePhones}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-900/30 transition-all active:scale-95"
        >
          <span>Choose Phone on EMI</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
