import React from 'react';
import { BookOpen, Smartphone, Tag, Gift, CreditCard, ChevronRight, Award, MapPin } from 'lucide-react';
import { SiteSettings } from '../../../types/database';

interface CoverPageProps {
  settings: SiteSettings;
  onOpenShop: () => void;
  onNavigate: (page: number) => void;
}

export const CoverPage: React.FC<CoverPageProps> = ({
  settings,
  onOpenShop,
  onNavigate,
}) => {
  return (
    <div className="relative min-h-[640px] md:min-h-[720px] w-full flex flex-col items-center justify-between p-6 sm:p-10 bg-gradient-to-b from-slate-950 via-blue-950 to-slate-950 text-white rounded-2xl border-4 border-amber-500/30 shadow-2xl overflow-hidden select-none">
      {/* Decorative Gold Filigree Corner Accents */}
      <div className="absolute top-4 left-4 w-12 h-12 border-t-2 border-l-2 border-amber-400/60 rounded-tl-lg pointer-events-none" />
      <div className="absolute top-4 right-4 w-12 h-12 border-t-2 border-r-2 border-amber-400/60 rounded-tr-lg pointer-events-none" />
      <div className="absolute bottom-4 left-4 w-12 h-12 border-b-2 border-l-2 border-amber-400/60 rounded-bl-lg pointer-events-none" />
      <div className="absolute bottom-4 right-4 w-12 h-12 border-b-2 border-r-2 border-amber-400/60 rounded-br-lg pointer-events-none" />

      {/* Subtle Background Ornament */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(30,64,175,0.25)_0,transparent_70%)] pointer-events-none" />

      {/* Top Emblem & Location */}
      <div className="relative z-10 text-center space-y-1.5 pt-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-900/60 border border-blue-700/60 text-amber-300 text-xs font-semibold tracking-widest uppercase">
          <Award className="w-3.5 h-3.5" />
          Multi-Brand Digital Showroom
        </div>
        <p className="text-xs sm:text-sm text-slate-300 flex items-center justify-center gap-1">
          <MapPin className="w-3.5 h-3.5 text-blue-400" />
          Tyoda Road, Ganj Basoda (Dist. Vidisha, MP)
        </p>
      </div>

      {/* Centerpiece Book Title & Royal Hindi Branding */}
      <div className="relative z-10 text-center space-y-4 max-w-xl">
        <div className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-tr from-blue-700 via-blue-600 to-indigo-500 p-1 shadow-xl shadow-blue-900/50 flex items-center justify-center">
          <div className="w-full h-full rounded-xl bg-slate-950 flex items-center justify-center text-3xl font-serif-display font-extrabold text-amber-400">
            M
          </div>
        </div>

        <div className="space-y-1">
          <h1 className="text-3xl sm:text-5xl md:text-6xl font-black font-serif-display tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-400 drop-shadow-md">
            MERU MOBILE SHOP
          </h1>
          <div className="flex items-center justify-center gap-2 pt-1">
            <span className="h-[1px] w-12 bg-amber-400/40" />
            <h2 className="text-xl sm:text-2xl font-bold font-hindi text-white tracking-wide">
              {settings.brand_tagline}
            </h2>
            <span className="h-[1px] w-12 bg-amber-400/40" />
          </div>
        </div>

        <p className="text-xs sm:text-sm text-blue-200 tracking-wider font-medium">
          Mobile • Genuine Accessories • 0% Finance • Festive Offers
        </p>

        {/* Primary OPEN SHOP Button */}
        <div className="pt-4">
          <button
            onClick={onOpenShop}
            className="group relative inline-flex items-center gap-3 px-8 sm:px-10 py-4 bg-gradient-to-r from-blue-600 via-blue-500 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black text-sm sm:text-base rounded-2xl shadow-xl shadow-blue-900/60 border border-blue-400/30 transition-all hover:scale-105 active:scale-95 cursor-pointer"
          >
            <BookOpen className="w-5 h-5 text-amber-300 group-hover:rotate-12 transition-transform" />
            <span>OPEN SHOP</span>
            <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>

      {/* Bottom Quick-Action Buttons */}
      <div className="relative z-10 w-full max-w-2xl pt-6">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <button
            onClick={() => onNavigate(5)}
            className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-blue-950 border border-slate-800 hover:border-blue-600/50 text-center transition-all flex flex-col items-center gap-1 group"
          >
            <Smartphone className="w-4 h-4 text-blue-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-bold text-white uppercase tracking-wider">
              SHOP PHONES
            </span>
          </button>

          <button
            onClick={() => onNavigate(3)}
            className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-blue-950 border border-slate-800 hover:border-blue-600/50 text-center transition-all flex flex-col items-center gap-1 group"
          >
            <Tag className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-bold text-white uppercase tracking-wider">
              TODAY'S OFFERS
            </span>
          </button>

          <button
            onClick={() => onNavigate(17)}
            className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-blue-950 border border-slate-800 hover:border-amber-500/50 text-center transition-all flex flex-col items-center gap-1 group"
          >
            <Gift className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
              LUCKY DRAW
            </span>
          </button>

          <button
            onClick={() => onNavigate(18)}
            className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-blue-950 border border-slate-800 hover:border-blue-600/50 text-center transition-all flex flex-col items-center gap-1 group"
          >
            <CreditCard className="w-4 h-4 text-blue-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-bold text-white uppercase tracking-wider">
              0% FINANCE
            </span>
          </button>
        </div>

        <div className="text-center text-[10px] text-slate-500 pt-4 font-mono">
          Owner: {settings.owner_name} • Ganj Basoda (Pincode: 464221)
        </div>
      </div>
    </div>
  );
};
