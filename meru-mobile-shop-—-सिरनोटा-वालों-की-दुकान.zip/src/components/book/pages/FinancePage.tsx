import React, { useState } from 'react';
import { CreditCard, Calculator, ShieldAlert, ChevronRight, CheckCircle2, FileText, ArrowRight } from 'lucide-react';
import { FinanceProvider } from '../../../types/database';
import { formatPrice } from '../../../utils/formatters';

interface FinancePageProps {
  providers: FinanceProvider[];
  onCheckProcess: () => void;
  onOpenEnquiry: () => void;
}

export const FinancePage: React.FC<FinancePageProps> = ({
  providers,
  onCheckProcess,
  onOpenEnquiry,
}) => {
  const [devicePrice, setDevicePrice] = useState<number>(30000);
  const [tenure, setTenure] = useState<number>(6);
  const [downPayment, setDownPayment] = useState<number>(0);

  const loanAmount = Math.max(0, devicePrice - downPayment);
  const estimatedEmi = Math.round(loanAmount / tenure);

  return (
    <div className="min-h-[600px] flex flex-col justify-between p-5 sm:p-8 bg-slate-900/90 text-slate-100 rounded-2xl border border-slate-800 space-y-6">
      {/* Chapter Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs">
            18
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
            Chapter VI • 0% Easy EMI Finance
          </span>
        </div>
        <span className="text-xs font-hindi text-amber-400 font-medium">
          सिरनोटा वालों की दुकान
        </span>
      </div>

      <div className="space-y-5">
        <div>
          <h2 className="text-2xl font-black text-white font-serif-display">
            Instant 0% EMI Finance Schemes
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Buy your dream phone today and pay in easy monthly installments. Paperless in-store verification in just 15 minutes.
          </p>
        </div>

        {/* Interactive EMI Calculator */}
        <div className="p-4 sm:p-5 bg-slate-950 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <Calculator className="w-4 h-4 text-blue-400" />
              Interactive EMI Calculator
            </h3>
            <span className="text-[11px] text-emerald-400 font-semibold">0% No Cost Schemes</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400">Device Price:</span>
                  <span className="font-bold text-white">{formatPrice(devicePrice)}</span>
                </div>
                <input
                  type="range"
                  min="8000"
                  max="150000"
                  step="1000"
                  value={devicePrice}
                  onChange={(e) => setDevicePrice(Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400">Down Payment (₹):</span>
                  <span className="font-bold text-white">{formatPrice(downPayment)}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max={devicePrice * 0.7}
                  step="500"
                  value={downPayment}
                  onChange={(e) => setDownPayment(Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>

              <div>
                <span className="text-xs text-slate-400 block mb-1">Tenure (Months):</span>
                <div className="grid grid-cols-4 gap-1.5">
                  {[3, 6, 8, 12].map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setTenure(m)}
                      className={`py-1.5 text-xs font-bold rounded-lg border transition-all ${
                        tenure === m
                          ? 'bg-blue-600 text-white border-blue-500 shadow'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      {m} Mo
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Calculated Box */}
            <div className="p-4 bg-gradient-to-br from-blue-950/80 to-slate-900 rounded-xl border border-blue-800/60 flex flex-col justify-between space-y-3">
              <div className="space-y-1">
                <span className="text-[11px] text-blue-300 uppercase font-semibold">
                  Estimated Monthly Installment
                </span>
                <div className="text-3xl font-black text-white">
                  {formatPrice(estimatedEmi)}
                  <span className="text-xs font-normal text-slate-400"> /month</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Loan Amount: {formatPrice(loanAmount)} for {tenure} months
                </p>
              </div>

              <button
                type="button"
                onClick={onOpenEnquiry}
                className="w-full py-2.5 px-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all shadow-md active:scale-95"
              >
                Consult Finance Desk for This Scheme
              </button>
            </div>
          </div>
        </div>

        {/* Finance Providers Logos & Schemes */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-white">Authorized In-Store Finance Partners:</span>
            <span className="text-slate-400">Ganj Basoda Showroom Desk</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {providers.map((p) => (
              <div
                key={p.id}
                className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1"
              >
                <div className="font-bold text-xs text-white">{p.name}</div>
                <div className="text-[11px] text-emerald-400 font-semibold">{p.interest_rate_from}</div>
                <div className="text-[10px] text-slate-400 line-clamp-1">{p.tenure_options}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Mandatory Regulatory Disclaimer */}
        <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-start gap-2.5 text-xs text-amber-300">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p>
            <span className="font-bold">Important Notice:</span> Final eligibility, interest waiver, down payment, and loan approval are subject strictly to the finance provider's credit bureau evaluation and underwriting rules in-store.
          </p>
        </div>
      </div>

      {/* Footer Navigation CTA */}
      <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
        <span className="text-xs text-slate-400">
          Required: Aadhaar + PAN + Bank passbook
        </span>
        <button
          onClick={onCheckProcess}
          className="inline-flex items-center gap-1.5 text-xs text-blue-400 hover:text-white font-semibold"
        >
          <span>See How Finance Works (Page 19)</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
