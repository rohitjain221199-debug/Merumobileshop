import React from 'react';
import { Award, ShieldCheck, HeartHandshake, MapPin, Phone, Users, ChevronRight } from 'lucide-react';
import { SiteSettings } from '../../../types/database';

interface AboutPageProps {
  settings: SiteSettings;
  onExploreCatalog: () => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({
  settings,
  onExploreCatalog,
}) => {
  return (
    <div className="min-h-[600px] flex flex-col justify-between p-5 sm:p-8 bg-slate-900/90 text-slate-100 rounded-2xl border border-slate-800 space-y-6">
      {/* Chapter Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs">
            23
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
            Chapter XI • Legacy & Heritage
          </span>
        </div>
        <span className="text-xs font-hindi text-amber-400 font-medium">
          सिरनोटा वालों की दुकान
        </span>
      </div>

      <div className="space-y-4">
        <div>
          <h2 className="text-2xl font-black text-white font-serif-display">
            The Story of सिरनोटा वालों की दुकान
          </h2>
          <p className="text-xs text-blue-300 font-hindi mt-1">
            गंज बासोदा में विश्वास, सम्मान और तकनीकी सेवा का 15+ वर्षों का अटूट रिश्ता
          </p>
        </div>

        {/* Founder Bio Card */}
        <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col sm:flex-row items-center gap-4">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-blue-700 via-indigo-700 to-slate-900 p-1 shrink-0 flex items-center justify-center text-2xl font-bold font-serif-display text-amber-400 border border-amber-500/30 shadow-lg">
            MJ
          </div>
          <div className="space-y-1 text-center sm:text-left">
            <div className="flex items-center justify-center sm:justify-start gap-2">
              <h3 className="text-base font-bold text-white">{settings.owner_name}</h3>
              <span className="text-[10px] bg-blue-900/60 text-blue-300 px-2 py-0.5 rounded border border-blue-700/50">
                Founder & Owner
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              "Humare yahan har customer sirf ek grahak nahi, parivaar jaisa hai. Sealed-pack mobile, pakka bill, aur sahi daam — yehi humari pehchan hai."
            </p>
          </div>
        </div>

        {/* Narrative */}
        <div className="text-xs text-slate-300 space-y-2 leading-relaxed">
          <p>
            Established on Tyoda Road, near Pawan Auto Mobile and Old Bus Stand in Ganj Basoda, <span className="text-white font-semibold">Meru Mobile Shop</span> has grown to become the region's premier technology destination.
          </p>
          <p>
            From the initial era of keypad handsets to today's high-speed 5G AI smartphones, we have continuously bridged modern technology with warm, honest small-town relationships. Customers from Ganj Basoda, Tyoda, Kurwai, Gyaraspur, and rural Vidisha visit us for dependable advice.
          </p>
        </div>

        {/* 3 Core Values */}
        <div className="grid grid-cols-3 gap-2.5 pt-2">
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-center space-y-1">
            <ShieldCheck className="w-5 h-5 text-emerald-400 mx-auto" />
            <div className="text-xs font-bold text-white">Genuine Stock</div>
            <div className="text-[10px] text-slate-400">100% Brand Sealed</div>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-center space-y-1">
            <Award className="w-5 h-5 text-amber-400 mx-auto" />
            <div className="text-xs font-bold text-white">0% Finance</div>
            <div className="text-[10px] text-slate-400">All Major NBFCs</div>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-center space-y-1">
            <HeartHandshake className="w-5 h-5 text-blue-400 mx-auto" />
            <div className="text-xs font-bold text-white">After-Sale Care</div>
            <div className="text-[10px] text-slate-400">Lifetime Friendly Help</div>
          </div>
        </div>
      </div>

      {/* Footer Navigation CTA */}
      <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
        <span>Ganj Basoda, Vidisha (MP) - 464221</span>
        <button
          onClick={onExploreCatalog}
          className="inline-flex items-center gap-1.5 text-blue-400 hover:text-white font-semibold"
        >
          <span>Explore Showroom Catalogue</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
