import React from 'react';
import { Sparkles, ShieldCheck, CheckCircle2, ChevronRight, Award, Zap, HeartHandshake } from 'lucide-react';
import { SiteSettings, Banner } from '../../../types/database';

interface WelcomePageProps {
  settings: SiteSettings;
  banners: Banner[];
  onExplorePhones: () => void;
  onExploreFinance: () => void;
}

export const WelcomePage: React.FC<WelcomePageProps> = ({
  settings,
  banners,
  onExplorePhones,
  onExploreFinance,
}) => {
  const activeBanner = banners.find((b) => b.is_active) || banners[0];

  return (
    <div className="min-h-[600px] flex flex-col justify-between p-5 sm:p-8 bg-slate-900/90 text-slate-100 rounded-2xl border border-slate-800 space-y-6">
      {/* Chapter Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs">
            02
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
            Chapter I • Introduction
          </span>
        </div>
        <span className="text-xs font-hindi text-amber-400 font-medium">
          सिरनोटा वालों की दुकान
        </span>
      </div>

      {/* Main Hero & Story */}
      <div className="space-y-4">
        <div className="space-y-1.5">
          <h2 className="text-2xl sm:text-3xl font-black text-white font-serif-display">
            Welcome to Meru Mobile Shop
          </h2>
          <p className="text-xs sm:text-sm text-blue-300 font-hindi font-medium">
            गंज बासोदा और विदिशा जिले का सबसे विश्वसनीय मोबाइल व इलेक्ट्रॉनिक्स शोरूम
          </p>
        </div>

        {/* Feature Highlight Banner */}
        {activeBanner && (
          <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 aspect-[16/7] flex items-end p-4 shadow-lg group">
            <img
              src={activeBanner.image_url}
              alt={activeBanner.title}
              className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />
            <div className="relative z-10 space-y-1">
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-blue-600 text-white">
                Featured Showroom
              </span>
              <h3 className="text-sm sm:text-base font-bold text-white line-clamp-1">
                {activeBanner.title}
              </h3>
              <p className="text-xs text-slate-300 line-clamp-1">{activeBanner.subtitle}</p>
            </div>
          </div>
        )}

        <p className="text-xs text-slate-300 leading-relaxed">
          {settings.about_text}
        </p>

        {/* The 4 Pillars of Meru Mobile */}
        <div className="grid grid-cols-2 gap-2.5 pt-2">
          <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80 space-y-1">
            <div className="flex items-center gap-1.5 text-blue-400 font-semibold text-xs">
              <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0" />
              <span>100% Genuine Bills</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Direct brand-authorized stock with official manufacturer warranty.
            </p>
          </div>

          <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80 space-y-1">
            <div className="flex items-center gap-1.5 text-amber-400 font-semibold text-xs">
              <Zap className="w-4 h-4 text-amber-400 shrink-0" />
              <span>15-Min 0% EMI</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Bajaj, HDB, IDFC & TVS Credit with minimal Aadhaar/PAN documentation.
            </p>
          </div>

          <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80 space-y-1">
            <div className="flex items-center gap-1.5 text-emerald-400 font-semibold text-xs">
              <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Festive Lucky Draw</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Assured gift tickets with every smartphone purchase in store.
            </p>
          </div>

          <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80 space-y-1">
            <div className="flex items-center gap-1.5 text-indigo-400 font-semibold text-xs">
              <HeartHandshake className="w-4 h-4 text-indigo-400 shrink-0" />
              <span>Local Trust & Care</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Free data transfer, tempered glass fitting, and friendly after-sales support.
            </p>
          </div>
        </div>
      </div>

      {/* Footer Navigation CTA */}
      <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
        <button
          onClick={onExploreFinance}
          className="text-xs text-slate-400 hover:text-white font-medium"
        >
          Check 0% EMI Schemes →
        </button>

        <button
          onClick={onExplorePhones}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-900/30 transition-all active:scale-95"
        >
          <span>Explore Smartphones</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
