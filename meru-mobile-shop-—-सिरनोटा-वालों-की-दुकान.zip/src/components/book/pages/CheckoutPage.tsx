import React, { useState } from 'react';
import { Truck, CheckCircle2, ShieldCheck, MapPin, Phone, User, CreditCard, ArrowRight, QrCode } from 'lucide-react';
import { CartItem, SiteSettings, Order, PaymentMethod } from '../../../types/database';
import { formatPrice } from '../../../utils/formatters';
import { StoreService } from '../../../services/storeService';

interface CheckoutPageProps {
  cart: CartItem[];
  settings: SiteSettings;
  onOrderSuccess: (order: Order) => void;
  onNavigateToPage: (page: number) => void;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({
  cart,
  settings,
  onOrderSuccess,
  onNavigateToPage,
}) => {
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [addressLine1, setAddressLine1] = useState('');
  const [landmark, setLandmark] = useState('');
  const [city, setCity] = useState('Ganj Basoda');
  const [pincode, setPincode] = useState('464221');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('COD');
  const [orderNotes, setOrderNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  const subtotal = cart.reduce((acc, item) => acc + item.variant.selling_price * item.quantity, 0);
  const deliveryCharge = subtotal >= settings.free_delivery_above || subtotal === 0 ? 0 : 50;
  const finalAmount = subtotal + deliveryCharge;

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !phone || !addressLine1) return;

    setIsSubmitting(true);

    const orderItems = cart.map((item) => ({
      id: `item-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      order_id: '',
      product_id: item.product_id,
      product_name: item.product.name,
      variant_id: item.variant_id,
      variant_description: `${item.variant.color_name}${item.variant.ram ? ` - ${item.variant.ram}/${item.variant.storage}` : ''}`,
      image_url: item.variant.image_url || item.product.primary_image,
      price: item.variant.selling_price,
      mrp: item.variant.mrp,
      quantity: item.quantity,
      subtotal: item.variant.selling_price * item.quantity,
    }));

    const newOrder = await StoreService.createOrder({
      customer_name: fullName,
      customer_phone: phone,
      customer_email: email || undefined,
      items: orderItems,
      shipping_address: {
        id: `addr-${Date.now()}`,
        full_name: fullName,
        phone,
        address_line1: addressLine1,
        landmark: landmark || undefined,
        city,
        state: 'Madhya Pradesh',
        pincode,
      },
      subtotal,
      discount_amount: 0,
      delivery_charge: deliveryCharge,
      final_amount: finalAmount,
      payment_method: paymentMethod,
      payment_status: paymentMethod === 'STORE_PICKUP_PAY' ? 'pending' : 'pending',
      order_status: 'Pending',
      order_notes: orderNotes || undefined,
    });

    setIsSubmitting(false);
    setCreatedOrder(newOrder);
    onOrderSuccess(newOrder);
  };

  return (
    <div className="min-h-[600px] flex flex-col justify-between p-5 sm:p-8 bg-slate-900/90 text-slate-100 rounded-2xl border border-slate-800 space-y-6">
      {/* Chapter Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs">
            21
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
            Chapter IX • Checkout & Store Reservation
          </span>
        </div>
        <span className="text-xs font-hindi text-amber-400 font-medium">
          सिरनोटा वालों की दुकान
        </span>
      </div>

      <div className="space-y-4">
        {createdOrder ? (
          /* Order Confirmation Screen */
          <div className="p-6 bg-slate-950 rounded-2xl border border-emerald-500/50 text-center space-y-4 shadow-xl">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h3 className="text-xl font-bold text-white">Order Registered Successfully!</h3>
              <p className="text-xs text-slate-300">
                Your device has been reserved at Meru Mobile Shop showroom.
              </p>
            </div>

            <div className="p-3 bg-slate-900 max-w-sm mx-auto rounded-xl border border-slate-800 text-xs space-y-1">
              <div className="text-slate-400">Order Number:</div>
              <div className="font-mono text-base font-extrabold text-blue-400">
                {createdOrder.order_number}
              </div>
              <div className="text-slate-400 pt-1">
                Final Amount: <span className="text-white font-bold">{formatPrice(createdOrder.final_amount)}</span> ({createdOrder.payment_method})
              </div>
            </div>

            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Maneesh Jain will confirm device availability and delivery time via WhatsApp or call to{' '}
              <span className="text-white font-semibold">{createdOrder.customer_phone}</span>.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <button
                onClick={() => onNavigateToPage(25)}
                className="w-full sm:w-auto px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all shadow-md"
              >
                Track Live Order (Page 25)
              </button>

              <button
                onClick={() => onNavigateToPage(5)}
                className="w-full sm:w-auto px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-medium"
              >
                Return to Shop
              </button>
            </div>
          </div>
        ) : cart.length === 0 ? (
          <div className="py-16 text-center text-slate-400 space-y-2">
            <p className="text-xs">No items in bag to checkout.</p>
            <button
              onClick={() => onNavigateToPage(20)}
              className="text-xs text-blue-400 font-semibold"
            >
              Go to Bag (Page 20)
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmitOrder} className="space-y-4">
            <div>
              <h2 className="text-xl font-bold text-white">Delivery Address & Contact</h2>
              <p className="text-xs text-slate-400">
                Enter your Ganj Basoda address or specify Showroom Pickup on Tyoda Road.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Customer Info */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
                <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-blue-400" />
                  Customer Details
                </h3>

                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Ramesh Kumar"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] text-slate-300 mb-1">Mobile (WhatsApp) *</label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="10-digit number"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-300 mb-1">Email (Optional)</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="For invoice copy"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">Address / Street *</label>
                  <input
                    type="text"
                    required
                    value={addressLine1}
                    onChange={(e) => setAddressLine1(e.target.value)}
                    placeholder="House / Shop no., Road or Mohalla"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[11px] text-slate-300 mb-1">Landmark</label>
                    <input
                      type="text"
                      value={landmark}
                      onChange={(e) => setLandmark(e.target.value)}
                      placeholder="e.g. Near Temple"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-300 mb-1">City</label>
                    <input
                      type="text"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-300 mb-1">Pincode</label>
                    <input
                      type="text"
                      value={pincode}
                      onChange={(e) => setPincode(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Payment Method & Order Review */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3 flex flex-col justify-between">
                <div className="space-y-3">
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <CreditCard className="w-3.5 h-3.5 text-blue-400" />
                    Payment Options
                  </h3>

                  <div className="space-y-2">
                    <label
                      className={`p-3 rounded-xl border flex items-center gap-3 cursor-pointer transition-all ${
                        paymentMethod === 'COD'
                          ? 'bg-blue-950/60 border-blue-500 text-white ring-1 ring-blue-500'
                          : 'bg-slate-900 border-slate-800 text-slate-300'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        checked={paymentMethod === 'COD'}
                        onChange={() => setPaymentMethod('COD')}
                        className="accent-blue-600"
                      />
                      <div>
                        <div className="text-xs font-bold">Cash on Delivery (COD)</div>
                        <div className="text-[11px] text-slate-400">
                          Pay cash or UPI upon doorstep delivery in Ganj Basoda.
                        </div>
                      </div>
                    </label>

                    <label
                      className={`p-3 rounded-xl border flex items-center gap-3 cursor-pointer transition-all ${
                        paymentMethod === 'STORE_PICKUP_PAY'
                          ? 'bg-blue-950/60 border-blue-500 text-white ring-1 ring-blue-500'
                          : 'bg-slate-900 border-slate-800 text-slate-300'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        checked={paymentMethod === 'STORE_PICKUP_PAY'}
                        onChange={() => setPaymentMethod('STORE_PICKUP_PAY')}
                        className="accent-blue-600"
                      />
                      <div>
                        <div className="text-xs font-bold">In-Store Collection & Pay (Tyoda Road)</div>
                        <div className="text-[11px] text-slate-400">
                          Reserve sealed device; pay via Cash, Card, 0% EMI or UPI at shop.
                        </div>
                      </div>
                    </label>

                    <label
                      className={`p-3 rounded-xl border flex items-center gap-3 cursor-pointer transition-all ${
                        paymentMethod === 'UPI_QR'
                          ? 'bg-blue-950/60 border-blue-500 text-white ring-1 ring-blue-500'
                          : 'bg-slate-900 border-slate-800 text-slate-300'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        checked={paymentMethod === 'UPI_QR'}
                        onChange={() => setPaymentMethod('UPI_QR')}
                        className="accent-blue-600"
                      />
                      <div>
                        <div className="text-xs font-bold">Manual Shop UPI QR / Advance</div>
                        <div className="text-[11px] text-slate-400">
                          Scan Meru Mobile Shop's verified merchant QR during order verification.
                        </div>
                      </div>
                    </label>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-300 mb-1">
                      Order Notes (Optional)
                    </label>
                    <input
                      type="text"
                      value={orderNotes}
                      onChange={(e) => setOrderNotes(e.target.value)}
                      placeholder="e.g. Please bring tempered glass and data cable along"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-900 space-y-2">
                  <div className="flex justify-between text-xs text-slate-300">
                    <span>Payable Total ({cart.length} items):</span>
                    <span className="font-extrabold text-white text-sm">
                      {formatPrice(finalAmount)}
                    </span>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-blue-900/40 transition-all active:scale-95 cursor-pointer"
                  >
                    <span>{isSubmitting ? 'Registering Order...' : 'CONFIRM ORDER & RESERVE'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </form>
        )}
      </div>

      {/* Footer Navigation CTA */}
      <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
        <button
          onClick={() => onNavigateToPage(20)}
          className="text-slate-400 hover:text-white"
        >
          ← Back to Bag (Page 20)
        </button>

        <span className="font-hindi text-amber-400">
          सिरनोटा वालों की दुकान — गंज बासोदा
        </span>
      </div>
    </div>
  );
};
