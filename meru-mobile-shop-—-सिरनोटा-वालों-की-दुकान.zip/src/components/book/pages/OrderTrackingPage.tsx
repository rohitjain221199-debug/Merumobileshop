import React, { useState } from 'react';
import { Search, PackageCheck, Clock, CheckCircle2, Truck, Check, AlertCircle, Phone } from 'lucide-react';
import { StoreService } from '../../../services/storeService';
import { Order, OrderStatus } from '../../../types/database';
import { formatPrice, formatDate } from '../../../utils/formatters';

interface OrderTrackingPageProps {
  onNavigateToPage: (page: number) => void;
}

export const OrderTrackingPage: React.FC<OrderTrackingPageProps> = ({
  onNavigateToPage,
}) => {
  const [orderQuery, setOrderQuery] = useState('MERU-2025-1001');
  const [searchedOrder, setSearchedOrder] = useState<Order | undefined>(
    StoreService.getOrderById('MERU-2025-1001') || StoreService.getOrders()[0]
  );
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const found = StoreService.getOrderById(orderQuery.trim());
    if (found) {
      setSearchedOrder(found);
    } else {
      setSearchedOrder(undefined);
      setErrorMsg(`No order found matching "${orderQuery}". Please check your order ID or mobile number.`);
    }
  };

  const TRACKING_STAGES: { status: OrderStatus; label: string }[] = [
    { status: 'Pending', label: 'Order Registered' },
    { status: 'Confirmed', label: 'Showroom Stock Reserved' },
    { status: 'Processing', label: 'Verified by Maneesh Jain' },
    { status: 'Packed', label: 'Packed with Warranty Bill' },
    { status: 'Out for Delivery', label: 'Out for Delivery' },
    { status: 'Delivered', label: 'Delivered / Collected' },
  ];

  const getStageIndex = (status: OrderStatus): number => {
    const idx = TRACKING_STAGES.findIndex((s) => s.status === status);
    if (idx !== -1) return idx;
    if (status === 'Shipped') return 4;
    return 0;
  };

  const currentStageIdx = searchedOrder ? getStageIndex(searchedOrder.order_status) : -1;

  return (
    <div className="min-h-[600px] flex flex-col justify-between p-5 sm:p-8 bg-slate-900/90 text-slate-100 rounded-2xl border border-slate-800 space-y-6">
      {/* Chapter Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs">
            25
          </span>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
            Chapter XIII • Live Order Status & Tracking
          </span>
        </div>
        <span className="text-xs font-hindi text-amber-400 font-medium">
          सिरनोटा वालों की दुकान
        </span>
      </div>

      <div className="space-y-5">
        <div>
          <h2 className="text-2xl font-black text-white font-serif-display">
            Live Order Tracking
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Check the real-time progress of your device reservation or delivery order.
          </p>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="max-w-xl">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
              <input
                type="text"
                value={orderQuery}
                onChange={(e) => setOrderQuery(e.target.value)}
                placeholder="Enter Order ID (e.g. MERU-2025-1001)"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white uppercase font-mono placeholder:normal-case placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>
            <button
              type="submit"
              className="py-2.5 px-5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shrink-0"
            >
              Track Order
            </button>
          </div>
          {errorMsg && (
            <p className="text-xs text-red-400 mt-1.5 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" />
              {errorMsg}
            </p>
          )}
        </form>

        {/* Order Details & Visual Timeline */}
        {searchedOrder && (
          <div className="p-4 sm:p-6 bg-slate-950 rounded-2xl border border-slate-800 space-y-5 shadow-lg">
            {/* Top Order Overview Banner */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-900">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400">Order ID:</span>
                  <span className="font-mono text-sm font-extrabold text-white">
                    {searchedOrder.order_number}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-blue-900/60 text-blue-300 font-bold border border-blue-700/50">
                    {searchedOrder.order_status}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Placed on {formatDate(searchedOrder.created_at)} • Customer: {searchedOrder.customer_name} ({searchedOrder.customer_phone})
                </div>
              </div>

              <div className="text-right">
                <div className="text-xs text-slate-400">Total Amount:</div>
                <div className="text-base font-black text-blue-400">
                  {formatPrice(searchedOrder.final_amount)}
                </div>
                <div className="text-[10px] text-slate-500 uppercase font-medium">
                  {searchedOrder.payment_method} ({searchedOrder.payment_status})
                </div>
              </div>
            </div>

            {/* Visual Tracking Timeline */}
            <div className="py-2">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
                Shipment / Handover Progress
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                {TRACKING_STAGES.map((stage, idx) => {
                  const isCompleted = idx <= currentStageIdx;
                  const isCurrent = idx === currentStageIdx;

                  return (
                    <div
                      key={stage.status}
                      className={`p-3 rounded-xl border text-center space-y-1.5 transition-all ${
                        isCurrent
                          ? 'bg-blue-950/80 border-blue-500 ring-1 ring-blue-500 text-white'
                          : isCompleted
                          ? 'bg-slate-900 border-emerald-500/40 text-slate-200'
                          : 'bg-slate-900/40 border-slate-900 text-slate-600'
                      }`}
                    >
                      <div
                        className={`w-6 h-6 mx-auto rounded-full flex items-center justify-center text-xs font-bold ${
                          isCompleted
                            ? 'bg-emerald-500 text-slate-950'
                            : 'bg-slate-800 text-slate-500'
                        }`}
                      >
                        {isCompleted ? <Check className="w-3.5 h-3.5" /> : idx + 1}
                      </div>
                      <div className="text-[11px] font-bold leading-tight">
                        {stage.label}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Status History Logs */}
            {searchedOrder.status_history && searchedOrder.status_history.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-slate-900">
                <h5 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  Timeline Activity Log:
                </h5>
                <div className="space-y-1.5">
                  {searchedOrder.status_history.map((hist) => (
                    <div
                      key={hist.id}
                      className="text-xs flex items-start gap-2 bg-slate-900/60 p-2 rounded-lg"
                    >
                      <Clock className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold text-white">{hist.status}</span>
                        {hist.note && (
                          <span className="text-slate-300 ml-1.5">— {hist.note}</span>
                        )}
                        <span className="text-[10px] text-slate-500 ml-2">
                          ({formatDate(hist.created_at)})
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Items inside order */}
            <div className="space-y-2 pt-2 border-t border-slate-900">
              <h5 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Order Items:
              </h5>
              <div className="space-y-1.5">
                {searchedOrder.items.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between text-xs bg-slate-900/60 p-2.5 rounded-xl"
                  >
                    <div className="flex items-center gap-2.5">
                      <img
                        src={item.image_url}
                        alt={item.product_name}
                        className="w-8 h-8 object-contain rounded"
                      />
                      <div>
                        <div className="font-bold text-white">{item.product_name}</div>
                        <div className="text-[10px] text-slate-400">
                          {item.variant_description} × {item.quantity}
                        </div>
                      </div>
                    </div>
                    <div className="font-bold text-white">
                      {formatPrice(item.subtotal)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Navigation CTA */}
      <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
        <span className="font-hindi text-amber-400">
          सिरनोटा वालों की दुकान — गंज बासोदा
        </span>
        <button
          onClick={() => onNavigateToPage(5)}
          className="text-blue-400 hover:text-white font-medium"
        >
          Return to Showroom Catalogue →
        </button>
      </div>
    </div>
  );
};
