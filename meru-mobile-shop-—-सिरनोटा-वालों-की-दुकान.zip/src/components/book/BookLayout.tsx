import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  BookOpen,
  Sliders,
  Eye,
  Maximize2,
  Minimize2,
  Sparkles,
} from 'lucide-react';
import { BookPageConfig, SiteSettings } from '../../types/database';

interface BookLayoutProps {
  currentPage: number;
  totalPages: number;
  bookPages: BookPageConfig[];
  onPageChange: (newPage: number) => void;
  renderPageContent: (pageNumber: number) => React.ReactNode;
  settings: SiteSettings;
}

export const BookLayout: React.FC<BookLayoutProps> = ({
  currentPage,
  totalPages,
  bookPages,
  onPageChange,
  renderPageContent,
  settings,
}) => {
  const [isReducedMotion, setIsReducedMotion] = useState(false);
  const [isTwoPageDesktop, setIsTwoPageDesktop] = useState(true);
  const touchStartXRef = useRef<number | null>(null);

  // Auto handle viewport width for 2-page vs 1-page layout
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1024) {
        setIsTwoPageDesktop(false);
      } else {
        setIsTwoPageDesktop(true);
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Keyboard navigation (ArrowLeft & ArrowRight)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing in an input or textarea
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement ||
        e.target instanceof HTMLSelectElement
      ) {
        return;
      }

      if (e.key === 'ArrowRight') {
        goToNext();
      } else if (e.key === 'ArrowLeft') {
        goToPrev();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentPage, isTwoPageDesktop]);

  const goToNext = () => {
    const step = isTwoPageDesktop && currentPage > 1 ? 2 : 1;
    const next = Math.min(totalPages, currentPage + step);
    if (next !== currentPage) onPageChange(next);
  };

  const goToPrev = () => {
    const step = isTwoPageDesktop && currentPage > 2 ? 2 : 1;
    const prev = Math.max(1, currentPage - step);
    if (prev !== currentPage) onPageChange(prev);
  };

  // Touch Swipe Handling for Mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartXRef.current === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchStartXRef.current - touchEndX;

    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        // Swiped Left -> Go Next Page
        goToNext();
      } else {
        // Swiped Right -> Go Prev Page
        goToPrev();
      }
    }
    touchStartXRef.current = null;
  };

  // For 2-page spread on desktop:
  // If currentPage is 1 (Cover), it renders alone as a single grand hardbound book cover.
  // If currentPage > 1, left page is currentPage (if even) or currentPage-1, and right page is left+1.
  const isCover = currentPage === 1;

  let leftPageNum = currentPage;
  let rightPageNum = currentPage + 1;

  if (isTwoPageDesktop && !isCover) {
    if (currentPage % 2 !== 0) {
      // e.g. on page 3: left is 2, right is 3
      leftPageNum = currentPage - 1;
      rightPageNum = currentPage;
    } else {
      // e.g. on page 2: left is 2, right is 3
      leftPageNum = currentPage;
      rightPageNum = currentPage + 1;
    }
  }

  return (
    <div className="w-full max-w-7xl mx-auto px-2 sm:px-4 py-4 sm:py-6 flex flex-col items-center">
      {/* Top Book Control & Accessibility Bar */}
      <div className="w-full flex items-center justify-between pb-3 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <span className="font-hindi text-amber-400 font-bold hidden sm:inline">
            ★ {settings.brand_tagline}
          </span>
          <span className="text-slate-600 hidden sm:inline">•</span>
          <span className="text-slate-300 font-medium">
            {isCover
              ? 'Book Cover (Page 1 of 26)'
              : isTwoPageDesktop
              ? `Spreads: Page ${leftPageNum} & ${Math.min(totalPages, rightPageNum)} of ${totalPages}`
              : `Page ${currentPage} of ${totalPages}`}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Reduced motion toggle */}
          <button
            type="button"
            onClick={() => setIsReducedMotion(!isReducedMotion)}
            className={`px-2 py-1 rounded-lg border text-[11px] transition-colors ${
              isReducedMotion
                ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
            }`}
            title="Toggle Page Turning Animations"
          >
            {isReducedMotion ? 'Motion: Off' : 'Motion: Smooth'}
          </button>

          {/* Spread mode toggle on large screens */}
          <button
            type="button"
            onClick={() => setIsTwoPageDesktop(!isTwoPageDesktop)}
            className="hidden lg:flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-[11px]"
            title="Toggle 2-Page Spread vs Single Page"
          >
            {isTwoPageDesktop ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            <span>{isTwoPageDesktop ? 'Single Page' : 'Two-Page Spread'}</span>
          </button>
        </div>
      </div>

      {/* Main Interactive Book Spread Viewport */}
      <div
        className="w-full relative select-none"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {/* Left Page Turn Button (Desktop overlay or side) */}
        {currentPage > 1 && (
          <button
            type="button"
            onClick={goToPrev}
            className="absolute -left-3 sm:-left-6 top-1/2 -translate-y-1/2 z-30 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-slate-900/90 hover:bg-blue-600 text-white border border-slate-700/80 hover:border-blue-500 flex items-center justify-center shadow-xl shadow-black/80 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            title="Previous Page (Left Arrow)"
            aria-label="Previous Page"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        {/* Right Page Turn Button (Desktop overlay or side) */}
        {currentPage < totalPages && (
          <button
            type="button"
            onClick={goToNext}
            className="absolute -right-3 sm:-right-6 top-1/2 -translate-y-1/2 z-30 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-slate-900/90 hover:bg-blue-600 text-white border border-slate-700/80 hover:border-blue-500 flex items-center justify-center shadow-xl shadow-black/80 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            title="Next Page (Right Arrow)"
            aria-label="Next Page"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}

        {/* Book Container with Realistic Spine and Paper Crease */}
        <div className="relative w-full rounded-3xl bg-slate-950 p-2 sm:p-3 border-2 border-slate-800 shadow-2xl book-shadow perspective-book overflow-hidden">
          {/* Cover View Mode */}
          {isCover ? (
            <div className="w-full max-w-2xl mx-auto transition-transform duration-300">
              {renderPageContent(1)}
            </div>
          ) : isTwoPageDesktop ? (
            /* Desktop Two-Page Spread (Left + Right Pages) */
            <div className="grid grid-cols-2 gap-0 relative">
              {/* Left Page */}
              <div className="relative pr-2 border-r border-slate-800/80 overflow-hidden">
                <div className="absolute inset-y-0 right-0 w-8 spine-shadow-left pointer-events-none z-20" />
                <div className="transition-all duration-300">
                  {renderPageContent(leftPageNum)}
                </div>
                <div className="text-center text-[10px] text-slate-500 pt-2 font-mono">
                  — Page {leftPageNum} —
                </div>
              </div>

              {/* Right Page */}
              <div className="relative pl-2 overflow-hidden">
                <div className="absolute inset-y-0 left-0 w-8 spine-shadow-right pointer-events-none z-20" />
                <div className="transition-all duration-300">
                  {rightPageNum <= totalPages ? (
                    renderPageContent(rightPageNum)
                  ) : (
                    <div className="min-h-[500px] flex items-center justify-center text-slate-600 text-xs">
                      End of Catalogue
                    </div>
                  )}
                </div>
                {rightPageNum <= totalPages && (
                  <div className="text-center text-[10px] text-slate-500 pt-2 font-mono">
                    — Page {rightPageNum} —
                  </div>
                )}
              </div>

              {/* 3D Center Book Crease / Spine Effect */}
              <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-4 page-crease pointer-events-none z-30" />
            </div>
          ) : (
            /* Mobile Single Page View */
            <div className="w-full relative overflow-hidden">
              <div className="transition-all duration-300">
                {renderPageContent(currentPage)}
              </div>
              <div className="text-center text-[10px] text-slate-500 pt-2 font-mono">
                — Page {currentPage} of {totalPages} —
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Chapter Jump Slider / Bottom Navigation */}
      <div className="w-full max-w-4xl pt-4 sm:pt-6 space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <button
            type="button"
            onClick={goToPrev}
            disabled={currentPage <= 1}
            className="flex items-center gap-1 font-semibold disabled:opacity-30 hover:text-white transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>

          <span className="font-semibold text-slate-300">
            {bookPages.find((p) => p.page_number === currentPage)?.title || `Chapter ${currentPage}`}
          </span>

          <button
            type="button"
            onClick={goToNext}
            disabled={currentPage >= totalPages}
            className="flex items-center gap-1 font-semibold disabled:opacity-30 hover:text-white transition-colors"
          >
            <span>Next</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Page progress scrub bar */}
        <input
          type="range"
          min="1"
          max={totalPages}
          value={currentPage}
          onChange={(e) => onPageChange(Number(e.target.value))}
          className="w-full accent-blue-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
        />

        {/* Quick Chapter Shortcuts */}
        <div className="flex items-center justify-center gap-1.5 flex-wrap pt-1 text-[11px]">
          <button
            onClick={() => onPageChange(1)}
            className={`px-2 py-0.5 rounded ${currentPage === 1 ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
          >
            Cover
          </button>
          <button
            onClick={() => onPageChange(3)}
            className={`px-2 py-0.5 rounded ${currentPage === 3 ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
          >
            Offers
          </button>
          <button
            onClick={() => onPageChange(5)}
            className={`px-2 py-0.5 rounded ${currentPage === 5 ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
          >
            Smartphones
          </button>
          <button
            onClick={() => onPageChange(10)}
            className={`px-2 py-0.5 rounded ${currentPage === 10 ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
          >
            Accessories
          </button>
          <button
            onClick={() => onPageChange(17)}
            className={`px-2 py-0.5 rounded ${currentPage === 17 ? 'bg-amber-500 text-slate-950 font-bold' : 'text-amber-400 hover:text-amber-300'}`}
          >
            Lucky Draw
          </button>
          <button
            onClick={() => onPageChange(18)}
            className={`px-2 py-0.5 rounded ${currentPage === 18 ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
          >
            0% EMI
          </button>
          <button
            onClick={() => onPageChange(20)}
            className={`px-2 py-0.5 rounded ${currentPage === 20 ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
          >
            Bag
          </button>
          <button
            onClick={() => onPageChange(24)}
            className={`px-2 py-0.5 rounded ${currentPage === 24 ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
          >
            Location
          </button>
          <button
            onClick={() => onPageChange(25)}
            className={`px-2 py-0.5 rounded ${currentPage === 25 ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
          >
            Track Order
          </button>
        </div>
      </div>
    </div>
  );
};
