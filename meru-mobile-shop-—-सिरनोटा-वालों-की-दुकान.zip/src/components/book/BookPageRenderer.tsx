import React from 'react';
import {
  Product,
  Brand,
  Category,
  Offer,
  Banner,
  FinanceProvider,
  Review,
  SiteSettings,
  CartItem,
  WishlistItem,
  Order,
  BookPageConfig,
} from '../../types/database';

// Import individual page components
import { CoverPage } from './pages/CoverPage';
import { WelcomePage } from './pages/WelcomePage';
import { OffersPage } from './pages/OffersPage';
import { BrandsPage } from './pages/BrandsPage';
import { ProductListingPage } from './pages/ProductListingPage';
import { AccessoriesHubPage } from './pages/AccessoriesHubPage';
import { LuckyDrawPage } from './pages/LuckyDrawPage';
import { FinancePage } from './pages/FinancePage';
import { HowFinanceWorksPage } from './pages/HowFinanceWorksPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { ReviewsPage } from './pages/ReviewsPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { OrderTrackingPage } from './pages/OrderTrackingPage';
import { FooterSummaryPage } from './pages/FooterSummaryPage';

interface BookPageRendererProps {
  pageNumber: number;
  settings: SiteSettings;
  bookPages: BookPageConfig[];
  products: Product[];
  brands: Brand[];
  categories: Category[];
  offers: Offer[];
  banners: Banner[];
  financeProviders: FinanceProvider[];
  reviews: Review[];
  cart: CartItem[];
  wishlist: WishlistItem[];
  onOpenProduct: (product: Product) => void;
  onAddToCart: (product: Product, variantId?: string) => void;
  onBuyNow: (product: Product, variantId?: string) => void;
  onToggleWishlist: (product: Product) => void;
  onNavigateToPage: (pageNumber: number) => void;
  onOpenEnquiryModal: (type?: any, product?: string) => void;
  onUpdateCartQty: (itemId: string, qty: number) => void;
  onClearCart: () => void;
  onOrderCreated: (order: Order) => void;
}

export const BookPageRenderer: React.FC<BookPageRendererProps> = ({
  pageNumber,
  settings,
  bookPages,
  products,
  brands,
  categories,
  offers,
  banners,
  financeProviders,
  reviews,
  cart,
  wishlist,
  onOpenProduct,
  onAddToCart,
  onBuyNow,
  onToggleWishlist,
  onNavigateToPage,
  onOpenEnquiryModal,
  onUpdateCartQty,
  onClearCart,
  onOrderCreated,
}) => {
  switch (pageNumber) {
    case 1:
      return (
        <CoverPage
          settings={settings}
          onOpenShop={() => onNavigateToPage(2)}
          onNavigate={onNavigateToPage}
        />
      );

    case 2:
      return (
        <WelcomePage
          settings={settings}
          banners={banners}
          onExplorePhones={() => onNavigateToPage(5)}
          onExploreFinance={() => onNavigateToPage(18)}
        />
      );

    case 3:
      return (
        <OffersPage
          offers={offers}
          banners={banners}
          onClaimOffer={() => onNavigateToPage(5)}
        />
      );

    case 4:
      return (
        <BrandsPage
          brands={brands}
          products={products}
          onSelectBrand={() => onNavigateToPage(5)}
          onOpenProduct={onOpenProduct}
        />
      );

    case 5:
      // All Smartphones Showcase
      return (
        <ProductListingPage
          title="All Smartphones"
          subtitle="Genuine bill, official brand warranty & instant in-store setup"
          products={products.filter((p) => p.category_id === 'cat-smartphones')}
          brands={brands}
          onOpenProduct={onOpenProduct}
          onAddToCart={onAddToCart}
          onBuyNow={onBuyNow}
        />
      );

    case 6:
      // Featured Smartphones
      return (
        <ProductListingPage
          title="Featured Smartphones"
          subtitle="Top rated flagships and bestsellers in Ganj Basoda"
          products={products.filter((p) => p.is_featured && p.category_id === 'cat-smartphones')}
          brands={brands}
          onOpenProduct={onOpenProduct}
          onAddToCart={onAddToCart}
          onBuyNow={onBuyNow}
        />
      );

    case 7:
      // Budget Smartphones
      return (
        <ProductListingPage
          title="Budget Smartphones (Under ₹15,000)"
          subtitle="Power-packed performance and long battery for daily use"
          products={products.filter((p) => p.selling_price <= 16000 && p.category_id === 'cat-smartphones')}
          brands={brands}
          onOpenProduct={onOpenProduct}
          onAddToCart={onAddToCart}
          onBuyNow={onBuyNow}
        />
      );

    case 8:
      // 5G Phones
      return (
        <ProductListingPage
          title="High-Speed 5G Smartphones"
          subtitle="Next-gen 5G multi-band phones ready for Airtel & Jio in MP"
          products={products.filter((p) => p.is_5g)}
          brands={brands}
          onOpenProduct={onOpenProduct}
          onAddToCart={onAddToCart}
          onBuyNow={onBuyNow}
        />
      );

    case 9:
      // Premium Phones
      return (
        <ProductListingPage
          title="Flagship & Premium Smartphones"
          subtitle="Pro cameras, AMOLED curved displays and top-tier processors"
          products={products.filter((p) => p.selling_price >= 28000 && p.category_id === 'cat-smartphones')}
          brands={brands}
          onOpenProduct={onOpenProduct}
          onAddToCart={onAddToCart}
          onBuyNow={onBuyNow}
        />
      );

    case 10:
      // Accessories Hub Overview
      return (
        <AccessoriesHubPage
          categories={categories.filter((c) => c.id !== 'cat-smartphones')}
          onNavigateToPage={onNavigateToPage}
        />
      );

    case 11:
      // Earbuds & Audio
      return (
        <ProductListingPage
          title="Earbuds, Neckbands & Headphones"
          subtitle="boAt, Realme, OnePlus and Noise with heavy bass & ANC"
          products={products.filter((p) => p.category_id === 'cat-earbuds')}
          brands={brands}
          onOpenProduct={onOpenProduct}
          onAddToCart={onAddToCart}
          onBuyNow={onBuyNow}
        />
      );

    case 12:
      // Bluetooth Speakers
      return (
        <ProductListingPage
          title="Bluetooth Speakers"
          subtitle="Loud sound, punchy bass, long battery & waterproof designs"
          products={products.filter((p) => p.category_id === 'cat-speakers')}
          brands={brands}
          onOpenProduct={onOpenProduct}
          onAddToCart={onAddToCart}
          onBuyNow={onBuyNow}
        />
      );

    case 13:
      // Power Banks
      return (
        <ProductListingPage
          title="High-Capacity Fast Power Banks"
          subtitle="10,000mAh & 20,000mAh units with Type-C 33W fast charging"
          products={products.filter((p) => p.category_id === 'cat-powerbanks')}
          brands={brands}
          onOpenProduct={onOpenProduct}
          onAddToCart={onAddToCart}
          onBuyNow={onBuyNow}
        />
      );

    case 14:
      // Chargers & Cables
      return (
        <ProductListingPage
          title="Fast Chargers & Heavy-Duty Cables"
          subtitle="65W GaN adapters, SuperVOOC, Type-C to C and Lightning cables"
          products={products.filter((p) => p.category_id === 'cat-chargers')}
          brands={brands}
          onOpenProduct={onOpenProduct}
          onAddToCart={onAddToCart}
          onBuyNow={onBuyNow}
        />
      );

    case 15:
      // Smartwatches
      return (
        <ProductListingPage
          title="Smartwatches & Fitness Trackers"
          subtitle="AMOLED displays, Bluetooth calling and 24/7 health monitoring"
          products={products.filter((p) => p.category_id === 'cat-smartwatches')}
          brands={brands}
          onOpenProduct={onOpenProduct}
          onAddToCart={onAddToCart}
          onBuyNow={onBuyNow}
        />
      );

    case 16:
      // Covers & Tempered Glass
      return (
        <ProductListingPage
          title="Cases, UV Tempered Glass & Skins"
          subtitle="Military drop tested covers and custom laser edge-to-edge glass"
          products={products.filter((p) => p.category_id === 'cat-covers')}
          brands={brands}
          onOpenProduct={onOpenProduct}
          onAddToCart={onAddToCart}
          onBuyNow={onBuyNow}
        />
      );

    case 17:
      return (
        <LuckyDrawPage
          settings={settings}
          onExplorePhones={() => onNavigateToPage(5)}
        />
      );

    case 18:
      return (
        <FinancePage
          providers={financeProviders}
          onCheckProcess={() => onNavigateToPage(19)}
          onOpenEnquiry={() => onOpenEnquiryModal('Finance EMI Enquiry')}
        />
      );

    case 19:
      return (
        <HowFinanceWorksPage
          onExplorePhones={() => onNavigateToPage(5)}
          onOpenEnquiry={() => onOpenEnquiryModal('Finance EMI Enquiry')}
        />
      );

    case 20:
      return (
        <CartPage
          cart={cart}
          settings={settings}
          onUpdateQty={onUpdateCartQty}
          onProceedToCheckout={() => onNavigateToPage(21)}
          onContinueShopping={() => onNavigateToPage(5)}
        />
      );

    case 21:
      return (
        <CheckoutPage
          cart={cart}
          settings={settings}
          onOrderSuccess={onOrderCreated}
          onNavigateToPage={onNavigateToPage}
        />
      );

    case 22:
      return (
        <ReviewsPage
          reviews={reviews}
          products={products}
          onReviewSubmitted={() => {}}
        />
      );

    case 23:
      return (
        <AboutPage
          settings={settings}
          onExploreCatalog={() => onNavigateToPage(5)}
        />
      );

    case 24:
      return (
        <ContactPage
          settings={settings}
          onOpenEnquiry={() => onOpenEnquiryModal('Store Visit')}
        />
      );

    case 25:
      return <OrderTrackingPage onNavigateToPage={onNavigateToPage} />;

    case 26:
    default:
      return (
        <FooterSummaryPage
          settings={settings}
          onNavigateToPage={onNavigateToPage}
          onOpenEnquiryModal={onOpenEnquiryModal}
        />
      );
  }
};
