import React, { useState } from 'react';
import { Star, MessageSquare, Plus, CheckCircle2, ShieldCheck } from 'lucide-react';
import { Review, Product } from '../../types/database';
import { StoreService } from '../../services/storeService';
import { formatDate } from '../../utils/formatters';

interface ReviewsViewProps {
  reviews: Review[];
  products: Product[];
  onReviewSubmitted: () => void;
}

export const ReviewsView: React.FC<ReviewsViewProps> = ({
  reviews,
  products,
  onReviewSubmitted,
}) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [productId, setProductId] = useState(products[0]?.id || '');
  const [rating, setRating] = useState(5);
  const [title, setTitle] = useState('');
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const approvedReviews = reviews.filter((r) => r.is_approved);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !title || !comment) return;

    const prod = products.find((p) => p.id === productId);
    StoreService.submitReview({
      product_id: productId,
      product_name: prod ? prod.name : 'Store Experience',
      customer_name: customerName,
      customer_phone: customerPhone || undefined,
      rating,
      title,
      comment,
    });

    setSubmitted(true);
    setIsFormOpen(false);
    onReviewSubmitted();
  };

  return (
    <div className="space-y-6 animate-page-enter max-w-5xl mx-auto">
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-3 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold border border-blue-200 uppercase">
            <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
            <span>Customer Testimonials</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 font-serif-display mt-1">
            Customer Reviews & Experiences
          </h1>
          <p className="text-xs text-slate-500">
            Real feedback from verified buyers in Ganj Basoda and Vidisha district
          </p>
        </div>

        <button
          onClick={() => setIsFormOpen(!isFormOpen)}
          className="px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-md shadow-blue-600/20 transition-all self-start sm:self-auto shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Write a Review</span>
        </button>
      </div>

      {submitted && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-2.5 text-xs text-emerald-800">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>
            Thank you! Your feedback has been received and will be verified by our showroom team before appearing publicly.
          </span>
        </div>
      )}

      {/* Review Submission Form Modal */}
      {isFormOpen && (
        <form
          onSubmit={handleSubmit}
          className="p-6 bg-white rounded-3xl border border-slate-200 space-y-4 shadow-sm animate-in fade-in"
        >
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            Share Your Experience with Meru Mobile Shop
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Your Name *</label>
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="e.g. Deepak Raghuwanshi"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Mobile (Optional)</label>
              <input
                type="tel"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                placeholder="For purchase verification"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Device Purchased</label>
              <select
                value={productId}
                onChange={(e) => setProductId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Your Rating</label>
              <div className="flex items-center gap-1 pt-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="p-1 hover:scale-110 transition-transform"
                  >
                    <Star
                      className={`w-6 h-6 ${
                        star <= rating ? 'text-amber-500 fill-amber-500' : 'text-slate-300'
                      }`}
                    />
                  </button>
                ))}
                <span className="text-xs font-bold text-amber-700 ml-2">{rating} Stars</span>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Review Headline *</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Best price in Ganj Basoda and fast Bajaj EMI"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Detailed Review *</label>
            <textarea
              required
              rows={3}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Write your feedback regarding handset performance, Maneesh Jain's service, or free data transfer..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-900 focus:outline-none focus:border-blue-500 resize-none"
            />
          </div>

          <div className="flex justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={() => setIsFormOpen(false)}
              className="px-4 py-2 text-slate-500 hover:text-slate-800 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs"
            >
              Submit for Showroom Approval
            </button>
          </div>
        </form>
      )}

      {/* Approved Reviews Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {approvedReviews.map((rev) => (
          <div
            key={rev.id}
            className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-3"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded text-xs font-bold text-amber-700 border border-amber-200">
                  <span>{rev.rating}</span>
                  <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                </div>
                <span className="text-[10px] text-slate-400">{formatDate(rev.created_at)}</span>
              </div>

              <h3 className="text-sm font-bold text-slate-900">{rev.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed italic">
                "{rev.comment}"
              </p>
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
              <div>
                <div className="font-bold text-slate-900">{rev.customer_name}</div>
                {rev.product_name && (
                  <div className="text-[10px] text-blue-600 font-medium">{rev.product_name}</div>
                )}
              </div>
              <span className="text-emerald-600 text-[10px] font-bold flex items-center gap-0.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                Verified
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
