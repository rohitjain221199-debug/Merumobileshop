import React from 'react';
import { Award, ShieldCheck, HeartHandshake, MapPin, Phone, Users, ChevronRight, CheckCircle2, Clock } from 'lucide-react';
import { SiteSettings } from '../../types/database';

interface AboutViewProps {
  settings: SiteSettings;
  onNavigate: (route: string) => void;
  onOpenEnquiry: () => void;
}

export const AboutView: React.FC<AboutViewProps> = ({
  settings,
  onNavigate,
  onOpenEnquiry,
}) => {
  return (
    <div className="space-y-10 animate-page-enter max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 rounded-3xl p-6 sm:p-10 text-white relative overflow-hidden shadow-lg">
        <div className="absolute right-0 top-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-xs text-blue-200 text-xs font-semibold border border-white/15">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span>15+ Years of Local Trust in Ganj Basoda</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-black font-serif-display leading-tight">
            {settings.shop_name}
            <span className="block text-amber-400 font-hindi text-2xl sm:text-3xl font-bold mt-1">
              {settings.brand_tagline}
            </span>
          </h1>

          <p className="text-blue-100/90 text-sm sm:text-base leading-relaxed">
            Welcome to the digital showroom of Ganj Basoda's favorite mobile shop. Serving customers from Vidisha, Kurwai, Shamshabad, and all surrounding tehsils with 100% genuine sealed-pack phones, fast 15-minute finance, and dependable after-sales care.
          </p>

          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={() => onNavigate('mobiles')}
              className="px-5 py-2.5 bg-white text-blue-950 font-bold text-xs sm:text-sm rounded-xl shadow-md hover:bg-blue-50 transition-all flex items-center gap-2"
            >
              <span>Explore Smartphones</span>
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={onOpenEnquiry}
              className="px-5 py-2.5 bg-blue-700/60 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm rounded-xl border border-white/20 transition-all"
            >
              Book Showroom Visit
            </button>
          </div>
        </div>
      </div>

      {/* Founder Section */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="w-28 h-28 rounded-2xl bg-gradient-to-tr from-blue-700 via-indigo-700 to-blue-900 p-1 shrink-0 flex flex-col items-center justify-center text-3xl font-bold font-serif-display text-amber-400 border-2 border-amber-400/40 shadow-md">
            <span>MJ</span>
            <span className="text-[10px] text-white font-normal uppercase tracking-wider mt-1">Ganj Basoda</span>
          </div>

          <div className="space-y-2 text-center md:text-left flex-1">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 justify-center md:justify-start">
              <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                {settings.owner_name}
              </h2>
              <span className="inline-block px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 font-bold text-xs border border-blue-200">
                Founder & Proprietor
              </span>
            </div>
            <p className="text-sm font-hindi text-slate-700 italic">
              "हमारे यहाँ हर ग्राहक सिर्फ एक खरीदार नहीं, परिवार जैसा है। सच्चा बिल, सील्ड-पैक मोबाइल और सही दाम — यही सिरनोटा वालों की पहचान है।"
            </p>
            <p className="text-xs text-slate-500 leading-relaxed pt-1">
              Started with a vision to bring official brand smartphones and authentic mobile accessories at genuine metro rates to Ganj Basoda, Meru Mobile Shop has grown to become the most trusted name in Tyoda Road.
            </p>
          </div>
        </div>
      </div>

      {/* 4 Pillars of Meru Mobile Shop */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2.5">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">100% Genuine Sealed Pack</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Every phone is genuine brand stock with original manufacturer seal and official 1-year brand warranty.
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2.5">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
            <Award className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">Official Brand Invoices</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            GST printed invoice provided with every mobile purchase for complete tax compliance and peace of mind.
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2.5">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold">
            <HeartHandshake className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">Instant 15-Min EMI</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Zero percent down-payment finance through Bajaj Finserv, HDB Financial, and IDFC First Bank right at the counter.
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2.5">
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
            <Users className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">Free Data Transfer & Setup</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Free contacts & WhatsApp data transfer from old phone to new phone, with glass guard pasting on the spot.
          </p>
        </div>
      </div>

      {/* Showroom Highlights & Location callout */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-4 shadow-xs">
        <h3 className="text-lg font-bold text-slate-900">Showroom Details & Facilities</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-600">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-slate-900 block">Live Demo Units</span>
              Experience cameras, displays, and build quality of latest Samsung, Vivo, Oppo, OnePlus and Apple models before buying.
            </div>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-slate-900 block">Exchange Bonus</span>
              Best exchange valuation for your old smartphones with immediate discount applied to your new handset bill.
            </div>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-slate-900 block">Complete Protection Hub</span>
              11D Tempered glass, camera lens protectors, silicone & armor covers for all models in stock.
            </div>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-slate-900 block">Same-Day Local Delivery</span>
              Doorstep delivery in Ganj Basoda within 2-4 hours, or instant pick up at our Tyoda Road showroom.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
