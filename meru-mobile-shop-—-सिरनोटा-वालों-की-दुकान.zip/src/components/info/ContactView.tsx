import React from 'react';
import { MapPin, Phone, MessageCircle, Clock, ExternalLink, Calendar, Mail, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { SiteSettings } from '../../types/database';
import { createWhatsAppUrl } from '../../utils/formatters';

interface ContactViewProps {
  settings: SiteSettings;
  onOpenEnquiry: () => void;
}

export const ContactView: React.FC<ContactViewProps> = ({
  settings,
  onOpenEnquiry,
}) => {
  const handleOpenWhatsApp = () => {
    const msg = `Hello Meru Mobile Shop (${settings.shop_name}), mujhe showroom visit karni hai aur models dekhne hain.`;
    window.open(createWhatsAppUrl(settings.whatsapp_number, msg), '_blank');
  };

  const handleCall = () => {
    window.open(`tel:${settings.phone}`);
  };

  return (
    <div className="space-y-8 animate-page-enter max-w-5xl mx-auto">
      {/* Header */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-2 shadow-xs">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold border border-blue-200 uppercase">
          <MapPin className="w-3.5 h-3.5" />
          <span>Showroom & Customer Support</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 font-serif-display">
          Visit Meru Mobile Showroom
        </h1>
        <p className="text-xs text-slate-500 max-w-xl">
          Located right on Tyoda Road, near Pawan Auto Mobile and the Old Bus Stand in Ganj Basoda. Walk in for demo, purchase, exchange, or EMI finance.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Address Card */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-5 shadow-xs">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Store Address & Landmark</h3>
              <p className="text-[11px] text-slate-400">Ganj Basoda, District Vidisha</p>
            </div>
          </div>

          <div className="space-y-2 text-xs text-slate-600">
            <div className="font-bold text-slate-900 text-base">{settings.shop_name}</div>
            <div className="text-blue-700 font-hindi font-bold">{settings.brand_tagline}</div>
            <div className="text-slate-700 font-medium">{settings.address_street}</div>
            <div className="text-slate-500">Landmark: {settings.landmark}</div>
            <div className="text-slate-700">
              {settings.address_city}, Dist. {settings.address_district}, {settings.address_state} – {settings.address_pincode}
            </div>
            <div className="pt-2 text-slate-500">
              <span className="font-semibold text-slate-700">Proprietor:</span> {settings.owner_name}
            </div>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <a
              href="https://maps.google.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 py-2.5 px-4 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs rounded-xl border border-blue-200 transition-colors flex items-center justify-center gap-1.5"
            >
              <span>Open in Google Maps</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>

            <button
              onClick={onOpenEnquiry}
              className="flex-1 py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 shadow-sm"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Book Appointment</span>
            </button>
          </div>
        </div>

        {/* Timings & Direct Contact */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-5 shadow-xs">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Direct Contact & WhatsApp</h3>
              <p className="text-[11px] text-slate-400">Instant answers during store hours</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-600 flex items-center justify-center">
                  <MessageCircle className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[11px] text-slate-400 font-medium">WhatsApp Support</div>
                  <div className="text-xs font-bold text-slate-900">+91 {settings.whatsapp_number}</div>
                </div>
              </div>
              <button
                onClick={handleOpenWhatsApp}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-1 shadow-xs"
              >
                <span>Chat</span>
              </button>
            </div>

            <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-600 flex items-center justify-center">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[11px] text-slate-400 font-medium">Phone Call Enquiry</div>
                  <div className="text-xs font-bold text-slate-900">+91 {settings.phone}</div>
                </div>
              </div>
              <button
                onClick={handleCall}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-1 shadow-xs"
              >
                <span>Call</span>
              </button>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-1">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                <span>Showroom Timings</span>
              </div>
              <div className="text-xs text-slate-600 pl-5">
                {settings.opening_hours} • Open 7 Days a Week
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Assurance Card */}
      <div className="bg-blue-50/60 rounded-3xl border border-blue-100 p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 text-center sm:text-left">
          <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-bold text-slate-900 text-xs sm:text-sm">
              Authentic Products Guarantee in Ganj Basoda
            </h4>
            <p className="text-[11px] text-slate-500">
              Buy with complete peace of mind. Every product comes with manufacturer box seal, original accessories, and authorized warranty.
            </p>
          </div>
        </div>

        <button
          onClick={handleOpenWhatsApp}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors shrink-0 flex items-center gap-1.5"
        >
          <MessageCircle className="w-4 h-4" />
          <span>WhatsApp Maneesh Jain</span>
        </button>
      </div>
    </div>
  );
};
