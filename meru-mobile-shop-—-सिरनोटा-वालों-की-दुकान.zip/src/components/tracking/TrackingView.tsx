import React, { useState } from 'react';
import { Search, Clock, Check, AlertCircle, PackageCheck, MapPin, Truck } from 'lucide-react';
import { StoreService } from '../../services/storeService';
import { Order, OrderStatus } from '../../types/database';
import { formatPrice, formatDate } from '../../utils/formatters';

interface TrackingViewProps {
  onNavigate: (route: string) => void;
}

export const TrackingView: React.FC<TrackingViewProps> = ({ onNavigate }) => {
  const [orderQuery, setOrderQuery] = useState('MERU-2025-1001');
  const [searchedOrder, setSearchedOrder] = useState<Order | undefined>(
    StoreService.getOrderById('MERU-2025-1001') || StoreService.getOrders()[0]
  );
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const found = StoreService.getOrderById(orderQuery.trim());
    if (found) {
      setSearchedOrder(found);
    } else {
      setSearchedOrder(undefined);
      setErrorMsg(`No order found matching "${orderQuery}". Please check your order ID.`);
    }
  };

  const TRACKING_STAGES: { status: OrderStatus; label: string }[] = [
    { status: 'Pending', label: 'Order Registered' },
    { status: 'Confirmed', label: 'Stock Reserved' },
    { status: 'Processing', label: 'Order Verified' },
    { status: 'Packed', label: 'Packed with GST Bill' },
    { status: 'Out for Delivery', label: 'Out for Delivery' },
    { status: 'Delivered', label: 'Delivered / Collected' },
  ];

  const getStageIndex = (status: OrderStatus): number => {
    const idx = TRACKING_STAGES.findIndex((s) => s.status === status);
    if (idx !== -1) return idx;
    if (status === 'Shipped') return 4;
    return 0;
  };

  const currentStageIdx = searchedOrder ? getStageIndex(searchedOrder.order_status) : -1;

  return (
    <div className="space-y-6 animate-page-enter max-w-4xl mx-auto">
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-3 shadow-xs">
        <h1 className="text-2xl font-black text-slate-900 font-serif-display flex items-center gap-2">
          <Truck className="w-6 h-6 text-blue-600" />
          <span>Track My Order</span>
        </h1>
        <p className="text-xs text-slate-500">
          Enter your Order Number to check live packaging, handover or delivery status
        </p>

        <form onSubmit={handleSearch} className="pt-2 max-w-md">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={orderQuery}
                onChange={(e) => setOrderQuery(e.target.value)}
                placeholder="Order ID (e.g. MERU-2025-1001)"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-900 font-mono uppercase focus:outline-none focus:border-blue-500"
              />
            </div>
            <button
              type="submit"
              className="py-2.5 px-5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
            >
              Track
            </button>
          </div>
          {errorMsg && (
            <p className="text-xs text-red-600 mt-2 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{errorMsg}</span>
            </p>
          )}
        </form>
      </div>

      {searchedOrder && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6 shadow-xs">
          {/* Order Header Summary */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-base font-extrabold text-slate-900">
                  {searchedOrder.order_number}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 font-bold border border-blue-200">
                  {searchedOrder.order_status}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Ordered on {formatDate(searchedOrder.created_at)} • Customer: {searchedOrder.customer_name} ({searchedOrder.customer_phone})
              </p>
            </div>

            <div className="text-right">
              <div className="text-xs text-slate-400">Total Amount:</div>
              <div className="text-lg font-black text-blue-600">
                {formatPrice(searchedOrder.final_amount)}
              </div>
              <div className="text-[10px] text-slate-500 uppercase">
                {searchedOrder.payment_method} ({searchedOrder.payment_status})
              </div>
            </div>
          </div>

          {/* Visual 6-Step Timeline */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Live Progress
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5">
              {TRACKING_STAGES.map((stg, i) => {
                const isCompleted = i <= currentStageIdx;
                const isCurrent = i === currentStageIdx;

                return (
                  <div
                    key={stg.status}
                    className={`p-3 rounded-2xl border text-center space-y-1.5 transition-all ${
                      isCurrent
                        ? 'bg-blue-50 border-blue-500 ring-2 ring-blue-500/20 text-blue-900'
                        : isCompleted
                        ? 'bg-emerald-50/60 border-emerald-300 text-slate-800'
                        : 'bg-slate-50 border-slate-200 text-slate-400'
                    }`}
                  >
                    <div
                      className={`w-6 h-6 mx-auto rounded-full flex items-center justify-center text-xs font-bold ${
                        isCompleted
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-200 text-slate-500'
                      }`}
                    >
                      {isCompleted ? <Check className="w-3.5 h-3.5" /> : i + 1}
                    </div>
                    <div className="text-[11px] font-bold leading-tight">
                      {stg.label}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Activity Logs with Timestamps */}
          {searchedOrder.status_history && searchedOrder.status_history.length > 0 && (
            <div className="space-y-2 pt-3 border-t border-slate-100">
              <h4 className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                Status History Updates:
              </h4>
              <div className="space-y-1.5">
                {searchedOrder.status_history.map((hist) => (
                  <div
                    key={hist.id}
                    className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex items-start gap-2 text-xs"
                  >
                    <Clock className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-slate-900">{hist.status}</span>
                      {hist.note && <span className="text-slate-600 ml-1.5">— {hist.note}</span>}
                      <span className="text-[10px] text-slate-400 ml-2">({formatDate(hist.created_at)})</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Items summary */}
          <div className="space-y-2 pt-3 border-t border-slate-100">
            <h4 className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Ordered Devices:
            </h4>
            <div className="space-y-1.5">
              {searchedOrder.items.map((it) => (
                <div
                  key={it.id}
                  className="p-2.5 bg-slate-50 rounded-xl flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <img src={it.image_url} alt="" className="w-9 h-9 object-contain rounded-lg bg-white p-1 border border-slate-200" />
                    <div>
                      <div className="font-bold text-slate-900">{it.product_name}</div>
                      <div className="text-[11px] text-slate-500">
                        {it.variant_description} × {it.quantity}
                      </div>
                    </div>
                  </div>
                  <div className="font-bold text-slate-900">{formatPrice(it.subtotal)}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
