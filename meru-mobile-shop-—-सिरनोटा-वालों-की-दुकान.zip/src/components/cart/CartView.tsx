import React, { useState } from 'react';
import { ShoppingBag, Trash2, Plus, Minus, Tag, Check, ArrowRight, ShieldCheck, Truck } from 'lucide-react';
import { CartItem, SiteSettings } from '../../types/database';
import { formatPrice } from '../../utils/formatters';
import { StoreService } from '../../services/storeService';

interface CartViewProps {
  cart: CartItem[];
  settings: SiteSettings;
  onUpdateQty: (itemId: string, qty: number) => void;
  onProceedToCheckout: () => void;
  onContinueShopping: () => void;
}

export const CartView: React.FC<CartViewProps> = ({
  cart,
  settings,
  onUpdateQty,
  onProceedToCheckout,
  onContinueShopping,
}) => {
  const [couponCode, setCouponCode] = useState('');
  const [couponError, setCouponError] = useState<string | null>(null);
  const [appliedCoupon, setAppliedCoupon] = useState<{
    code: string;
    discount: number;
    message: string;
  } | null>(null);

  const subtotal = cart.reduce((acc, item) => acc + item.variant.selling_price * item.quantity, 0);
  const discountAmount = appliedCoupon ? appliedCoupon.discount : 0;
  const isFreeDelivery = subtotal >= settings.free_delivery_above || subtotal === 0;
  const deliveryCharge = isFreeDelivery ? 0 : 50;
  const finalTotal = Math.max(0, subtotal - discountAmount + deliveryCharge);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError(null);
    const res = StoreService.applyCoupon(couponCode, subtotal);
    if (!res.valid) {
      setCouponError(res.message);
      setAppliedCoupon(null);
    } else {
      setAppliedCoupon({
        code: couponCode.toUpperCase(),
        discount: res.discount,
        message: res.message,
      });
    }
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode('');
    setCouponError(null);
  };

  return (
    <div className="space-y-6 animate-page-enter max-w-5xl mx-auto">
      <div className="flex items-center justify-between pb-3 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-black text-slate-900 font-serif-display flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-blue-600" />
            <span>Your Shopping Bag</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Review your selected phones and accessories before reservation
          </p>
        </div>
        <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200">
          {cart.reduce((a, b) => a + b.quantity, 0)} Items Total
        </span>
      </div>

      {cart.length === 0 ? (
        <div className="py-20 text-center bg-white rounded-3xl border border-slate-200 p-8 space-y-4 shadow-xs">
          <ShoppingBag className="w-14 h-14 text-slate-300 mx-auto" />
          <h2 className="text-lg font-bold text-slate-800">Your shopping bag is empty</h2>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Explore our curated 5G smartphones, genuine boAt earbuds, chargers, and Noise calling smartwatches from Ganj Basoda.
          </p>
          <button
            onClick={onContinueShopping}
            className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-600/20 transition-all"
          >
            Browse Showroom Mobiles
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Cart Items List */}
          <div className="lg:col-span-8 space-y-3">
            {cart.map((item) => (
              <div
                key={item.id}
                className="p-4 bg-white rounded-2xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-18 h-18 rounded-xl bg-slate-50 border border-slate-100 p-1.5 flex items-center justify-center shrink-0">
                    <img
                      src={item.variant.image_url || item.product.primary_image}
                      alt={item.product.name}
                      className="max-h-full max-w-full object-contain"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-blue-600 font-bold uppercase tracking-wider">
                      {item.product.brand_name}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 line-clamp-1">
                      {item.product.name}
                    </h3>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      {item.variant.color_name} {item.variant.ram ? `• ${item.variant.ram} / ${item.variant.storage}` : ''}
                    </div>
                    <div className="text-xs font-black text-slate-900 mt-1">
                      {formatPrice(item.variant.selling_price)}
                    </div>
                  </div>
                </div>

                {/* Quantity Controls & Remove */}
                <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-0 border-slate-100">
                  <div className="flex items-center bg-slate-100 rounded-xl border border-slate-200 p-1">
                    <button
                      type="button"
                      onClick={() => onUpdateQty(item.id, item.quantity - 1)}
                      className="p-1 text-slate-600 hover:text-slate-900 rounded-lg transition-colors"
                      title="Decrease quantity"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="px-3 text-xs font-bold text-slate-900">
                      {item.quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => onUpdateQty(item.id, item.quantity + 1)}
                      className="p-1 text-slate-600 hover:text-slate-900 rounded-lg transition-colors"
                      title="Increase quantity"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => onUpdateQty(item.id, 0)}
                    className="p-2 text-slate-400 hover:text-red-600 rounded-xl hover:bg-red-50 transition-colors"
                    title="Remove from bag"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}

            <div className="pt-2">
              <button
                onClick={onContinueShopping}
                className="text-xs text-blue-600 hover:underline font-bold"
              >
                ← Continue Shopping for more devices
              </button>
            </div>
          </div>

          {/* Order Summary & Coupon Card */}
          <div className="lg:col-span-4 bg-white rounded-3xl border border-slate-200 p-5 space-y-4 shadow-xs sticky top-24">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Order Summary
            </h2>

            {/* Coupon Code Section */}
            <form onSubmit={handleApplyCoupon} className="space-y-1.5">
              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                  placeholder="Coupon code (FESTIVE500)"
                  disabled={Boolean(appliedCoupon)}
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 uppercase font-mono placeholder:normal-case focus:outline-none focus:border-blue-500"
                />
                {appliedCoupon ? (
                  <button
                    type="button"
                    onClick={handleRemoveCoupon}
                    className="px-3 py-2 bg-red-50 text-red-700 hover:bg-red-100 rounded-xl text-xs font-bold border border-red-200"
                  >
                    Remove
                  </button>
                ) : (
                  <button
                    type="submit"
                    className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold"
                  >
                    Apply
                  </button>
                )}
              </div>

              {appliedCoupon && (
                <p className="text-[11px] text-emerald-600 font-semibold">
                  ✓ {appliedCoupon.message}
                </p>
              )}
              {couponError && (
                <p className="text-[11px] text-red-600 font-semibold">
                  ✕ {couponError}
                </p>
              )}
            </form>

            {/* Calculations Breakdown */}
            <div className="space-y-2.5 text-xs border-t border-slate-100 pt-3">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal:</span>
                <span className="font-bold text-slate-900">{formatPrice(subtotal)}</span>
              </div>

              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-600 font-semibold">
                  <span>Coupon Discount:</span>
                  <span>-{formatPrice(discountAmount)}</span>
                </div>
              )}

              <div className="flex justify-between text-slate-600">
                <span>Ganj Basoda Delivery:</span>
                <span className={isFreeDelivery ? 'text-emerald-600 font-bold' : 'text-slate-900'}>
                  {isFreeDelivery ? 'FREE' : formatPrice(deliveryCharge)}
                </span>
              </div>

              <div className="border-t border-slate-200 pt-2.5 flex justify-between text-sm font-black text-slate-900">
                <span>Total Amount:</span>
                <span className="text-base text-blue-600">{formatPrice(finalTotal)}</span>
              </div>
            </div>

            {/* Checkout Action Button */}
            <button
              type="button"
              onClick={onProceedToCheckout}
              className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 transition-all active:scale-95 cursor-pointer"
            >
              <span>PROCEED TO CHECKOUT</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400 text-center">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span>Cash on Delivery / Showroom Collection Available</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
