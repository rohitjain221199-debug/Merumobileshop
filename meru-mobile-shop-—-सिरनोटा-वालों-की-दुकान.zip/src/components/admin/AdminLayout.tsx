import React, { useState } from 'react';
import {
  LayoutDashboard,
  Smartphone,
  Package,
  ShoppingBag,
  Tag,
  Gift,
  BookOpen,
  MessageSquare,
  Calendar,
  Settings,
  Database,
  History,
  LogOut,
  ChevronLeft,
  ShieldCheck,
  User,
  Menu,
  X,
  CreditCard,
} from 'lucide-react';
import {
  Product,
  Order,
  Offer,
  Brand,
  Category,
  BookPageConfig,
  LuckyDrawPrize,
  LuckyDrawWinner,
  Review,
  BookingEnquiry,
  SiteSettings,
  AuditLog,
  Profile,
  UserRole,
} from '../../types/database';

import { AdminDashboardTab } from './tabs/AdminDashboardTab';
import { AdminProductsTab } from './tabs/AdminProductsTab';
import { AdminInventoryTab } from './tabs/AdminInventoryTab';
import { AdminOrdersTab } from './tabs/AdminOrdersTab';
import { AdminOffersTab } from './tabs/AdminOffersTab';
import { AdminBookPagesTab } from './tabs/AdminBookPagesTab';
import { AdminLuckyDrawTab } from './tabs/AdminLuckyDrawTab';
import { AdminReviewsTab } from './tabs/AdminReviewsTab';
import { AdminBookingsTab } from './tabs/AdminBookingsTab';
import { AdminSettingsTab } from './tabs/AdminSettingsTab';
import { AdminSupabaseTab } from './tabs/AdminSupabaseTab';
import { AdminAuditLogsTab } from './tabs/AdminAuditLogsTab';

interface AdminLayoutProps {
  currentUser: Profile | null;
  onLogin: (user: Profile) => void;
  onLogout: () => void;
  onReturnToStore: () => void;
  products: Product[];
  orders: Order[];
  offers: Offer[];
  brands: Brand[];
  categories: Category[];
  bookPages: BookPageConfig[];
  luckyPrizes: LuckyDrawPrize[];
  luckyWinners: LuckyDrawWinner[];
  reviews: Review[];
  bookings: BookingEnquiry[];
  settings: SiteSettings;
  auditLogs: AuditLog[];
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  currentUser,
  onLogin,
  onLogout,
  onReturnToStore,
  products,
  orders,
  offers,
  brands,
  categories,
  bookPages,
  luckyPrizes,
  luckyWinners,
  reviews,
  bookings,
  settings,
  auditLogs,
}) => {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Authentication State if not logged in as Admin
  const [loginPhone, setLoginPhone] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole>('super_admin');

  const isAdminRole = currentUser && ['super_admin', 'admin', 'manager', 'staff'].includes(currentUser.role);

  const handleSimulateLogin = (role: UserRole) => {
    const names: Record<UserRole, string> = {
      super_admin: 'Maneesh Jain (Owner)',
      admin: 'Sunil Jain (Store Admin)',
      manager: 'Rajesh Sen (Inventory Manager)',
      staff: 'Rohan Sharma (Counter Staff)',
      customer: 'Rahul Sharma',
    };
    const profile: Profile = {
      id: `usr-${role}-${Date.now()}`,
      phone: '9826000000',
      full_name: names[role],
      role,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    onLogin(profile);
  };

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'products', label: 'Products & Variants', icon: Smartphone },
    { id: 'inventory', label: 'Stock & Inventory', icon: Package },
    { id: 'orders', label: 'Orders Management', icon: ShoppingBag, badge: orders.filter((o) => o.order_status === 'Pending').length },
    { id: 'offers', label: 'Offers & Coupons', icon: Tag },
    { id: 'luckydraw', label: 'Lucky Draw Prizes', icon: Gift },
    { id: 'bookpages', label: 'Book Appearance', icon: BookOpen },
    { id: 'reviews', label: 'Reviews Moderation', icon: MessageSquare, badge: reviews.filter((r) => !r.is_approved).length },
    { id: 'bookings', label: 'Store Enquiries', icon: Calendar, badge: bookings.filter((b) => b.status === 'New').length },
    { id: 'settings', label: 'Store Settings', icon: Settings },
    { id: 'supabase', label: 'Supabase & SQL', icon: Database },
    { id: 'audit', label: 'Audit Logs', icon: History },
  ];

  if (!isAdminRole) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl text-slate-100">
          <div className="text-center space-y-2">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-700 to-indigo-600 flex items-center justify-center mx-auto text-white shadow-lg shadow-blue-950/50">
              <ShieldCheck className="w-8 h-8 text-amber-300" />
            </div>
            <h2 className="text-xl font-black text-white font-serif-display">
              MERU MOBILE SHOP — Admin Portal
            </h2>
            <p className="text-xs text-amber-400 font-hindi">
              सिरनोटा वालों की दुकान — गंज बासोदा
            </p>
          </div>

          <div className="space-y-3">
            <span className="text-xs font-semibold text-slate-400 block text-center">
              Select Role for Instant Portal Access:
            </span>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleSimulateLogin('super_admin')}
                className="p-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold text-center transition-all shadow-md"
              >
                Super Admin (Owner: Maneesh Jain)
              </button>

              <button
                type="button"
                onClick={() => handleSimulateLogin('manager')}
                className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold text-center transition-all"
              >
                Store Manager
              </button>

              <button
                type="button"
                onClick={() => handleSimulateLogin('admin')}
                className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold text-center transition-all"
              >
                Admin
              </button>

              <button
                type="button"
                onClick={() => handleSimulateLogin('staff')}
                className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold text-center transition-all"
              >
                Counter Staff
              </button>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800 text-center">
            <button
              onClick={onReturnToStore}
              className="text-xs text-blue-400 hover:underline flex items-center justify-center gap-1 mx-auto"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Return to Customer Showroom Catalogue</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col text-slate-100">
      {/* Top Header */}
      <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 sm:px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-slate-400 hover:text-white rounded-lg lg:hidden"
          >
            <Menu className="w-5 h-5" />
          </button>

          <button
            onClick={onReturnToStore}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Showroom Book</span>
          </button>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm text-white">MERU ADMIN</span>
              <span className="text-[10px] px-2 py-0.2 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30 uppercase">
                {currentUser?.role.replace('_', ' ')}
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-hindi hidden sm:block">
              सिरनोटा वालों की दुकान — Tyoda Road, Ganj Basoda
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <div className="text-xs font-bold text-white">{currentUser?.full_name}</div>
            <div className="text-[10px] text-slate-500 font-mono">{currentUser?.phone}</div>
          </div>

          <button
            onClick={onLogout}
            className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-xl transition-colors"
            title="Logout"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Admin Area */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto p-3 sm:p-6 gap-6">
        {/* Desktop Sidebar Navigation */}
        <aside className="w-64 shrink-0 hidden lg:block space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-900/30'
                    : 'text-slate-300 hover:bg-slate-900 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-amber-400 text-slate-950 font-black text-[10px]">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </aside>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 flex bg-black/80 backdrop-blur-sm lg:hidden">
            <div className="w-72 bg-slate-900 h-full p-4 flex flex-col justify-between border-r border-slate-800">
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <span className="font-bold text-white text-sm">Navigation</span>
                  <button onClick={() => setMobileMenuOpen(false)}>
                    <X className="w-5 h-5 text-slate-400" />
                  </button>
                </div>

                <div className="space-y-1">
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActiveTab(item.id);
                          setMobileMenuOpen(false);
                        }}
                        className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold ${
                          isActive ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <Icon className="w-4 h-4" />
                          <span>{item.label}</span>
                        </div>
                        {item.badge !== undefined && item.badge > 0 && (
                          <span className="px-1.5 py-0.2 rounded-full bg-amber-400 text-slate-950 font-black text-[10px]">
                            {item.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              <button
                onClick={onReturnToStore}
                className="w-full py-2.5 bg-slate-800 text-slate-200 rounded-xl text-xs font-medium"
              >
                Return to Showroom
              </button>
            </div>
            <div className="flex-1" onClick={() => setMobileMenuOpen(false)} />
          </div>
        )}

        {/* Tab Content Router */}
        <main className="flex-1 overflow-x-hidden">
          {activeTab === 'dashboard' && (
            <AdminDashboardTab
              products={products}
              orders={orders}
              offers={offers}
              luckyWinners={luckyWinners}
              onNavigateTab={setActiveTab}
            />
          )}

          {activeTab === 'products' && (
            <AdminProductsTab
              products={products}
              brands={brands}
              categories={categories}
              adminName={currentUser.full_name}
            />
          )}

          {activeTab === 'inventory' && (
            <AdminInventoryTab
              products={products}
              adminName={currentUser.full_name}
            />
          )}

          {activeTab === 'orders' && (
            <AdminOrdersTab
              orders={orders}
              adminName={currentUser.full_name}
            />
          )}

          {activeTab === 'offers' && (
            <AdminOffersTab
              offers={offers}
              adminName={currentUser.full_name}
            />
          )}

          {activeTab === 'luckydraw' && (
            <AdminLuckyDrawTab
              prizes={luckyPrizes}
              winners={luckyWinners}
              adminName={currentUser.full_name}
            />
          )}

          {activeTab === 'bookpages' && (
            <AdminBookPagesTab
              bookPages={bookPages}
              adminName={currentUser.full_name}
            />
          )}

          {activeTab === 'reviews' && (
            <AdminReviewsTab
              reviews={reviews}
              adminName={currentUser.full_name}
            />
          )}

          {activeTab === 'bookings' && (
            <AdminBookingsTab
              bookings={bookings}
              adminName={currentUser.full_name}
            />
          )}

          {activeTab === 'settings' && (
            <AdminSettingsTab
              settings={settings}
              adminName={currentUser.full_name}
            />
          )}

          {activeTab === 'supabase' && <AdminSupabaseTab />}

          {activeTab === 'audit' && <AdminAuditLogsTab logs={auditLogs} />}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar (Android Friendly) */}
      <div className="lg:hidden sticky bottom-0 z-30 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 p-2 flex items-center justify-around text-[10px]">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center gap-0.5 p-1 ${
            activeTab === 'dashboard' ? 'text-blue-400 font-bold' : 'text-slate-400'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Home</span>
        </button>
        <button
          onClick={() => setActiveTab('products')}
          className={`flex flex-col items-center gap-0.5 p-1 ${
            activeTab === 'products' ? 'text-blue-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Smartphone className="w-4 h-4" />
          <span>Products</span>
        </button>
        <button
          onClick={() => setActiveTab('inventory')}
          className={`flex flex-col items-center gap-0.5 p-1 ${
            activeTab === 'inventory' ? 'text-blue-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>Stock</span>
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`flex flex-col items-center gap-0.5 p-1 ${
            activeTab === 'orders' ? 'text-blue-400 font-bold' : 'text-slate-400'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Orders</span>
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          className={`flex flex-col items-center gap-0.5 p-1 ${
            activeTab === 'settings' ? 'text-blue-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>Settings</span>
        </button>
      </div>
    </div>
  );
};
