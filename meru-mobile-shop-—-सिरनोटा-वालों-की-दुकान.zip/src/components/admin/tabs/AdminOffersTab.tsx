import React, { useState } from 'react';
import { Tag, Plus, Trash2, Edit2, Check, X, Clock } from 'lucide-react';
import { Offer } from '../../../types/database';
import { StoreService } from '../../../services/storeService';
import { formatPrice } from '../../../utils/formatters';

interface AdminOffersTabProps {
  offers: Offer[];
  adminName: string;
}

export const AdminOffersTab: React.FC<AdminOffersTabProps> = ({
  offers,
  adminName,
}) => {
  const [isCreating, setIsCreating] = useState(false);
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [code, setCode] = useState('');
  const [type, setType] = useState<'flat' | 'percentage'>('flat');
  const [val, setVal] = useState(500);
  const [minOrder, setMinOrder] = useState(5000);
  const [badge, setBadge] = useState('FLAT ₹500 OFF');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const newOffer: Offer = {
      id: `off-${Date.now()}`,
      name,
      description: desc,
      discount_type: type,
      discount_value: val,
      coupon_code: code.toUpperCase(),
      min_order_amount: minOrder,
      start_date: new Date().toISOString(),
      end_date: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
      usage_count: 0,
      is_active: true,
      banner_badge: badge,
    };
    StoreService.saveOffer(newOffer, adminName);
    setIsCreating(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Delete this promotional offer?')) {
      StoreService.deleteOffer(id, adminName);
    }
  };

  return (
    <div className="space-y-4 text-slate-100">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
        <div>
          <h2 className="text-xl font-black text-white">Offers, Discounts & Coupon Codes</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Configure seasonal festive discounts and coupon codes for online bag checkout ({offers.length} Offers)
          </p>
        </div>

        <button
          onClick={() => setIsCreating(true)}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Offer</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {offers.map((offer) => (
          <div
            key={offer.id}
            className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-2 flex flex-col justify-between"
          >
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400">
                  {offer.banner_badge}
                </span>
                <span className="text-[10px] text-slate-400">Used {offer.usage_count}x</span>
              </div>
              <h4 className="text-xs font-bold text-white mt-1">{offer.name}</h4>
              <p className="text-[11px] text-slate-400">{offer.description}</p>
              <div className="font-mono text-xs font-bold text-blue-400 pt-1">
                Code: {offer.coupon_code || 'Auto-applied'}
              </div>
              <div className="text-[10px] text-slate-500">
                Min Order: {formatPrice(offer.min_order_amount)}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => handleDelete(offer.id)}
                className="p-1.5 text-slate-400 hover:text-red-400 text-xs font-semibold"
                title="Delete Offer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {isCreating && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-5 max-w-md w-full space-y-3">
            <h3 className="font-bold text-white text-base">Create Seasonal Coupon Offer</h3>

            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Offer Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Navratri Special Mobile Discount"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Coupon Code *</label>
                <input
                  type="text"
                  required
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  placeholder="e.g. NAVRATRI500"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono uppercase"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">Discount Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="flat">Flat Amount (₹)</option>
                    <option value="percentage">Percentage (%)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">Discount Value</label>
                  <input
                    type="number"
                    required
                    value={val}
                    onChange={(e) => setVal(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">Min Order Amount (₹)</label>
                  <input
                    type="number"
                    required
                    value={minOrder}
                    onChange={(e) => setMinOrder(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">Badge Tag</label>
                  <input
                    type="text"
                    value={badge}
                    onChange={(e) => setBadge(e.target.value)}
                    placeholder="e.g. FESTIVE ₹500 OFF"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Description</label>
                <textarea
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white resize-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="flex-1 py-2 text-xs text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs"
                >
                  Save Offer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
