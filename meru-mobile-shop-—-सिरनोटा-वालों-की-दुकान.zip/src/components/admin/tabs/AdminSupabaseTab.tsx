import React, { useState } from 'react';
import { Database, Copy, Check, ShieldCheck, Server, AlertCircle } from 'lucide-react';
import { isSupabaseConfigured } from '../../../lib/supabase';

export const AdminSupabaseTab: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const isConnected = isSupabaseConfigured();

  const handleCopySchema = () => {
    // Schema SQL instructions
    const sql = `-- MERU MOBILE SHOP SUPABASE SCHEMA
-- Please see /supabase/schema.sql for the full production PostgreSQL schema including 25+ tables, RLS policies, indexes, and storage bucket setup.`;
    navigator.clipboard.writeText(sql);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-4 text-slate-100 max-w-4xl">
      <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
        <h2 className="text-xl font-black text-white flex items-center gap-2">
          <Database className="w-5 h-5 text-blue-400" />
          <span>Supabase PostgreSQL & Cloud Architecture</span>
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Backend status, Row Level Security policies, Storage buckets & SQL migration runner
        </p>
      </div>

      {/* Connection Status Card */}
      <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-white uppercase tracking-wider">
            Backend Connection Status
          </span>
          <span
            className={`px-2.5 py-0.5 rounded-full text-xs font-bold flex items-center gap-1.5 ${
              isConnected
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-400' : 'bg-blue-400'} animate-pulse`} />
            {isConnected ? 'Connected to Supabase Cloud' : 'Active Local-First Store Engine (Zero Latency)'}
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          The application is fully architected for Supabase with PostgreSQL, Row Level Security (RLS), Supabase Auth, and Supabase Storage. All catalogue items, product variants, orders, stock adjustments, and lucky draw tickets persist seamlessly.
        </p>

        {/* Environment Variables Guide */}
        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-xs">
          <div className="font-bold text-slate-200">Supabase Environment Configuration:</div>
          <div className="space-y-1 font-mono text-[11px] text-slate-400">
            <div>
              <span className="text-blue-400">VITE_SUPABASE_URL</span> = "{import.meta.env.VITE_SUPABASE_URL || 'https://[your-project].supabase.co'}"
            </div>
            <div>
              <span className="text-blue-400">VITE_SUPABASE_ANON_KEY</span> = "{import.meta.env.VITE_SUPABASE_ANON_KEY ? '••••••••••••••••••••••••••••' : '[your-anon-public-key]'}"
            </div>
          </div>
          <p className="text-[11px] text-slate-500">
            When provided, the app queries Supabase directly. When unset, it uses our high-performance relational local-first engine with zero downtime.
          </p>
        </div>
      </div>

      {/* SQL Migration & Schema Card */}
      <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Complete PostgreSQL Schema & RLS Policies
            </h3>
            <p className="text-[11px] text-slate-400">
              Found at <code className="text-blue-400">/supabase/schema.sql</code> with all 25+ relational tables
            </p>
          </div>

          <button
            onClick={handleCopySchema}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy SQL Path'}</span>
          </button>
        </div>

        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] font-mono text-slate-400 space-y-1 max-h-48 overflow-y-auto">
          <div className="text-emerald-400">-- Relational Tables Included:</div>
          <div>• profiles, user_roles (RBAC: Super Admin, Admin, Manager, Staff)</div>
          <div>• brands, categories, products, product_variants, product_images</div>
          <div>• inventory_transactions, addresses, orders, order_items, order_status_history</div>
          <div>• offers, banners, reviews, bookings, lucky_draw_prizes, lucky_draw_winners</div>
          <div>• finance_providers, book_pages, site_settings, audit_logs, notifications</div>
          <div className="text-blue-400 pt-1">-- Storage Buckets Created:</div>
          <div>• product-images, brand-logos, banners, review-images, lucky-draw-prizes</div>
        </div>
      </div>
    </div>
  );
};
