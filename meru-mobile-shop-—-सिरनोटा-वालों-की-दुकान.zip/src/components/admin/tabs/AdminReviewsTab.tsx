import React from 'react';
import { Star, Check, X, Trash2, ShieldCheck } from 'lucide-react';
import { Review } from '../../../types/database';
import { StoreService } from '../../../services/storeService';
import { formatDate } from '../../../utils/formatters';

interface AdminReviewsTabProps {
  reviews: Review[];
  adminName: string;
}

export const AdminReviewsTab: React.FC<AdminReviewsTabProps> = ({
  reviews,
  adminName,
}) => {
  const handleApprove = (id: string, approved: boolean) => {
    StoreService.toggleReviewApproval(id, approved, adminName);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Delete this customer review?')) {
      StoreService.deleteReview(id, adminName);
    }
  };

  return (
    <div className="space-y-4 text-slate-100">
      <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
        <h2 className="text-xl font-black text-white">Customer Feedback & Reviews Moderation</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Approve verified feedback before it displays on public Page 22 ({reviews.length} Reviews)
        </p>
      </div>

      <div className="space-y-3">
        {reviews.map((rev) => (
          <div
            key={rev.id}
            className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="font-bold text-xs text-white">{rev.title}</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    rev.is_approved
                      ? 'bg-emerald-500/20 text-emerald-400'
                      : 'bg-amber-500/20 text-amber-400'
                  }`}
                >
                  {rev.is_approved ? 'Approved & Public' : 'Pending Approval'}
                </span>
              </div>
              <p className="text-xs text-slate-300">{rev.comment}</p>
              <div className="flex items-center gap-2 text-[11px] text-slate-400 pt-1">
                <span>By: {rev.customer_name}</span>
                {rev.customer_phone && <span className="font-mono">({rev.customer_phone})</span>}
                <span>•</span>
                <span>{formatDate(rev.created_at)}</span>
                <span>•</span>
                <span className="text-blue-400">{rev.product_name}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {!rev.is_approved ? (
                <button
                  onClick={() => handleApprove(rev.id, true)}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Approve</span>
                </button>
              ) : (
                <button
                  onClick={() => handleApprove(rev.id, false)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-medium"
                >
                  Hide
                </button>
              )}
              <button
                onClick={() => handleDelete(rev.id)}
                className="p-1.5 text-slate-400 hover:text-red-400 rounded-lg"
                title="Delete"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
