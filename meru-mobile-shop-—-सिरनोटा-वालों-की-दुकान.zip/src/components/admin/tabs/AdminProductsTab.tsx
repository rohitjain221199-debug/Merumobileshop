import React, { useState } from 'react';
import { Plus, Edit2, Trash2, Copy, Search, Check, X, Smartphone, Layers } from 'lucide-react';
import { Product, ProductVariant, Brand, Category } from '../../../types/database';
import { StoreService } from '../../../services/storeService';
import { formatPrice } from '../../../utils/formatters';

interface AdminProductsTabProps {
  products: Product[];
  brands: Brand[];
  categories: Category[];
  adminName: string;
}

export const AdminProductsTab: React.FC<AdminProductsTabProps> = ({
  products,
  brands,
  categories,
  adminName,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  // Form State
  const [name, setName] = useState('');
  const [brandId, setBrandId] = useState(brands[0]?.id || '');
  const [categoryId, setCategoryId] = useState(categories[0]?.id || '');
  const [model, setModel] = useState('');
  const [description, setDescription] = useState('');
  const [shortDesc, setShortDesc] = useState('');
  const [mrp, setMrp] = useState(19999);
  const [sellingPrice, setSellingPrice] = useState(16999);
  const [sku, setSku] = useState('');
  const [warranty, setWarranty] = useState('1 Year Official Brand Warranty');
  const [is5G, setIs5G] = useState(true);
  const [primaryImage, setPrimaryImage] = useState('');
  const [isFeatured, setIsFeatured] = useState(false);
  const [isBestseller, setIsBestseller] = useState(false);
  const [isNewArrival, setIsNewArrival] = useState(false);
  const [variants, setVariants] = useState<ProductVariant[]>([]);

  const handleOpenCreate = () => {
    setName('');
    setBrandId(brands[0]?.id || '');
    setCategoryId(categories[0]?.id || '');
    setModel('');
    setDescription('');
    setShortDesc('');
    setMrp(19999);
    setSellingPrice(16999);
    setSku(`MERU-${Date.now().toString().slice(-6)}`);
    setWarranty('1 Year Official Brand Warranty');
    setIs5G(true);
    setPrimaryImage('https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=800&auto=format&fit=crop');
    setIsFeatured(false);
    setIsBestseller(false);
    setIsNewArrival(true);
    setVariants([
      {
        id: `v-${Date.now()}-1`,
        product_id: '',
        sku: `SKU-${Date.now().toString().slice(-6)}-1`,
        color_name: 'Black',
        color_hex: '#111827',
        ram: '8GB',
        storage: '128GB',
        mrp: 19999,
        selling_price: 16999,
        stock_quantity: 10,
        is_default: true,
      },
    ]);
    setEditingProduct(null);
    setIsCreating(true);
  };

  const handleOpenEdit = (p: Product) => {
    setEditingProduct(p);
    setName(p.name);
    setBrandId(p.brand_id);
    setCategoryId(p.category_id);
    setModel(p.model);
    setDescription(p.description);
    setShortDesc(p.short_description);
    setMrp(p.mrp);
    setSellingPrice(p.selling_price);
    setSku(p.sku);
    setWarranty(p.warranty);
    setIs5G(p.is_5g);
    setPrimaryImage(p.primary_image);
    setIsFeatured(p.is_featured);
    setIsBestseller(p.is_bestseller);
    setIsNewArrival(p.is_new_arrival);
    setVariants(p.variants || []);
    setIsCreating(true);
  };

  const handleDuplicate = (p: Product) => {
    const duplicated: Product = {
      ...p,
      id: `prod-${Date.now()}`,
      name: `${p.name} (Copy)`,
      slug: `${p.slug}-copy-${Date.now().toString().slice(-4)}`,
      sku: `${p.sku}-CPY`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    StoreService.saveProduct(duplicated, adminName);
  };

  const handleDelete = (id: string, productName: string) => {
    if (window.confirm(`Are you sure you want to remove "${productName}" from the showroom database?`)) {
      StoreService.deleteProduct(id, adminName);
    }
  };

  const handleAddVariant = () => {
    const newV: ProductVariant = {
      id: `v-${Date.now()}-${variants.length}`,
      product_id: editingProduct?.id || '',
      sku: `${sku}-V${variants.length + 1}`,
      color_name: 'Blue',
      color_hex: '#2563eb',
      ram: '8GB',
      storage: '256GB',
      mrp: mrp,
      selling_price: sellingPrice,
      stock_quantity: 5,
      is_default: variants.length === 0,
    };
    setVariants([...variants, newV]);
  };

  const handleUpdateVariant = (index: number, field: keyof ProductVariant, val: any) => {
    const updated = [...variants];
    updated[index] = { ...updated[index], [field]: val };
    setVariants(updated);
  };

  const handleRemoveVariant = (index: number) => {
    setVariants(variants.filter((_, idx) => idx !== index));
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const brand = brands.find((b) => b.id === brandId);
    const category = categories.find((c) => c.id === categoryId);

    const totalStock = variants.reduce((acc, v) => acc + (Number(v.stock_quantity) || 0), 0);

    const productPayload: Product = {
      id: editingProduct ? editingProduct.id : `prod-${Date.now()}`,
      name,
      slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      brand_id: brandId,
      brand_name: brand?.name,
      category_id: categoryId,
      category_name: category?.name,
      model,
      description,
      short_description: shortDesc,
      specifications: editingProduct?.specifications || {
        Display: '6.67" AMOLED 120Hz',
        Processor: 'Octa Core High Speed 5G',
        Battery: '5000mAh with Fast Charge',
      },
      mrp,
      selling_price: sellingPrice,
      discount_percent: mrp > sellingPrice ? Math.round(((mrp - sellingPrice) / mrp) * 100) : 0,
      stock_quantity: totalStock,
      stock_status: totalStock <= 0 ? 'out_of_stock' : totalStock <= 5 ? 'low_stock' : 'in_stock',
      sku,
      warranty,
      is_5g: is5G,
      primary_image: primaryImage,
      images: editingProduct?.images || [],
      variants: variants.map((v) => ({
        ...v,
        product_id: editingProduct?.id || `prod-${Date.now()}`,
      })),
      is_featured: isFeatured,
      is_new_arrival: isNewArrival,
      is_bestseller: isBestseller,
      is_offer_product: false,
      is_active: true,
      created_at: editingProduct ? editingProduct.created_at : new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    StoreService.saveProduct(productPayload, adminName);
    setIsCreating(false);
    setEditingProduct(null);
  };

  const filtered = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.model.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4 text-slate-100">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
        <div>
          <h2 className="text-xl font-black text-white">Product & Variant Management</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage models, pricing, storage variants, images & warranty ({products.length} Products)
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-blue-900/30 transition-all self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Product</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Filter products by model name, brand or SKU..."
          className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
        />
      </div>

      {/* Product List Table */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Product</th>
                <th className="py-3 px-4">Brand & Category</th>
                <th className="py-3 px-4">Selling Price / MRP</th>
                <th className="py-3 px-4">Variants & Stock</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.map((prod) => (
                <tr key={prod.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={prod.primary_image}
                        alt={prod.name}
                        className="w-10 h-10 object-contain rounded-lg bg-slate-950 p-1 border border-slate-800 shrink-0"
                      />
                      <div>
                        <div className="font-bold text-white line-clamp-1">{prod.name}</div>
                        <div className="text-[11px] text-slate-400">SKU: {prod.sku}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-blue-400">{prod.brand_name}</div>
                    <div className="text-[11px] text-slate-400">{prod.category_name}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-black text-white">{formatPrice(prod.selling_price)}</div>
                    <div className="text-[10px] text-slate-500 line-through">
                      {formatPrice(prod.mrp)}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-bold text-white">{prod.stock_quantity} units</div>
                    <div className="text-[10px] text-slate-400">
                      {prod.variants?.length || 0} variants configured
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        prod.stock_quantity <= 0
                          ? 'bg-rose-500/20 text-rose-400'
                          : prod.stock_quantity <= 5
                          ? 'bg-amber-500/20 text-amber-400'
                          : 'bg-emerald-500/20 text-emerald-400'
                      }`}
                    >
                      {prod.stock_status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(prod)}
                        className="p-1.5 bg-slate-800 hover:bg-blue-600 text-slate-300 hover:text-white rounded-lg transition-colors"
                        title="Edit Product"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDuplicate(prod)}
                        className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors"
                        title="Duplicate Product"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(prod.id, prod.name)}
                        className="p-1.5 bg-slate-800 hover:bg-red-600 text-slate-300 hover:text-white rounded-lg transition-colors"
                        title="Delete Product"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit / Create Product Modal */}
      {isCreating && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-5 my-6 max-h-[92vh] flex flex-col overflow-hidden text-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-white text-base">
                {editingProduct ? `Edit: ${editingProduct.name}` : 'Add New Showroom Product'}
              </h3>
              <button
                onClick={() => setIsCreating(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="flex-1 overflow-y-auto py-3 space-y-4 pr-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">Product Title *</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Vivo V30 Pro 5G"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">Model Name *</label>
                  <input
                    type="text"
                    required
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    placeholder="e.g. V30 Pro"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">Brand *</label>
                  <select
                    value={brandId}
                    onChange={(e) => setBrandId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  >
                    {brands.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">Category *</label>
                  <select
                    value={categoryId}
                    onChange={(e) => setCategoryId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">Base SKU *</label>
                  <input
                    type="text"
                    required
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">MRP (₹) *</label>
                  <input
                    type="number"
                    required
                    value={mrp}
                    onChange={(e) => setMrp(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">Selling Price (₹) *</label>
                  <input
                    type="number"
                    required
                    value={sellingPrice}
                    onChange={(e) => setSellingPrice(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] text-slate-300 mb-1">Primary Image URL *</label>
                  <input
                    type="url"
                    required
                    value={primaryImage}
                    onChange={(e) => setPrimaryImage(e.target.value)}
                    placeholder="https://images.unsplash.com/..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Short Description</label>
                <input
                  type="text"
                  value={shortDesc}
                  onChange={(e) => setShortDesc(e.target.value)}
                  placeholder="Key highlight for catalogue card"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Detailed Description</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none resize-none"
                />
              </div>

              {/* Badges / Checkboxes */}
              <div className="flex flex-wrap gap-4 pt-1 text-xs">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={is5G}
                    onChange={(e) => setIs5G(e.target.checked)}
                    className="accent-blue-600"
                  />
                  <span>5G Enabled</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isFeatured}
                    onChange={(e) => setIsFeatured(e.target.checked)}
                    className="accent-blue-600"
                  />
                  <span>Featured Product</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isBestseller}
                    onChange={(e) => setIsBestseller(e.target.checked)}
                    className="accent-blue-600"
                  />
                  <span>Bestseller</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isNewArrival}
                    onChange={(e) => setIsNewArrival(e.target.checked)}
                    className="accent-blue-600"
                  />
                  <span>New Arrival</span>
                </label>
              </div>

              {/* Independent Variants Section */}
              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-blue-400" />
                    Color & Storage Variants ({variants.length})
                  </h4>
                  <button
                    type="button"
                    onClick={handleAddVariant}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-blue-600 text-white rounded-lg text-xs font-semibold transition-colors"
                  >
                    + Add Variant
                  </button>
                </div>

                <div className="space-y-2">
                  {variants.map((v, idx) => (
                    <div
                      key={v.id}
                      className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 grid grid-cols-2 sm:grid-cols-6 gap-2 text-xs items-center"
                    >
                      <input
                        type="text"
                        placeholder="Color Name"
                        value={v.color_name}
                        onChange={(e) => handleUpdateVariant(idx, 'color_name', e.target.value)}
                        className="bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-white"
                      />
                      <input
                        type="text"
                        placeholder="RAM (e.g. 8GB)"
                        value={v.ram || ''}
                        onChange={(e) => handleUpdateVariant(idx, 'ram', e.target.value)}
                        className="bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-white"
                      />
                      <input
                        type="text"
                        placeholder="Storage (e.g. 128GB)"
                        value={v.storage || ''}
                        onChange={(e) => handleUpdateVariant(idx, 'storage', e.target.value)}
                        className="bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-white"
                      />
                      <input
                        type="number"
                        placeholder="Selling Price"
                        value={v.selling_price}
                        onChange={(e) => handleUpdateVariant(idx, 'selling_price', Number(e.target.value))}
                        className="bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-white"
                      />
                      <input
                        type="number"
                        placeholder="Stock Qty"
                        value={v.stock_quantity}
                        onChange={(e) => handleUpdateVariant(idx, 'stock_quantity', Number(e.target.value))}
                        className="bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-white"
                      />
                      <button
                        type="button"
                        onClick={() => handleRemoveVariant(idx)}
                        className="text-red-400 hover:text-red-300 text-xs font-semibold"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs shadow-md"
                >
                  Save Product to Showroom
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
