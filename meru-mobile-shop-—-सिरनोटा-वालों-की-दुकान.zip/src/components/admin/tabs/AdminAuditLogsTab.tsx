import React from 'react';
import { History, Shield, User, Clock } from 'lucide-react';
import { AuditLog } from '../../../types/database';
import { formatDate } from '../../../utils/formatters';

interface AdminAuditLogsTabProps {
  logs: AuditLog[];
}

export const AdminAuditLogsTab: React.FC<AdminAuditLogsTabProps> = ({ logs }) => {
  return (
    <div className="space-y-4 text-slate-100">
      <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
        <h2 className="text-xl font-black text-white flex items-center gap-2">
          <History className="w-5 h-5 text-blue-400" />
          <span>Admin Audit Logs & Activity History</span>
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Tamper-evident record of all price adjustments, stock changes, and store settings updates
        </p>
      </div>

      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-sm">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">Timestamp</th>
              <th className="py-3 px-4">Admin Actor</th>
              <th className="py-3 px-4">Action & Entity</th>
              <th className="py-3 px-4">Details / Change</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {logs.map((log) => (
              <tr key={log.id} className="hover:bg-slate-800/40">
                <td className="py-3 px-4 text-slate-400 font-mono text-[11px] whitespace-nowrap">
                  {formatDate(log.created_at)}
                </td>
                <td className="py-3 px-4 font-semibold text-white flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-blue-400" />
                  <span>{log.admin_name}</span>
                </td>
                <td className="py-3 px-4">
                  <span className="font-mono text-[10px] bg-blue-900/60 text-blue-300 px-2 py-0.5 rounded border border-blue-700/50">
                    {log.action}
                  </span>
                  <span className="text-slate-400 ml-2 font-medium">{log.entity}</span>
                </td>
                <td className="py-3 px-4 text-slate-300">
                  {log.new_value && <div>{log.new_value}</div>}
                  {log.previous_value && (
                    <div className="text-[10px] text-slate-500 line-through">{log.previous_value}</div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
