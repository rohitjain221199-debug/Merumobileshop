import React, { useState } from 'react';
import {
  TrendingUp,
  ShoppingBag,
  Package,
  AlertTriangle,
  Gift,
  Users,
  Clock,
  CheckCircle2,
  DollarSign,
  Calendar,
} from 'lucide-react';
import { Product, Order, Offer, LuckyDrawWinner } from '../../../types/database';
import { formatPrice, formatDate } from '../../../utils/formatters';

interface AdminDashboardTabProps {
  products: Product[];
  orders: Order[];
  offers: Offer[];
  luckyWinners: LuckyDrawWinner[];
  onNavigateTab: (tab: string) => void;
}

export const AdminDashboardTab: React.FC<AdminDashboardTabProps> = ({
  products,
  orders,
  offers,
  luckyWinners,
  onNavigateTab,
}) => {
  const [timeFilter, setTimeFilter] = useState<'today' | '7days' | '30days' | 'all'>('all');

  // Compute metrics
  const totalSales = orders.reduce((acc, o) => acc + (o.order_status !== 'Cancelled' ? o.final_amount : 0), 0);
  const totalOrders = orders.length;
  const pendingOrders = orders.filter((o) => o.order_status === 'Pending').length;
  const deliveredOrders = orders.filter((o) => o.order_status === 'Delivered').length;

  const lowStockProducts = products.filter((p) => p.stock_status === 'low_stock');
  const outOfStockProducts = products.filter((p) => p.stock_status === 'out_of_stock');
  const totalStockValue = products.reduce((acc, p) => acc + p.selling_price * p.stock_quantity, 0);

  const recentOrders = orders.slice(0, 5);

  return (
    <div className="space-y-6 text-slate-100">
      {/* Top Header with Date Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <span>MERU MOBILE SHOP — Business Overview</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Store Performance & Real-time Live Inventory (Ganj Basoda)
          </p>
        </div>

        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setTimeFilter('today')}
            className={`px-3 py-1 rounded-lg transition-colors ${
              timeFilter === 'today' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Today
          </button>
          <button
            onClick={() => setTimeFilter('7days')}
            className={`px-3 py-1 rounded-lg transition-colors ${
              timeFilter === '7days' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            7 Days
          </button>
          <button
            onClick={() => setTimeFilter('30days')}
            className={`px-3 py-1 rounded-lg transition-colors ${
              timeFilter === '30days' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            30 Days
          </button>
          <button
            onClick={() => setTimeFilter('all')}
            className={`px-3 py-1 rounded-lg transition-colors ${
              timeFilter === 'all' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            All Time
          </button>
        </div>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Gross Sales</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white">
            {formatPrice(totalSales)}
          </div>
          <div className="text-[10px] text-emerald-400 font-medium">
            From {totalOrders} shop orders
          </div>
        </div>

        <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Pending Orders</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white">
            {pendingOrders}
          </div>
          <div className="text-[10px] text-amber-400 font-medium">
            Requires verification
          </div>
        </div>

        <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Low Stock Alerts</span>
            <AlertTriangle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white">
            {lowStockProducts.length + outOfStockProducts.length}
          </div>
          <div className="text-[10px] text-rose-400 font-medium">
            {outOfStockProducts.length} completely out of stock
          </div>
        </div>

        <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Stock Value</span>
            <Package className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white">
            {formatPrice(totalStockValue)}
          </div>
          <div className="text-[10px] text-blue-400 font-medium">
            Across {products.length} products
          </div>
        </div>
      </div>

      {/* Quick Mobile Action Shortcuts */}
      <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-2">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider">
          Quick Shop Actions (Android / Desktop)
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2">
          <button
            onClick={() => onNavigateTab('products')}
            className="p-3 bg-slate-950 hover:bg-blue-950 border border-slate-800 text-center rounded-xl text-xs font-bold transition-all text-white"
          >
            + Add Product
          </button>
          <button
            onClick={() => onNavigateTab('orders')}
            className="p-3 bg-slate-950 hover:bg-blue-950 border border-slate-800 text-center rounded-xl text-xs font-bold transition-all text-white"
          >
            Manage Orders ({pendingOrders})
          </button>
          <button
            onClick={() => onNavigateTab('inventory')}
            className="p-3 bg-slate-950 hover:bg-blue-950 border border-slate-800 text-center rounded-xl text-xs font-bold transition-all text-white"
          >
            Stock Adjustment
          </button>
          <button
            onClick={() => onNavigateTab('offers')}
            className="p-3 bg-slate-950 hover:bg-blue-950 border border-slate-800 text-center rounded-xl text-xs font-bold transition-all text-white"
          >
            Offers ({offers.length})
          </button>
          <button
            onClick={() => onNavigateTab('luckydraw')}
            className="p-3 bg-slate-950 hover:bg-blue-950 border border-slate-800 text-center rounded-xl text-xs font-bold transition-all text-amber-400"
          >
            Lucky Draw ({luckyWinners.length})
          </button>
          <button
            onClick={() => onNavigateTab('settings')}
            className="p-3 bg-slate-950 hover:bg-blue-950 border border-slate-800 text-center rounded-xl text-xs font-bold transition-all text-white"
          >
            Store Settings
          </button>
        </div>
      </div>

      {/* Two Column Layout: Recent Orders & Stock Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recent Orders */}
        <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <ShoppingBag className="w-4 h-4 text-blue-400" />
              Recent Customer Orders
            </h3>
            <button
              onClick={() => onNavigateTab('orders')}
              className="text-xs text-blue-400 hover:underline"
            >
              View All →
            </button>
          </div>

          <div className="space-y-2">
            {recentOrders.map((ord) => (
              <div
                key={ord.id}
                className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-bold text-white flex items-center gap-2">
                    <span>{ord.order_number}</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-blue-900/60 text-blue-300">
                      {ord.order_status}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {ord.customer_name} ({ord.customer_phone}) • {ord.items.length} items
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-extrabold text-white">{formatPrice(ord.final_amount)}</div>
                  <div className="text-[10px] text-slate-500 uppercase">{ord.payment_method}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Stock & Inventory Attention List */}
        <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Low / Out of Stock Attention List
            </h3>
            <button
              onClick={() => onNavigateTab('inventory')}
              className="text-xs text-blue-400 hover:underline"
            >
              Adjust Stock →
            </button>
          </div>

          <div className="space-y-2">
            {[...outOfStockProducts, ...lowStockProducts].slice(0, 5).map((p) => (
              <div
                key={p.id}
                className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2.5">
                  <img
                    src={p.primary_image}
                    alt={p.name}
                    className="w-8 h-8 object-contain rounded bg-slate-900"
                  />
                  <div>
                    <div className="font-bold text-white line-clamp-1">{p.name}</div>
                    <div className="text-[11px] text-slate-400">
                      SKU: {p.sku} • {formatPrice(p.selling_price)}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <span
                    className={`text-xs font-bold px-2 py-0.5 rounded ${
                      p.stock_quantity <= 0
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                    }`}
                  >
                    {p.stock_quantity <= 0 ? 'Out of Stock' : `${p.stock_quantity} Left`}
                  </span>
                </div>
              </div>
            ))}
            {outOfStockProducts.length === 0 && lowStockProducts.length === 0 && (
              <div className="py-6 text-center text-xs text-slate-500">
                All inventory levels are healthy.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
