import React from 'react';
import { Phone, Calendar, CheckCircle2, Clock, X, MessageSquare } from 'lucide-react';
import { BookingEnquiry } from '../../../types/database';
import { StoreService } from '../../../services/storeService';
import { formatDate } from '../../../utils/formatters';

interface AdminBookingsTabProps {
  bookings: BookingEnquiry[];
  adminName: string;
}

export const AdminBookingsTab: React.FC<AdminBookingsTabProps> = ({
  bookings,
  adminName,
}) => {
  const handleStatusChange = (id: string, status: BookingEnquiry['status']) => {
    StoreService.updateBookingStatus(id, status, undefined, adminName);
  };

  return (
    <div className="space-y-4 text-slate-100">
      <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
        <h2 className="text-xl font-black text-white">Customer Enquiries & Device Reservations</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Track customer callbacks, phone inquiries, store visit appointments & 0% EMI queries ({bookings.length} Requests)
        </p>
      </div>

      <div className="space-y-3">
        {bookings.map((b) => (
          <div
            key={b.id}
            className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white">{b.customer_name}</span>
                <span className="text-[10px] font-mono text-blue-400 font-bold">{b.customer_phone}</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-blue-900/60 text-blue-300 font-semibold">
                  {b.enquiry_type}
                </span>
              </div>
              {b.product_name && (
                <div className="text-xs text-amber-400 font-medium">
                  Model: {b.product_name}
                </div>
              )}
              {b.message && (
                <p className="text-xs text-slate-300 italic">"{b.message}"</p>
              )}
              <div className="text-[10px] text-slate-500">
                Received: {formatDate(b.created_at)}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={b.status}
                onChange={(e) => handleStatusChange(b.id, e.target.value as any)}
                className="bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white"
              >
                <option value="New">New</option>
                <option value="Contacted">Contacted</option>
                <option value="Processing">Processing</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
              </select>

              <a
                href={`tel:${b.customer_phone}`}
                className="p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold"
                title="Call Customer"
              >
                <Phone className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
