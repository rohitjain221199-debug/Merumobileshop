import React, { useState } from 'react';
import { Package, Plus, Minus, AlertTriangle, History, Search } from 'lucide-react';
import { Product } from '../../../types/database';
import { StoreService } from '../../../services/storeService';
import { formatPrice } from '../../../utils/formatters';

interface AdminInventoryTabProps {
  products: Product[];
  adminName: string;
}

export const AdminInventoryTab: React.FC<AdminInventoryTabProps> = ({
  products,
  adminName,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedVariantId, setSelectedVariantId] = useState<string>('');
  const [adjustmentAmount, setAdjustmentAmount] = useState<number>(1);
  const [adjustmentReason, setAdjustmentReason] = useState<string>('New stock arrived from distributor');

  const handleAdjustStock = (isAddition: boolean) => {
    if (!selectedProduct) return;
    const change = isAddition ? Math.abs(adjustmentAmount) : -Math.abs(adjustmentAmount);
    StoreService.adjustInventory(
      selectedProduct.id,
      selectedVariantId || undefined,
      change,
      adjustmentReason,
      adminName
    );
    setSelectedProduct(null);
  };

  const filtered = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4 text-slate-100">
      <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
        <h2 className="text-xl font-black text-white">Live Showroom Inventory Management</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Record stock arrivals, manual adjustments & store reconciliation with audit tracking
        </p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search devices to adjust stock..."
          className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
        />
      </div>

      {/* Inventory Table */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">Device</th>
              <th className="py-3 px-4">SKU</th>
              <th className="py-3 px-4">Current Stock</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 text-right">Adjust Stock</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {filtered.map((prod) => (
              <tr key={prod.id} className="hover:bg-slate-800/40">
                <td className="py-3 px-4">
                  <div className="font-bold text-white">{prod.name}</div>
                  <div className="text-[11px] text-slate-400">{prod.brand_name}</div>
                </td>
                <td className="py-3 px-4 font-mono text-slate-300">{prod.sku}</td>
                <td className="py-3 px-4">
                  <span className="font-extrabold text-white text-sm">{prod.stock_quantity}</span>
                  <span className="text-slate-400 text-[11px] ml-1">in shop</span>
                </td>
                <td className="py-3 px-4">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      prod.stock_quantity <= 0
                        ? 'bg-rose-500/20 text-rose-400'
                        : prod.stock_quantity <= 5
                        ? 'bg-amber-500/20 text-amber-400'
                        : 'bg-emerald-500/20 text-emerald-400'
                    }`}
                  >
                    {prod.stock_status.replace('_', ' ')}
                  </span>
                </td>
                <td className="py-3 px-4 text-right">
                  <button
                    onClick={() => {
                      setSelectedProduct(prod);
                      setSelectedVariantId(prod.variants?.[0]?.id || '');
                    }}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
                  >
                    Adjust Stock
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Stock Adjustment Dialog */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-5 max-w-md w-full space-y-4">
            <h3 className="font-bold text-white text-base">
              Adjust Stock: {selectedProduct.name}
            </h3>

            {selectedProduct.variants && selectedProduct.variants.length > 0 && (
              <div>
                <label className="block text-xs text-slate-300 mb-1">Target Variant</label>
                <select
                  value={selectedVariantId}
                  onChange={(e) => setSelectedVariantId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                >
                  {selectedProduct.variants.map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.color_name} {v.ram ? `(${v.ram}/${v.storage})` : ''} — Current: {v.stock_quantity}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block text-xs text-slate-300 mb-1">Units Quantity</label>
              <input
                type="number"
                min="1"
                value={adjustmentAmount}
                onChange={(e) => setAdjustmentAmount(Math.max(1, Number(e.target.value)))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-300 mb-1">Adjustment Reason (Audit Log) *</label>
              <select
                value={adjustmentReason}
                onChange={(e) => setAdjustmentReason(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
              >
                <option value="New stock arrival from Indore distributor">New stock arrival from Indore distributor</option>
                <option value="Direct in-store counter cash sale">Direct in-store counter cash sale</option>
                <option value="Customer return / Exchange replacement">Customer return / Exchange replacement</option>
                <option value="Physical stock count reconciliation">Physical stock count reconciliation</option>
                <option value="Defective unit returned to brand service centre">Defective unit returned to brand service centre</option>
              </select>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => handleAdjustStock(true)}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Add to Stock</span>
              </button>
              <button
                type="button"
                onClick={() => handleAdjustStock(false)}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1"
              >
                <Minus className="w-3.5 h-3.5" />
                <span>- Reduce Stock</span>
              </button>
            </div>

            <button
              type="button"
              onClick={() => setSelectedProduct(null)}
              className="w-full py-1.5 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
