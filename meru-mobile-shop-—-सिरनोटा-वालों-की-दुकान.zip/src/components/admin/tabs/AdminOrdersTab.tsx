import React, { useState } from 'react';
import { ShoppingBag, Eye, CheckCircle2, Clock, Printer, X, Search, ChevronRight } from 'lucide-react';
import { Order, OrderStatus } from '../../../types/database';
import { StoreService } from '../../../services/storeService';
import { formatPrice, formatDate } from '../../../utils/formatters';

interface AdminOrdersTabProps {
  orders: Order[];
  adminName: string;
}

export const AdminOrdersTab: React.FC<AdminOrdersTabProps> = ({
  orders,
  adminName,
}) => {
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  const [newStatus, setNewStatus] = useState<OrderStatus>('Confirmed');
  const [statusNote, setStatusNote] = useState('');

  const STATUS_LIST: OrderStatus[] = [
    'Pending',
    'Confirmed',
    'Processing',
    'Packed',
    'Shipped',
    'Out for Delivery',
    'Delivered',
    'Cancelled',
    'Returned',
    'Refunded',
  ];

  const handleUpdateStatus = () => {
    if (!activeOrder) return;
    StoreService.updateOrderStatus(activeOrder.id, newStatus, statusNote, adminName);
    const updated = StoreService.getOrderById(activeOrder.id);
    setActiveOrder(updated || null);
    setStatusNote('');
  };

  const filteredOrders = orders.filter((o) => {
    if (selectedStatus !== 'all' && o.order_status !== selectedStatus) return false;
    const term = searchTerm.toLowerCase();
    return (
      o.order_number.toLowerCase().includes(term) ||
      o.customer_name.toLowerCase().includes(term) ||
      o.customer_phone.includes(term)
    );
  });

  return (
    <div className="space-y-4 text-slate-100">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
        <div>
          <h2 className="text-xl font-black text-white">Order Management System</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Process customer reservations, delivery dispatches & status tracking ({orders.length} Orders)
          </p>
        </div>

        {/* Filter by status */}
        <select
          value={selectedStatus}
          onChange={(e) => setSelectedStatus(e.target.value)}
          className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
        >
          <option value="all">All Statuses ({orders.length})</option>
          {STATUS_LIST.map((st) => (
            <option key={st} value={st}>
              {st} ({orders.filter((o) => o.order_status === st).length})
            </option>
          ))}
        </select>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search by Order ID, customer name or mobile number..."
          className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
        />
      </div>

      {/* Orders Table */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-sm">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">Order ID & Date</th>
              <th className="py-3 px-4">Customer Details</th>
              <th className="py-3 px-4">Items Ordered</th>
              <th className="py-3 px-4">Total Amount</th>
              <th className="py-3 px-4">Payment & Status</th>
              <th className="py-3 px-4 text-right">View / Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {filteredOrders.map((ord) => (
              <tr key={ord.id} className="hover:bg-slate-800/40 transition-colors">
                <td className="py-3 px-4">
                  <div className="font-mono font-bold text-white">{ord.order_number}</div>
                  <div className="text-[10px] text-slate-500">{formatDate(ord.created_at)}</div>
                </td>
                <td className="py-3 px-4">
                  <div className="font-semibold text-white">{ord.customer_name}</div>
                  <div className="text-[11px] text-blue-400 font-mono">{ord.customer_phone}</div>
                </td>
                <td className="py-3 px-4">
                  <div className="font-medium text-slate-200 line-clamp-1">
                    {ord.items.map((i) => `${i.product_name} (x${i.quantity})`).join(', ')}
                  </div>
                  <div className="text-[10px] text-slate-500">{ord.items.length} items total</div>
                </td>
                <td className="py-3 px-4">
                  <div className="font-extrabold text-white">{formatPrice(ord.final_amount)}</div>
                </td>
                <td className="py-3 px-4">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      ord.order_status === 'Delivered'
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : ord.order_status === 'Pending'
                        ? 'bg-amber-500/20 text-amber-400'
                        : 'bg-blue-500/20 text-blue-400'
                    }`}
                  >
                    {ord.order_status}
                  </span>
                  <div className="text-[10px] text-slate-400 mt-0.5">{ord.payment_method}</div>
                </td>
                <td className="py-3 px-4 text-right">
                  <button
                    onClick={() => {
                      setActiveOrder(ord);
                      setNewStatus(ord.order_status);
                    }}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
                  >
                    Manage
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Order Detail & Status Update Drawer / Modal */}
      {activeOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-5 my-6 max-h-[92vh] flex flex-col overflow-hidden text-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="font-bold text-white text-base">
                  Order Details: {activeOrder.order_number}
                </h3>
                <p className="text-xs text-slate-400">
                  Customer: {activeOrder.customer_name} • Phone: {activeOrder.customer_phone}
                </p>
              </div>
              <button
                onClick={() => setActiveOrder(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-3 space-y-4 pr-1">
              {/* Status Update Card */}
              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-2.5">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  Update Order Status
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <select
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value as any)}
                    className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    {STATUS_LIST.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>

                  <input
                    type="text"
                    value={statusNote}
                    onChange={(e) => setStatusNote(e.target.value)}
                    placeholder="Status note (e.g. Dispatched with delivery staff)"
                    className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleUpdateStatus}
                  className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold"
                >
                  Save Status Change
                </button>
              </div>

              {/* Delivery Address */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-1">
                <span className="font-bold text-white">Shipping Address:</span>
                <div className="text-slate-300">
                  {activeOrder.shipping_address.address_line1}, {activeOrder.shipping_address.landmark}
                </div>
                <div className="text-slate-400">
                  {activeOrder.shipping_address.city}, {activeOrder.shipping_address.state} – {activeOrder.shipping_address.pincode}
                </div>
              </div>

              {/* Items List */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-white">Items in Order:</span>
                {activeOrder.items.map((it) => (
                  <div
                    key={it.id}
                    className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2.5">
                      <img src={it.image_url} alt="" className="w-8 h-8 object-contain rounded" />
                      <div>
                        <div className="font-bold text-white">{it.product_name}</div>
                        <div className="text-[10px] text-slate-400">
                          {it.variant_description} × {it.quantity}
                        </div>
                      </div>
                    </div>
                    <div className="font-bold text-white">{formatPrice(it.subtotal)}</div>
                  </div>
                ))}
              </div>

              {/* Payment Summary */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-1">
                <div className="flex justify-between text-slate-400">
                  <span>Subtotal:</span>
                  <span>{formatPrice(activeOrder.subtotal)}</span>
                </div>
                {activeOrder.discount_amount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Discount ({activeOrder.coupon_code}):</span>
                    <span>-{formatPrice(activeOrder.discount_amount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-400">
                  <span>Delivery Charge:</span>
                  <span>{formatPrice(activeOrder.delivery_charge)}</span>
                </div>
                <div className="flex justify-between text-white font-bold text-sm pt-1 border-t border-slate-800">
                  <span>Final Payable:</span>
                  <span className="text-blue-400">{formatPrice(activeOrder.final_amount)}</span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-between">
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Invoice</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveOrder(null)}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
