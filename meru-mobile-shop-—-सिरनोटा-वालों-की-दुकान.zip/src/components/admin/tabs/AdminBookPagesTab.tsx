import React, { useState } from 'react';
import { BookOpen, Check, X, ArrowUp, ArrowDown, Edit2 } from 'lucide-react';
import { BookPageConfig } from '../../../types/database';
import { StoreService } from '../../../services/storeService';

interface AdminBookPagesTabProps {
  bookPages: BookPageConfig[];
  adminName: string;
}

export const AdminBookPagesTab: React.FC<AdminBookPagesTabProps> = ({
  bookPages,
  adminName,
}) => {
  const [pages, setPages] = useState<BookPageConfig[]>(bookPages);
  const [editingPage, setEditingPage] = useState<BookPageConfig | null>(null);

  const handleToggle = (id: string, currentEnabled: boolean) => {
    StoreService.toggleBookPage(id, !currentEnabled, adminName);
    setPages(StoreService.getBookPages());
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPage) return;
    const updated = pages.map((p) => (p.id === editingPage.id ? editingPage : p));
    StoreService.updateBookPages(updated, adminName);
    setPages(updated);
    setEditingPage(null);
  };

  const movePage = (index: number, direction: 'up' | 'down') => {
    if (
      (direction === 'up' && index === 0) ||
      (direction === 'down' && index === pages.length - 1)
    ) {
      return;
    }

    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    const newPages = [...pages];
    const temp = newPages[index];
    newPages[index] = newPages[targetIdx];
    newPages[targetIdx] = temp;

    // Reassign display_order
    const normalized = newPages.map((p, idx) => ({ ...p, display_order: idx + 1 }));
    StoreService.updateBookPages(normalized, adminName);
    setPages(normalized);
  };

  return (
    <div className="space-y-4 text-slate-100">
      <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
        <h2 className="text-xl font-black text-white">Interactive Book Appearance & Chapter Control</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Enable, disable, reorder, and edit titles of all 26 catalogue book spreads without touching code
        </p>
      </div>

      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Page #</th>
                <th className="py-3 px-4">Chapter & Title</th>
                <th className="py-3 px-4">Subtitle</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Order & Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {pages.map((p, idx) => (
                <tr key={p.id} className="hover:bg-slate-800/40">
                  <td className="py-3 px-4 font-mono font-bold text-blue-400">
                    Page {p.page_number}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-bold text-white">{p.title}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{p.chapter_name}</div>
                  </td>
                  <td className="py-3 px-4 text-slate-300 max-w-xs truncate">
                    {p.subtitle}
                  </td>
                  <td className="py-3 px-4">
                    <button
                      onClick={() => handleToggle(p.id, p.is_enabled)}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        p.is_enabled
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-slate-800 text-slate-500 border border-slate-700'
                      }`}
                    >
                      {p.is_enabled ? 'Active / Visible' : 'Hidden'}
                    </button>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => movePage(idx, 'up')}
                        disabled={idx === 0}
                        className="p-1 text-slate-400 hover:text-white disabled:opacity-20"
                        title="Move Page Up"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => movePage(idx, 'down')}
                        disabled={idx === pages.length - 1}
                        className="p-1 text-slate-400 hover:text-white disabled:opacity-20"
                        title="Move Page Down"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setEditingPage(p)}
                        className="p-1 text-blue-400 hover:text-blue-300 ml-1"
                        title="Edit Page Labels"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Page Modal */}
      {editingPage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-5 max-w-md w-full space-y-3">
            <h3 className="font-bold text-white text-base">
              Edit Page {editingPage.page_number} Appearance
            </h3>

            <form onSubmit={handleSaveEdit} className="space-y-3">
              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Page Title *</label>
                <input
                  type="text"
                  required
                  value={editingPage.title}
                  onChange={(e) => setEditingPage({ ...editingPage, title: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Page Subtitle *</label>
                <input
                  type="text"
                  required
                  value={editingPage.subtitle}
                  onChange={(e) => setEditingPage({ ...editingPage, subtitle: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Chapter Name *</label>
                <input
                  type="text"
                  required
                  value={editingPage.chapter_name}
                  onChange={(e) => setEditingPage({ ...editingPage, chapter_name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingPage(null)}
                  className="flex-1 py-2 text-xs text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs"
                >
                  Save Page
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
