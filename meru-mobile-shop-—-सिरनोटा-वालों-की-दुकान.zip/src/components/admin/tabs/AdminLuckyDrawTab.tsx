import React, { useState } from 'react';
import { Gift, Sparkles, Check, Trash2, Edit2, Plus, Clock } from 'lucide-react';
import { LuckyDrawPrize, LuckyDrawWinner } from '../../../types/database';
import { StoreService } from '../../../services/storeService';
import { formatDate } from '../../../utils/formatters';

interface AdminLuckyDrawTabProps {
  prizes: LuckyDrawPrize[];
  winners: LuckyDrawWinner[];
  adminName: string;
}

export const AdminLuckyDrawTab: React.FC<AdminLuckyDrawTabProps> = ({
  prizes,
  winners,
  adminName,
}) => {
  const [isCreating, setIsCreating] = useState(false);
  const [name, setName] = useState('');
  const [imgUrl, setImgUrl] = useState('');
  const [totalQty, setTotalQty] = useState(10);
  const [chance, setChance] = useState(10);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const newPrize: LuckyDrawPrize = {
      id: `prz-${Date.now()}`,
      name,
      image_url: imgUrl || 'https://images.unsplash.com/photo-1581553680321-4fffae59fccd?q=80&w=600&auto=format&fit=crop',
      total_quantity: totalQty,
      remaining_quantity: totalQty,
      winning_chance_percent: chance,
      is_active: true,
    };
    StoreService.saveLuckyPrize(newPrize, adminName);
    setIsCreating(false);
  };

  const handleMarkDelivered = (winnerId: string) => {
    StoreService.markPrizeDelivered(winnerId, adminName);
  };

  return (
    <div className="space-y-6 text-slate-100">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
        <div>
          <h2 className="text-xl font-black text-white">Festive Lucky Draw Management</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Configure gift prizes, stock pool, winning probabilities & winner gift handover records
          </p>
        </div>

        <button
          onClick={() => setIsCreating(true)}
          className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Draw Prize</span>
        </button>
      </div>

      {/* Prizes Pool Grid */}
      <div className="space-y-2">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider">
          Active Prizes Pool ({prizes.length} Items)
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {prizes.map((p) => (
            <div
              key={p.id}
              className="p-3.5 bg-slate-900 rounded-2xl border border-slate-800 flex items-center gap-3"
            >
              <img
                src={p.image_url}
                alt={p.name}
                className="w-12 h-12 object-contain rounded-lg bg-slate-950 p-1 border border-slate-800 shrink-0"
              />
              <div className="flex-1 min-w-0">
                <div className="font-bold text-xs text-white truncate">{p.name}</div>
                <div className="text-[11px] text-amber-400 mt-0.5">
                  Remaining: {p.remaining_quantity} / {p.total_quantity}
                </div>
                <div className="text-[10px] text-slate-500">
                  Winning Probability Weight: {p.winning_chance_percent}%
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Winners Roster Table */}
      <div className="space-y-2">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider">
          Lucky Draw Winners & Ticket Claims ({winners.length} Winners)
        </h3>
        <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-sm">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Ticket Number</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Prize Won</th>
                <th className="py-3 px-4">Draw Date</th>
                <th className="py-3 px-4">Delivery Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {winners.map((win) => (
                <tr key={win.id} className="hover:bg-slate-800/40">
                  <td className="py-3 px-4 font-mono font-bold text-blue-400">
                    {win.ticket_number}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-bold text-white">{win.customer_name}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{win.customer_phone}</div>
                  </td>
                  <td className="py-3 px-4 font-bold text-amber-400">{win.prize_name}</td>
                  <td className="py-3 px-4 text-slate-400">{formatDate(win.draw_date)}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        win.is_delivered
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'bg-amber-500/20 text-amber-400'
                      }`}
                    >
                      {win.is_delivered ? 'Handed Over' : 'Pending Claim'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    {!win.is_delivered ? (
                      <button
                        onClick={() => handleMarkDelivered(win.id)}
                        className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold"
                      >
                        Mark Handed Over
                      </button>
                    ) : (
                      <span className="text-[10px] text-slate-500">Completed</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Prize Modal */}
      {isCreating && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-5 max-w-md w-full space-y-3">
            <h3 className="font-bold text-white text-base">Add New Festive Prize</h3>
            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Prize Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Induction Cooktop (Festival Edition)"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Image URL</label>
                <input
                  type="url"
                  value={imgUrl}
                  onChange={(e) => setImgUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">Total Quantity</label>
                  <input
                    type="number"
                    min="1"
                    value={totalQty}
                    onChange={(e) => setTotalQty(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-300 mb-1">Winning Weight (%)</label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={chance}
                    onChange={(e) => setChance(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="flex-1 py-2 text-xs text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs"
                >
                  Save Prize
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
