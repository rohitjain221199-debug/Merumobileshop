import React, { useState } from 'react';
import { Tag, Copy, Check, Clock, Sparkles, ArrowRight } from 'lucide-react';
import { Offer } from '../../types/database';
import { formatPrice } from '../../utils/formatters';

interface OffersViewProps {
  offers: Offer[];
  onNavigate: (route: string) => void;
}

export const OffersView: React.FC<OffersViewProps> = ({ offers, onNavigate }) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const activeOffers = offers.filter((o) => o.is_active);

  return (
    <div className="space-y-6 animate-page-enter max-w-5xl mx-auto">
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-2 shadow-xs">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-200 uppercase">
          <Tag className="w-3.5 h-3.5" />
          <span>Exclusive Showroom Deals</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 font-serif-display">
          Today's Offers & Discount Coupons
        </h1>
        <p className="text-xs text-slate-500 max-w-xl">
          Apply these coupon codes during bag checkout or mention them at our Tyoda Road showroom for instant discounts on genuine smartphones and audio.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {activeOffers.map((offer) => (
          <div
            key={offer.id}
            className="p-5 bg-white rounded-3xl border border-slate-200 hover:border-blue-400 hover:shadow-md transition-all flex flex-col justify-between space-y-4"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                  {offer.banner_badge || `${offer.discount_value}${offer.discount_type === 'percentage' ? '%' : '₹'} OFF`}
                </span>
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-amber-500" />
                  Valid till Dec 2027
                </span>
              </div>

              <h3 className="text-base font-bold text-slate-900">{offer.name}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{offer.description}</p>
              <div className="text-[11px] text-slate-500">
                Minimum Order: <span className="font-bold text-slate-800">{formatPrice(offer.min_order_amount)}</span>
              </div>
            </div>

            {offer.coupon_code && (
              <div className="p-3 bg-slate-50 rounded-2xl border border-dashed border-blue-300 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Coupon Code</span>
                  <span className="font-mono text-sm font-black text-blue-700 tracking-wider">
                    {offer.coupon_code}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => handleCopy(offer.coupon_code!)}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-xs transition-colors"
                >
                  {copiedCode === offer.coupon_code ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-white" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Code</span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="p-6 bg-gradient-to-r from-blue-900 to-indigo-950 text-white rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-sm sm:text-base">Ready to redeem your coupon?</h3>
          <p className="text-xs text-blue-100">Explore all available smartphones and add to your bag.</p>
        </div>
        <button
          onClick={() => onNavigate('mobiles')}
          className="px-6 py-3 bg-white text-blue-900 rounded-xl text-xs font-bold shadow-md hover:bg-blue-50 transition-colors shrink-0"
        >
          Browse Eligible Mobiles →
        </button>
      </div>
    </div>
  );
};
