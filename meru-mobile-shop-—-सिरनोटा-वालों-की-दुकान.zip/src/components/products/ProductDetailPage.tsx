import React, { useState } from 'react';
import {
  ArrowLeft,
  Star,
  ShieldCheck,
  Truck,
  CreditCard,
  Heart,
  ShoppingBag,
  Zap,
  MessageCircle,
  Share2,
  Check,
  Maximize2,
  X,
  Sparkles,
} from 'lucide-react';
import { Product, ProductVariant, SiteSettings } from '../../types/database';
import { formatPrice, createWhatsAppUrl } from '../../utils/formatters';

interface ProductDetailPageProps {
  product: Product;
  settings: SiteSettings;
  onBack: () => void;
  onAddToCart: (product: Product, variantId?: string) => void;
  onBuyNow: (product: Product, variantId?: string) => void;
  onToggleWishlist: (product: Product) => void;
  isInWishlist?: boolean;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({
  product,
  settings,
  onBack,
  onAddToCart,
  onBuyNow,
  onToggleWishlist,
  isInWishlist = false,
}) => {
  const defaultVariant = product.variants?.[0];
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | undefined>(defaultVariant);
  const [activeImage, setActiveImage] = useState<string>(product.primary_image);
  const [isZoomOpen, setIsZoomOpen] = useState<boolean>(false);
  const [copiedShare, setCopiedShare] = useState<boolean>(false);

  // Dynamic values based on variant selection
  const currentSellingPrice = selectedVariant ? selectedVariant.selling_price : product.selling_price;
  const currentMrp = selectedVariant ? selectedVariant.mrp : product.mrp;
  const currentStock = selectedVariant ? selectedVariant.stock_quantity : product.stock_quantity;
  const isOutOfStock = currentStock <= 0;

  const discountPercent =
    currentMrp > currentSellingPrice
      ? Math.round(((currentMrp - currentSellingPrice) / currentMrp) * 100)
      : product.discount_percent;

  const emiPerMonth = Math.round(currentSellingPrice / 6);

  const handleWhatsAppInquiry = () => {
    const variantDesc = selectedVariant
      ? ` (${selectedVariant.color_name}, ${selectedVariant.ram || ''} ${selectedVariant.storage || ''})`
      : '';
    const message = `Hello Meru Mobile Shop, mujhe ${product.name}${variantDesc} ke baare mein jankari chahiye. Kya yeh Tyoda Road showroom par available hai?`;
    window.open(createWhatsAppUrl(settings.whatsapp_number, message), '_blank');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.name,
        text: `Check out ${product.name} at Meru Mobile Shop, Ganj Basoda:`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2000);
    }
  };

  return (
    <div className="space-y-6 animate-page-enter">
      {/* Top Back Navigation Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold shadow-2xs transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Catalogue</span>
        </button>

        {/* Breadcrumb */}
        <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-400">
          <span>Showroom</span>
          <span>/</span>
          <span className="text-slate-600 font-medium">{product.brand_name}</span>
          <span>/</span>
          <span className="text-slate-900 font-bold truncate max-w-[200px]">{product.name}</span>
        </div>

        <button
          onClick={handleShare}
          className="p-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-2xs transition-colors"
        >
          <Share2 className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">{copiedShare ? 'Copied Link!' : 'Share'}</span>
        </button>
      </div>

      {/* Main Product Presentation Grid */}
      <div className="bg-white rounded-3xl border border-slate-200 p-4 sm:p-8 shadow-xs grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Image Gallery */}
        <div className="lg:col-span-6 space-y-4">
          <div className="relative aspect-[4/3] rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-center p-6 overflow-hidden">
            <img
              src={activeImage}
              alt={product.name}
              className="max-h-full max-w-full object-contain cursor-zoom-in transition-transform duration-300 hover:scale-105"
              onClick={() => setIsZoomOpen(true)}
            />

            {/* Badges */}
            <div className="absolute top-3 left-3 flex flex-col gap-1.5">
              {product.is_5g && (
                <span className="bg-amber-500 text-slate-950 text-xs font-black px-2 py-0.5 rounded-md shadow-xs">
                  5G Dual VoLTE
                </span>
              )}
              {discountPercent > 0 && (
                <span className="bg-red-600 text-white text-xs font-extrabold px-2 py-0.5 rounded-md shadow-xs">
                  {discountPercent}% OFF
                </span>
              )}
            </div>

            <button
              onClick={() => setIsZoomOpen(true)}
              className="absolute bottom-3 right-3 p-2 bg-white/80 backdrop-blur-xs text-slate-700 hover:bg-white rounded-xl shadow-xs transition-colors"
              title="Full screen view"
            >
              <Maximize2 className="w-4 h-4" />
            </button>

            {isOutOfStock && (
              <div className="absolute inset-0 bg-white/80 backdrop-blur-xs flex items-center justify-center">
                <span className="bg-red-600 text-white font-bold text-sm px-4 py-2 rounded-xl shadow-md">
                  Out of Stock in Showroom
                </span>
              </div>
            )}
          </div>

          {/* Thumbnails list */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <button
              onClick={() => setActiveImage(product.primary_image)}
              className={`w-16 h-16 rounded-xl border-2 p-1.5 bg-slate-50 shrink-0 overflow-hidden ${
                activeImage === product.primary_image ? 'border-blue-600 ring-2 ring-blue-100' : 'border-slate-200 opacity-70 hover:opacity-100'
              }`}
            >
              <img src={product.primary_image} alt="main" className="w-full h-full object-contain" />
            </button>
            {product.images?.map((img) => (
              <button
                key={img.id}
                onClick={() => setActiveImage(img.image_url)}
                className={`w-16 h-16 rounded-xl border-2 p-1.5 bg-slate-50 shrink-0 overflow-hidden ${
                  activeImage === img.image_url ? 'border-blue-600 ring-2 ring-blue-100' : 'border-slate-200 opacity-70 hover:opacity-100'
                }`}
              >
                <img src={img.image_url} alt="sub" className="w-full h-full object-contain" />
              </button>
            ))}
            {selectedVariant?.image_url && (
              <button
                onClick={() => setActiveImage(selectedVariant.image_url!)}
                className={`w-16 h-16 rounded-xl border-2 p-1.5 bg-slate-50 shrink-0 overflow-hidden ${
                  activeImage === selectedVariant.image_url ? 'border-blue-600 ring-2 ring-blue-100' : 'border-slate-200 opacity-70 hover:opacity-100'
                }`}
              >
                <img src={selectedVariant.image_url} alt="variant" className="w-full h-full object-contain" />
              </button>
            )}
          </div>

          {/* 0% EMI Highlight Box */}
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-2xl flex items-center gap-3.5 text-xs text-blue-900">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-sm text-blue-950">
                0% No-Cost EMI from {formatPrice(emiPerMonth)}/month
              </div>
              <p className="text-[11px] text-blue-800 mt-0.5">
                Instant 15-minute paperless approval with Bajaj Finserv, HDB, IDFC First & TVS Credit at our showroom counter.
              </p>
            </div>
          </div>
        </div>

        {/* Right Column: Title, Variants & Purchase Details */}
        <div className="lg:col-span-6 space-y-5">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200">
                {product.brand_name}
              </span>
              <span className="text-xs font-hindi text-amber-700 font-semibold">
                ★ सिरनोटा वालों की दुकान
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 leading-tight">
              {product.name}
            </h1>

            <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
              {product.short_description}
            </p>

            <div className="flex items-center gap-2 pt-1">
              <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded text-xs font-bold text-amber-800">
                <span>4.9</span>
                <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
              </div>
              <span className="text-xs text-slate-400">• Verified Ganj Basoda Customer Rating</span>
            </div>
          </div>

          {/* Price Box */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 flex items-baseline gap-3">
            <span className="text-3xl font-black text-slate-900">
              {formatPrice(currentSellingPrice)}
            </span>
            {currentMrp > currentSellingPrice && (
              <span className="text-sm text-slate-400 line-through font-medium">
                {formatPrice(currentMrp)}
              </span>
            )}
            {discountPercent > 0 && (
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Save {formatPrice(currentMrp - currentSellingPrice)} ({discountPercent}% OFF)
              </span>
            )}
          </div>

          {/* Interactive Variant Picker */}
          {product.variants && product.variants.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-800">Select Colour & Storage Variant:</span>
                {selectedVariant && (
                  <span className="text-blue-600 font-mono text-[11px]">
                    SKU: {selectedVariant.sku}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {product.variants.map((v) => {
                  const isSelected = selectedVariant?.id === v.id;
                  return (
                    <button
                      key={v.id}
                      type="button"
                      onClick={() => {
                        setSelectedVariant(v);
                        if (v.image_url) setActiveImage(v.image_url);
                      }}
                      className={`p-3 rounded-2xl border text-left text-xs transition-all flex items-center justify-between ${
                        isSelected
                          ? 'bg-blue-50/70 border-blue-600 ring-2 ring-blue-500/20 text-slate-900 font-medium'
                          : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        {v.color_hex && (
                          <span
                            className="w-4 h-4 rounded-full border border-slate-300 shadow-xs shrink-0"
                            style={{ backgroundColor: v.color_hex }}
                          />
                        )}
                        <div>
                          <div className="font-bold text-slate-900">{v.color_name}</div>
                          <div className="text-[11px] text-slate-500">
                            {v.ram ? `${v.ram} / ` : ''}{v.storage || ''}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-extrabold text-blue-700">{formatPrice(v.selling_price)}</div>
                        <div className="text-[10px] text-slate-400">
                          {v.stock_quantity > 0 ? `${v.stock_quantity} left` : 'Out of stock'}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Delivery & Warranty Points */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-start gap-2.5">
              <Truck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-slate-900">Local Ganj Basoda Delivery</div>
                <div className="text-[11px] text-slate-500">Same-day delivery or instant pickup on Tyoda Road.</div>
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-slate-900">100% Genuine Brand Bill</div>
                <div className="text-[11px] text-slate-500">{product.warranty}</div>
              </div>
            </div>
          </div>

          {/* Action Buttons: Add to Bag, Buy Now, Wishlist, WhatsApp */}
          <div className="space-y-2.5 pt-2">
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                disabled={isOutOfStock}
                onClick={() => onAddToCart(product, selectedVariant?.id)}
                className="py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 transition-all active:scale-95 cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{isOutOfStock ? 'Out of Stock' : 'Add to Bag'}</span>
              </button>

              <button
                type="button"
                disabled={isOutOfStock}
                onClick={() => onBuyNow(product, selectedVariant?.id)}
                className="py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 disabled:opacity-50 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
              >
                <Zap className="w-4 h-4" />
                <span>Buy Now (Reserve)</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => onToggleWishlist(product)}
                className={`py-2.5 px-4 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-colors ${
                  isInWishlist
                    ? 'bg-pink-50 border-pink-300 text-pink-600'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Heart className={`w-4 h-4 ${isInWishlist ? 'fill-pink-600' : ''}`} />
                <span>{isInWishlist ? 'In Wishlist' : 'Add to Wishlist'}</span>
              </button>

              <button
                type="button"
                onClick={handleWhatsAppInquiry}
                className="py-2.5 px-4 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
              >
                <MessageCircle className="w-4 h-4 text-emerald-600" />
                <span>Ask on WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Specifications & Description Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Full Specifications Sheet */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 space-y-4 shadow-xs">
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <span>Technical Specifications</span>
          </h3>

          <div className="divide-y divide-slate-100 text-xs">
            {product.specifications &&
              Object.entries(product.specifications).map(([key, val]) => (
                <div key={key} className="py-2.5 flex justify-between gap-4">
                  <span className="font-semibold text-slate-500 w-1/3">{key}</span>
                  <span className="font-medium text-slate-900 w-2/3 text-right">{val}</span>
                </div>
              ))}
          </div>
        </div>

        {/* Showroom Perks & About Model */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 space-y-3 shadow-xs">
            <h3 className="text-base font-bold text-slate-900">Showroom Overview</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              {product.description}
            </p>
          </div>

          <div className="bg-gradient-to-br from-blue-900 to-indigo-950 text-white rounded-3xl p-5 space-y-2">
            <div className="flex items-center gap-2 text-amber-300 font-hindi font-bold text-xs">
              <Sparkles className="w-4 h-4" />
              <span>सिरनोटा वालों की दुकान — स्पेशल इन-स्टोर सेवा</span>
            </div>
            <p className="text-xs text-blue-100 leading-relaxed">
              Purchase this handset at our Tyoda Road showroom to enjoy <strong>Free Data Transfer</strong> from your old phone, <strong>Laser Cut Tempered Glass Fitting</strong>, and an assured <strong>Festive Lucky Draw Ticket</strong>!
            </p>
          </div>
        </div>
      </div>

      {/* Full-Screen Zoom Modal */}
      {isZoomOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative max-w-4xl max-h-[90vh] flex flex-col items-center justify-center">
            <button
              onClick={() => setIsZoomOpen(false)}
              className="absolute -top-12 right-0 p-2 text-white/80 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={activeImage}
              alt={product.name}
              className="max-h-[80vh] max-w-full object-contain"
            />
          </div>
        </div>
      )}
    </div>
  );
};
