import React from 'react';
import { ShoppingBag, Heart, Star, Zap, Eye, ShieldCheck } from 'lucide-react';
import { Product } from '../../types/database';
import { formatPrice } from '../../utils/formatters';

interface ProductCardProps {
  product: Product;
  onOpenProduct: (product: Product) => void;
  onAddToCart: (product: Product, variantId?: string) => void;
  onToggleWishlist: (product: Product) => void;
  isInWishlist?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onOpenProduct,
  onAddToCart,
  onToggleWishlist,
  isInWishlist = false,
}) => {
  const isOutOfStock = product.stock_status === 'out_of_stock';
  const defaultVariant = product.variants?.[0];

  const discountPercent =
    product.mrp > product.selling_price
      ? Math.round(((product.mrp - product.selling_price) / product.mrp) * 100)
      : product.discount_percent;

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 hover:border-blue-400 hover:shadow-lg transition-all duration-200 flex flex-col justify-between group overflow-hidden relative">
      {/* Top Image Box */}
      <div className="relative aspect-[4/3] bg-slate-50 p-4 flex items-center justify-center overflow-hidden cursor-pointer">
        <img
          src={product.primary_image}
          alt={product.name}
          onClick={() => onOpenProduct(product)}
          className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 items-start">
          {product.is_5g && (
            <span className="bg-amber-500 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-md shadow-xs">
              5G
            </span>
          )}
          {discountPercent > 0 && (
            <span className="bg-red-600 text-white text-[10px] font-extrabold px-1.5 py-0.5 rounded-md shadow-xs">
              {discountPercent}% OFF
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-2.5 right-2.5 p-2 rounded-full backdrop-blur-xs transition-colors shadow-xs ${
            isInWishlist
              ? 'bg-pink-50 text-pink-600'
              : 'bg-white/80 text-slate-400 hover:text-pink-600 hover:bg-white'
          }`}
          title="Save to Wishlist"
          aria-label="Wishlist"
        >
          <Heart className={`w-3.5 h-3.5 ${isInWishlist ? 'fill-pink-600' : ''}`} />
        </button>

        {isOutOfStock && (
          <div className="absolute inset-0 bg-white/80 backdrop-blur-xs flex items-center justify-center text-xs font-bold text-red-600">
            Out of Stock
          </div>
        )}
      </div>

      {/* Product Content Details */}
      <div className="p-4 space-y-2.5 flex-1 flex flex-col justify-between">
        <div className="space-y-1">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-blue-700 font-bold uppercase tracking-wider">
              {product.brand_name || 'Brand'}
            </span>
            <div className="flex items-center gap-1 text-slate-500 font-semibold">
              <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
              <span>4.9</span>
            </div>
          </div>

          <h3
            onClick={() => onOpenProduct(product)}
            className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-1 cursor-pointer"
          >
            {product.name}
          </h3>

          <p className="text-[11px] text-slate-500 line-clamp-1">
            {product.short_description}
          </p>

          {/* Variants Pills */}
          {product.variants && product.variants.length > 0 && (
            <div className="flex items-center gap-1 flex-wrap pt-1">
              {product.variants.slice(0, 3).map((v) => (
                <span
                  key={v.id}
                  className="text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-medium border border-slate-200"
                >
                  {v.ram ? `${v.ram}/` : ''}{v.storage || v.color_name}
                </span>
              ))}
              {product.variants.length > 3 && (
                <span className="text-[9px] text-slate-400">
                  +{product.variants.length - 3}
                </span>
              )}
            </div>
          )}
        </div>

        {/* Pricing & Actions */}
        <div className="pt-2 border-t border-slate-100 space-y-2">
          <div className="flex items-baseline justify-between">
            <div>
              <span className="text-base sm:text-lg font-black text-slate-900">
                {formatPrice(product.selling_price)}
              </span>
              {product.mrp > product.selling_price && (
                <span className="text-xs text-slate-400 line-through ml-1.5 font-medium">
                  {formatPrice(product.mrp)}
                </span>
              )}
            </div>
            <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-1.5 py-0.5 rounded">
              0% EMI
            </span>
          </div>

          <div className="grid grid-cols-2 gap-1.5">
            <button
              type="button"
              onClick={() => onOpenProduct(product)}
              className="py-2 px-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1 transition-colors"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Details</span>
            </button>

            <button
              type="button"
              disabled={isOutOfStock}
              onClick={() => onAddToCart(product, defaultVariant?.id)}
              className="py-2 px-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs flex items-center justify-center gap-1 shadow-xs transition-colors"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Add</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
