import React from 'react';
import { Heart, Trash2, ShoppingBag, ArrowRight, ShieldCheck } from 'lucide-react';
import { WishlistItem, Product } from '../../types/database';
import { formatPrice } from '../../utils/formatters';

interface WishlistViewProps {
  wishlist: WishlistItem[];
  onOpenProduct: (product: Product) => void;
  onAddToCart: (product: Product, variantId?: string) => void;
  onRemoveFromWishlist: (product: Product) => void;
  onNavigate: (route: string) => void;
}

export const WishlistView: React.FC<WishlistViewProps> = ({
  wishlist,
  onOpenProduct,
  onAddToCart,
  onRemoveFromWishlist,
  onNavigate,
}) => {
  return (
    <div className="space-y-6 animate-page-enter max-w-5xl mx-auto">
      {/* Header */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-2 shadow-xs">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-50 text-pink-700 text-xs font-bold border border-pink-200 uppercase">
          <Heart className="w-3.5 h-3.5 fill-pink-500 text-pink-500" />
          <span>Saved Showroom Items</span>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 font-serif-display">
              My Wishlist ({wishlist.length})
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Your saved smartphones and accessories ready for booking or instant showroom pickup.
            </p>
          </div>
          {wishlist.length > 0 && (
            <button
              onClick={() => onNavigate('mobiles')}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
            >
              <span>Explore More</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {wishlist.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 rounded-full bg-pink-50 text-pink-500 flex items-center justify-center mx-auto">
            <Heart className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-slate-900">Your wishlist is empty</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Save your favourite smartphones from Samsung, Apple, Vivo, Oppo, OnePlus and accessories to review later.
            </p>
          </div>
          <button
            onClick={() => onNavigate('mobiles')}
            className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors"
          >
            Browse Smartphones
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {wishlist.map((item) => {
            const product = item.product;
            return (
              <div
                key={item.id}
                className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs hover:border-blue-300 transition-all flex flex-col justify-between space-y-3 group"
              >
                <div
                  className="cursor-pointer space-y-3"
                  onClick={() => onOpenProduct(product)}
                >
                  <div className="w-full aspect-square bg-slate-50 rounded-xl overflow-hidden flex items-center justify-center p-3 relative">
                    <img
                      src={product.primary_image}
                      alt={product.name}
                      className="w-full h-full object-contain group-hover:scale-105 transition-transform"
                    />
                    {product.is_5g && (
                      <span className="absolute top-2 left-2 bg-blue-600 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-xs">
                        5G
                      </span>
                    )}
                  </div>

                  <div>
                    <div className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">
                      {product.brand_id.replace('brand-', '')}
                    </div>
                    <h3 className="font-bold text-slate-900 text-xs sm:text-sm line-clamp-2 group-hover:text-blue-600 transition-colors">
                      {product.name}
                    </h3>
                  </div>

                  <div className="flex items-baseline gap-2">
                    <span className="text-base font-black text-slate-900">
                      {formatPrice(product.selling_price)}
                    </span>
                    {product.mrp > product.selling_price && (
                      <span className="text-xs text-slate-400 line-through">
                        {formatPrice(product.mrp)}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                  <button
                    onClick={() => onAddToCart(product)}
                    className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1 shadow-xs"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Add to Bag</span>
                  </button>

                  <button
                    onClick={() => onRemoveFromWishlist(product)}
                    className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors"
                    title="Remove from wishlist"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
