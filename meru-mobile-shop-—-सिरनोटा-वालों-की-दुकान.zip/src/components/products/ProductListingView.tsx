import React, { useState, useMemo } from 'react';
import { Filter, SlidersHorizontal, Check, Smartphone, X, ArrowUpDown } from 'lucide-react';
import { Product, Brand, Category } from '../../types/database';
import { ProductCard } from './ProductCard';

interface ProductListingViewProps {
  title: string;
  subtitle?: string;
  initialBrandSlug?: string;
  initialCategorySlug?: string;
  products: Product[];
  brands: Brand[];
  categories: Category[];
  onOpenProduct: (product: Product) => void;
  onAddToCart: (product: Product, variantId?: string) => void;
  onToggleWishlist: (product: Product) => void;
  wishlistIds: Set<string>;
}

export const ProductListingView: React.FC<ProductListingViewProps> = ({
  title,
  subtitle,
  initialBrandSlug,
  initialCategorySlug,
  products,
  brands,
  categories,
  onOpenProduct,
  onAddToCart,
  onToggleWishlist,
  wishlistIds,
}) => {
  const [selectedBrandSlug, setSelectedBrandSlug] = useState<string>(initialBrandSlug || 'all');
  const [selectedCategorySlug, setSelectedCategorySlug] = useState<string>(initialCategorySlug || 'all');
  const [priceRange, setPriceRange] = useState<string>('all');
  const [only5G, setOnly5G] = useState<boolean>(false);
  const [onlyInStock, setOnlyInStock] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'featured' | 'price_low' | 'price_high' | 'newest'>('featured');
  const [mobileFilterOpen, setMobileFilterOpen] = useState<boolean>(false);

  // Filter computation
  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => {
        if (!p.is_active) return false;

        // Brand
        if (selectedBrandSlug !== 'all') {
          const brand = brands.find((b) => b.slug === selectedBrandSlug);
          if (brand && p.brand_id !== brand.id) return false;
        }

        // Category
        if (selectedCategorySlug !== 'all') {
          if (selectedCategorySlug === '5g-phones' && !p.is_5g) return false;
          else if (selectedCategorySlug === 'budget-phones' && p.selling_price > 16000) return false;
          else {
            const cat = categories.find((c) => c.slug === selectedCategorySlug);
            if (cat && p.category_id !== cat.id) return false;
          }
        }

        // Price
        if (priceRange === 'under_10k' && p.selling_price > 10000) return false;
        if (priceRange === '10k_20k' && (p.selling_price < 10000 || p.selling_price > 20000)) return false;
        if (priceRange === '20k_40k' && (p.selling_price < 20000 || p.selling_price > 40000)) return false;
        if (priceRange === 'above_40k' && p.selling_price < 40000) return false;

        // 5G
        if (only5G && !p.is_5g) return false;

        // Stock
        if (onlyInStock && p.stock_status === 'out_of_stock') return false;

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price_low') return a.selling_price - b.selling_price;
        if (sortBy === 'price_high') return b.selling_price - a.selling_price;
        if (sortBy === 'newest') return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
        return (b.is_bestseller ? 1 : 0) - (a.is_bestseller ? 1 : 0);
      });
  }, [
    products,
    selectedBrandSlug,
    selectedCategorySlug,
    priceRange,
    only5G,
    onlyInStock,
    sortBy,
    brands,
    categories,
  ]);

  const resetFilters = () => {
    setSelectedBrandSlug('all');
    setSelectedCategorySlug('all');
    setPriceRange('all');
    setOnly5G(false);
    setOnlyInStock(false);
    setSortBy('featured');
  };

  return (
    <div className="space-y-6 animate-page-enter">
      {/* Top Header & Sort Strip */}
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 font-serif-display">
            {title}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            {subtitle || `Showing ${filteredProducts.length} devices available at Meru Mobile Shop`}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Mobile Filter Trigger Button */}
          <button
            onClick={() => setMobileFilterOpen(true)}
            className="lg:hidden px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors"
          >
            <Filter className="w-4 h-4 text-blue-600" />
            <span>Filters</span>
          </button>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-700">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-transparent font-semibold text-slate-800 focus:outline-none cursor-pointer"
            >
              <option value="featured">Featured / Bestsellers</option>
              <option value="price_low">Price: Low to High</option>
              <option value="price_high">Price: High to Low</option>
              <option value="newest">New Arrivals</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Grid with Sidebar Filter */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Desktop Sidebar Filters */}
        <aside className="hidden lg:block lg:col-span-3 bg-white rounded-3xl border border-slate-200 p-5 space-y-5 shadow-xs sticky top-24">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="font-bold text-xs uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
              <Filter className="w-4 h-4 text-blue-600" />
              <span>Filter Options</span>
            </h3>
            <button
              onClick={resetFilters}
              className="text-[11px] text-blue-600 hover:underline font-semibold"
            >
              Reset
            </button>
          </div>

          {/* Brand Filter */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-800 block">Brand</span>
            <div className="space-y-1 text-xs">
              <button
                onClick={() => setSelectedBrandSlug('all')}
                className={`w-full text-left px-2 py-1 rounded-lg transition-colors ${
                  selectedBrandSlug === 'all'
                    ? 'bg-blue-50 text-blue-700 font-bold'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                All Brands ({products.length})
              </button>
              {brands.map((b) => (
                <button
                  key={b.id}
                  onClick={() => setSelectedBrandSlug(b.slug)}
                  className={`w-full text-left px-2 py-1 rounded-lg transition-colors ${
                    selectedBrandSlug === b.slug
                      ? 'bg-blue-50 text-blue-700 font-bold'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {b.name}
                </button>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div className="space-y-2 border-t border-slate-100 pt-3">
            <span className="text-xs font-bold text-slate-800 block">Price Range</span>
            <div className="space-y-1.5 text-xs text-slate-600">
              {[
                { label: 'All Prices', val: 'all' },
                { label: 'Under ₹10,000', val: 'under_10k' },
                { label: '₹10,000 to ₹20,000', val: '10k_20k' },
                { label: '₹20,000 to ₹40,000', val: '20k_40k' },
                { label: 'Above ₹40,000', val: 'above_40k' },
              ].map((p) => (
                <label key={p.val} className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="priceRange"
                    checked={priceRange === p.val}
                    onChange={() => setPriceRange(p.val)}
                    className="accent-blue-600"
                  />
                  <span>{p.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Feature Toggles */}
          <div className="space-y-2 border-t border-slate-100 pt-3 text-xs text-slate-700">
            <label className="flex items-center gap-2 cursor-pointer font-medium">
              <input
                type="checkbox"
                checked={only5G}
                onChange={(e) => setOnly5G(e.target.checked)}
                className="accent-blue-600"
              />
              <span>5G Enabled Devices Only</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer font-medium">
              <input
                type="checkbox"
                checked={onlyInStock}
                onChange={(e) => setOnlyInStock(e.target.checked)}
                className="accent-blue-600"
              />
              <span>In Stock in Showroom Only</span>
            </label>
          </div>
        </aside>

        {/* Products Grid */}
        <main className="lg:col-span-9">
          {filteredProducts.length === 0 ? (
            <div className="py-20 text-center bg-white rounded-3xl border border-slate-200 p-8 space-y-3">
              <Smartphone className="w-12 h-12 text-slate-300 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">
                No matching phones or accessories found
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Try selecting a different brand or resetting your price filters.
              </p>
              <button
                onClick={resetFilters}
                className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredProducts.map((p) => (
                <ProductCard
                  key={p.id}
                  product={p}
                  onOpenProduct={onOpenProduct}
                  onAddToCart={onAddToCart}
                  onToggleWishlist={onToggleWishlist}
                  isInWishlist={wishlistIds.has(p.id)}
                />
              ))}
            </div>
          )}
        </main>
      </div>

      {/* Mobile Filters Drawer */}
      {mobileFilterOpen && (
        <div className="fixed inset-0 z-50 flex bg-black/60 backdrop-blur-xs lg:hidden">
          <div className="w-72 bg-white h-full p-5 flex flex-col justify-between shadow-2xl overflow-y-auto">
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h3 className="font-bold text-slate-900 text-sm">Filters</h3>
                <button onClick={() => setMobileFilterOpen(false)}>
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              {/* Brands */}
              <div className="space-y-1 text-xs">
                <span className="font-bold text-slate-900 block mb-1">Select Brand</span>
                <select
                  value={selectedBrandSlug}
                  onChange={(e) => setSelectedBrandSlug(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 text-xs"
                >
                  <option value="all">All Brands</option>
                  {brands.map((b) => (
                    <option key={b.id} value={b.slug}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Price */}
              <div className="space-y-1 text-xs">
                <span className="font-bold text-slate-900 block mb-1">Price Range</span>
                <select
                  value={priceRange}
                  onChange={(e) => setPriceRange(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 text-xs"
                >
                  <option value="all">All Prices</option>
                  <option value="under_10k">Under ₹10,000</option>
                  <option value="10k_20k">₹10,000 to ₹20,000</option>
                  <option value="20k_40k">₹20,000 to ₹40,000</option>
                  <option value="above_40k">Above ₹40,000</option>
                </select>
              </div>

              {/* Toggles */}
              <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
                <label className="flex items-center gap-2 cursor-pointer font-medium">
                  <input
                    type="checkbox"
                    checked={only5G}
                    onChange={(e) => setOnly5G(e.target.checked)}
                    className="accent-blue-600"
                  />
                  <span>5G Phones Only</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer font-medium">
                  <input
                    type="checkbox"
                    checked={onlyInStock}
                    onChange={(e) => setOnlyInStock(e.target.checked)}
                    className="accent-blue-600"
                  />
                  <span>In Stock Only</span>
                </label>
              </div>
            </div>

            <button
              onClick={() => setMobileFilterOpen(false)}
              className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl text-xs"
            >
              Apply Filters ({filteredProducts.length} Results)
            </button>
          </div>
          <div className="flex-1" onClick={() => setMobileFilterOpen(false)} />
        </div>
      )}
    </div>
  );
};
