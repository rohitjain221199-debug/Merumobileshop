import React, { useState } from 'react';
import { User, Phone, MapPin, Package, Clock, CheckCircle2, ChevronRight, ShoppingBag, ExternalLink, ShieldCheck } from 'lucide-react';
import { Order, SiteSettings } from '../../types/database';
import { formatPrice, formatDate } from '../../utils/formatters';

interface AccountViewProps {
  settings: SiteSettings;
  orders: Order[];
  onNavigate: (route: string) => void;
  onTrackOrder: (orderId: string) => void;
}

export const AccountView: React.FC<AccountViewProps> = ({
  settings,
  orders,
  onNavigate,
  onTrackOrder,
}) => {
  const [customerPhone, setCustomerPhone] = useState('');
  const [phoneFilter, setPhoneFilter] = useState('');

  const filteredOrders = phoneFilter
    ? orders.filter((o) => o.customer_phone.includes(phoneFilter.trim()))
    : orders.slice(0, 5);

  const handleLookup = (e: React.FormEvent) => {
    e.preventDefault();
    setPhoneFilter(customerPhone.trim());
  };

  return (
    <div className="space-y-8 animate-page-enter max-w-4xl mx-auto">
      {/* Account Overview Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col sm:flex-row items-center gap-5">
          <div className="w-18 h-18 rounded-2xl bg-gradient-to-tr from-blue-700 to-indigo-600 flex items-center justify-center text-white text-2xl font-bold shadow-md shadow-blue-600/20 shrink-0">
            <User className="w-9 h-9" />
          </div>
          <div className="space-y-1 text-center sm:text-left flex-1">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-slate-900">
                Customer Account & Orders
              </h1>
              <span className="inline-block px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold text-xs border border-emerald-200">
                Meru Member
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Check your reserved smartphones, delivery updates, and store invoices from Meru Mobile Shop.
            </p>
          </div>
        </div>
      </div>

      {/* Order Lookup by Mobile */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Package className="w-4 h-4 text-blue-600" />
            <span>Find Orders by Mobile Number</span>
          </h2>
          {phoneFilter && (
            <button
              onClick={() => {
                setPhoneFilter('');
                setCustomerPhone('');
              }}
              className="text-xs text-blue-600 hover:underline font-semibold"
            >
              Show all recent
            </button>
          )}
        </div>

        <form onSubmit={handleLookup} className="flex gap-2">
          <div className="relative flex-1">
            <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="tel"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              placeholder="Enter your 10-digit mobile number..."
              className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition-colors shadow-xs"
          >
            Find Orders
          </button>
        </form>
      </div>

      {/* Orders List */}
      <div className="space-y-4">
        <h2 className="text-base font-bold text-slate-900">
          {phoneFilter ? `Orders for ${phoneFilter}` : 'Recent Orders'}
        </h2>

        {filteredOrders.length === 0 ? (
          <div className="bg-white rounded-3xl border border-slate-200 p-8 text-center space-y-3">
            <Package className="w-12 h-12 text-slate-300 mx-auto" />
            <div className="text-sm font-bold text-slate-800">No orders found</div>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              {phoneFilter
                ? 'We could not find any order with that phone number. Please check the number or place your first order.'
                : 'You have no saved orders yet. Browse our smartphones and make a reservation.'}
            </p>
            <button
              onClick={() => onNavigate('mobiles')}
              className="px-5 py-2 bg-blue-600 text-white text-xs font-bold rounded-xl shadow-xs hover:bg-blue-700"
            >
              Browse Mobiles
            </button>
          </div>
        ) : (
          filteredOrders.map((order) => (
            <div
              key={order.id}
              className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4 hover:border-blue-300 transition-colors"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-slate-900">{order.id}</span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        order.order_status === 'Delivered'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : order.order_status === 'Cancelled'
                          ? 'bg-red-50 text-red-700 border border-red-200'
                          : 'bg-blue-50 text-blue-700 border border-blue-200'
                      }`}
                    >
                      {order.order_status}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Placed on {formatDate(order.created_at)} • Payment: {order.payment_method} ({order.payment_status})
                  </div>
                </div>

                <div className="text-right flex items-center justify-between sm:justify-end gap-3">
                  <div>
                    <div className="text-xs text-slate-400">Total Amount</div>
                    <div className="text-sm font-black text-slate-900">{formatPrice(order.final_amount)}</div>
                  </div>
                  <button
                    onClick={() => {
                      onTrackOrder(order.id);
                      onNavigate('tracking');
                    }}
                    className="px-3 py-1.5 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-xl text-xs font-bold transition-colors flex items-center gap-1 border border-blue-200"
                  >
                    <span>Track</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Order Items */}
              <div className="space-y-2">
                {order.items.map((item) => (
                  <div key={item.id} className="flex items-center gap-3 py-1">
                    <img
                      src={item.image_url}
                      alt={item.product_name}
                      className="w-12 h-12 rounded-xl object-cover bg-slate-100 border border-slate-200 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold text-slate-800 truncate">{item.product_name}</div>
                      <div className="text-[11px] text-slate-400">{item.variant_description} × {item.quantity}</div>
                    </div>
                    <div className="text-xs font-bold text-slate-800">{formatPrice(item.subtotal)}</div>
                  </div>
                ))}
              </div>

              <div className="pt-2 text-xs text-slate-500 flex items-center justify-between bg-slate-50 p-3 rounded-2xl">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>Delivery to: {order.shipping_address?.city || 'Ganj Basoda'} ({order.shipping_address?.pincode || '464221'})</span>
                </span>
                <span className="font-semibold text-slate-700">Phone: {order.customer_phone}</span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Showroom Direct Assurance */}
      <div className="bg-blue-50/60 rounded-3xl border border-blue-100 p-5 flex items-center gap-4 text-xs text-slate-600">
        <ShieldCheck className="w-6 h-6 text-blue-600 shrink-0" />
        <div>
          <span className="font-bold text-slate-900 block">Meru Mobile Shop Tyoda Road Warranty</span>
          Show your order ID or mobile number at our showroom counter to claim quick bill duplicate or warranty assistance.
        </div>
      </div>
    </div>
  );
};
