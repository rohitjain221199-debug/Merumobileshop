import React, { useState } from 'react';
import { Truck, CheckCircle2, ShieldCheck, MapPin, Phone, User, CreditCard, ArrowRight, ArrowLeft } from 'lucide-react';
import { CartItem, SiteSettings, Order, PaymentMethod } from '../../types/database';
import { formatPrice } from '../../utils/formatters';
import { StoreService } from '../../services/storeService';

interface CheckoutViewProps {
  cart: CartItem[];
  settings: SiteSettings;
  onOrderSuccess: (order: Order) => void;
  onNavigate: (route: string) => void;
}

export const CheckoutView: React.FC<CheckoutViewProps> = ({
  cart,
  settings,
  onOrderSuccess,
  onNavigate,
}) => {
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [addressLine1, setAddressLine1] = useState('');
  const [landmark, setLandmark] = useState('');
  const [city, setCity] = useState('Ganj Basoda');
  const [pincode, setPincode] = useState('464221');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('COD');
  const [orderNotes, setOrderNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  const subtotal = cart.reduce((acc, item) => acc + item.variant.selling_price * item.quantity, 0);
  const deliveryCharge = subtotal >= settings.free_delivery_above || subtotal === 0 ? 0 : 50;
  const finalAmount = subtotal + deliveryCharge;

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !phone || !addressLine1) return;

    setIsSubmitting(true);

    const orderItems = cart.map((item) => ({
      id: `item-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      order_id: '',
      product_id: item.product_id,
      product_name: item.product.name,
      variant_id: item.variant_id,
      variant_description: `${item.variant.color_name}${item.variant.ram ? ` - ${item.variant.ram}/${item.variant.storage}` : ''}`,
      image_url: item.variant.image_url || item.product.primary_image,
      price: item.variant.selling_price,
      mrp: item.variant.mrp,
      quantity: item.quantity,
      subtotal: item.variant.selling_price * item.quantity,
    }));

    const newOrder = await StoreService.createOrder({
      customer_name: fullName,
      customer_phone: phone,
      customer_email: email || undefined,
      items: orderItems,
      shipping_address: {
        id: `addr-${Date.now()}`,
        full_name: fullName,
        phone,
        address_line1: addressLine1,
        landmark: landmark || undefined,
        city,
        state: 'Madhya Pradesh',
        pincode,
      },
      subtotal,
      discount_amount: 0,
      delivery_charge: deliveryCharge,
      final_amount: finalAmount,
      payment_method: paymentMethod,
      payment_status: 'pending',
      order_status: 'Pending',
      order_notes: orderNotes || undefined,
    });

    setIsSubmitting(false);
    setCreatedOrder(newOrder);
    onOrderSuccess(newOrder);
  };

  return (
    <div className="space-y-6 animate-page-enter max-w-4xl mx-auto">
      {/* Top Back Button */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigate('cart')}
          className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-blue-600"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Shopping Bag</span>
        </button>
        <span className="text-xs text-amber-600 font-hindi font-bold">
          ★ {settings.brand_tagline}
        </span>
      </div>

      {createdOrder ? (
        /* Order Success Card */
        <div className="p-8 bg-white rounded-3xl border border-emerald-200 text-center space-y-4 shadow-sm">
          <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 mx-auto flex items-center justify-center">
            <CheckCircle2 className="w-9 h-9" />
          </div>

          <div className="space-y-1">
            <h2 className="text-2xl font-black text-slate-900 font-serif-display">
              Order Confirmed & Device Reserved!
            </h2>
            <p className="text-xs text-slate-500">
              Thank you, <span className="font-semibold text-slate-900">{createdOrder.customer_name}</span>. Your phone/accessory has been recorded at Meru Mobile Shop showroom.
            </p>
          </div>

          <div className="p-4 bg-slate-50 max-w-sm mx-auto rounded-2xl border border-slate-200 text-xs space-y-1">
            <div className="text-slate-500">Order Reference Number:</div>
            <div className="font-mono text-base font-extrabold text-blue-600">
              {createdOrder.order_number}
            </div>
            <div className="text-slate-500 pt-1">
              Payable: <span className="text-slate-900 font-bold">{formatPrice(createdOrder.final_amount)}</span> via {createdOrder.payment_method}
            </div>
          </div>

          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Maneesh Jain or our Ganj Basoda showroom executive will confirm handover time via call or WhatsApp on{' '}
            <span className="font-semibold text-slate-900">{createdOrder.customer_phone}</span>.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-3">
            <button
              onClick={() => onNavigate('tracking')}
              className="w-full sm:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-600/20"
            >
              Track Live Order Timeline →
            </button>

            <button
              onClick={() => onNavigate('home')}
              className="w-full sm:w-auto px-5 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
            >
              Return to Homepage
            </button>
          </div>
        </div>
      ) : cart.length === 0 ? (
        <div className="py-16 text-center bg-white rounded-3xl border border-slate-200 p-6 space-y-2">
          <p className="text-xs text-slate-500">No devices in bag to checkout.</p>
          <button
            onClick={() => onNavigate('mobiles')}
            className="text-xs text-blue-600 font-bold hover:underline"
          >
            Explore Phones →
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmitOrder} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            {/* Left: Address & Customer Details */}
            <div className="md:col-span-7 bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 space-y-4 shadow-xs">
              <div>
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <User className="w-4 h-4 text-blue-600" />
                  <span>Delivery Address & Customer Info</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Enter your address in Ganj Basoda or nearby Vidisha district
                </p>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Ramesh Sharma"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Mobile Number (WhatsApp) *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="10-digit mobile number"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Email (Optional)
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="For GST invoice copy"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Street Address / Mohalla *
                </label>
                <input
                  type="text"
                  required
                  value={addressLine1}
                  onChange={(e) => setAddressLine1(e.target.value)}
                  placeholder="House/Shop no., Road, Colony"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">Landmark</label>
                  <input
                    type="text"
                    value={landmark}
                    onChange={(e) => setLandmark(e.target.value)}
                    placeholder="Near Temple/School"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">City</label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-xs text-slate-900 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">Pincode</label>
                  <input
                    type="text"
                    value={pincode}
                    onChange={(e) => setPincode(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-xs text-slate-900 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Order Notes (Optional)
                </label>
                <input
                  type="text"
                  value={orderNotes}
                  onChange={(e) => setOrderNotes(e.target.value)}
                  placeholder="e.g. Please bring laser tempered glass along"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            {/* Right: Payment & Summary */}
            <div className="md:col-span-5 space-y-4">
              <div className="bg-white rounded-3xl border border-slate-200 p-5 space-y-4 shadow-xs">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                  <CreditCard className="w-4 h-4 text-blue-600" />
                  <span>Payment Options</span>
                </h3>

                <div className="space-y-2">
                  <label
                    className={`p-3 rounded-2xl border flex items-start gap-3 cursor-pointer transition-all ${
                      paymentMethod === 'COD'
                        ? 'bg-blue-50/70 border-blue-600 ring-2 ring-blue-500/20 text-slate-900'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'COD'}
                      onChange={() => setPaymentMethod('COD')}
                      className="accent-blue-600 mt-0.5"
                    />
                    <div>
                      <div className="text-xs font-bold">Cash on Delivery (COD)</div>
                      <div className="text-[11px] text-slate-500">
                        Pay cash or UPI upon doorstep delivery in Ganj Basoda.
                      </div>
                    </div>
                  </label>

                  <label
                    className={`p-3 rounded-2xl border flex items-start gap-3 cursor-pointer transition-all ${
                      paymentMethod === 'STORE_PICKUP_PAY'
                        ? 'bg-blue-50/70 border-blue-600 ring-2 ring-blue-500/20 text-slate-900'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'STORE_PICKUP_PAY'}
                      onChange={() => setPaymentMethod('STORE_PICKUP_PAY')}
                      className="accent-blue-600 mt-0.5"
                    />
                    <div>
                      <div className="text-xs font-bold">In-Store Collection & Pay (Tyoda Road)</div>
                      <div className="text-[11px] text-slate-500">
                        Collect sealed unit at showroom; pay via Cash, Card, 0% EMI or UPI.
                      </div>
                    </div>
                  </label>

                  <label
                    className={`p-3 rounded-2xl border flex items-start gap-3 cursor-pointer transition-all ${
                      paymentMethod === 'UPI_QR'
                        ? 'bg-blue-50/70 border-blue-600 ring-2 ring-blue-500/20 text-slate-900'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'UPI_QR'}
                      onChange={() => setPaymentMethod('UPI_QR')}
                      className="accent-blue-600 mt-0.5"
                    />
                    <div>
                      <div className="text-xs font-bold">Manual Shop UPI QR / Advance</div>
                      <div className="text-[11px] text-slate-500">
                        Pay directly via Meru Mobile Shop verified Merchant UPI QR code.
                      </div>
                    </div>
                  </label>
                </div>

                {/* Items preview & total */}
                <div className="space-y-2 border-t border-slate-100 pt-3 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Items ({cart.length}):</span>
                    <span className="font-bold text-slate-900">{formatPrice(subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Delivery:</span>
                    <span className={deliveryCharge === 0 ? 'text-emerald-600 font-bold' : 'text-slate-900'}>
                      {deliveryCharge === 0 ? 'FREE' : formatPrice(deliveryCharge)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm font-black text-slate-900 pt-1 border-t border-slate-100">
                    <span>Final Payable:</span>
                    <span className="text-blue-600">{formatPrice(finalAmount)}</span>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 transition-all active:scale-95 cursor-pointer"
                >
                  <span>{isSubmitting ? 'Registering Order...' : 'CONFIRM ORDER & RESERVE'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </form>
      )}
    </div>
  );
};
