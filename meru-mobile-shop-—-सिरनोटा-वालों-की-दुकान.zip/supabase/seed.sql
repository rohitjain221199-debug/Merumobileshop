-- ========================================================================
-- MERU MOBILE SHOP — SEED DATA SCRIPT
-- Brand: सिरनोटा वालों की दुकान (Owner: Maneesh Jain)
-- Location: Tyoda Road, Ganj Basoda, District Vidisha, Madhya Pradesh - 464221
-- ========================================================================

-- Insert Initial Site Settings
INSERT INTO public.site_settings (
  id, shop_name, brand_tagline, owner_name, phone, whatsapp_number, email,
  address_street, address_area, address_city, address_district, address_state,
  address_pincode, landmark, google_maps_url, opening_hours, about_text,
  announcement_bar_text, free_delivery_above, cod_available
) VALUES (
  'current',
  'MERU MOBILE SHOP',
  'सिरनोटा वालों की दुकान',
  'Maneesh Jain',
  '+91 98260 00000',
  '919826000000',
  'merumobileshop@gmail.com',
  'Tyoda Road, Near Pawan Auto Mobile / Old Bus Stand',
  'Tyoda Road',
  'Ganj Basoda',
  'Vidisha',
  'Madhya Pradesh',
  '464221',
  'Near Pawan Auto Mobile, Opp. Old Bus Stand',
  'https://maps.google.com/?q=Ganj+Basoda+Vidisha+Madhya+Pradesh',
  '9:30 AM – 9:30 PM (Open All 7 Days)',
  'Meru Mobile Shop is Ganj Basoda’s most trusted multi-brand mobile showroom, widely known in the region as "सिरनोटा वालों की दुकान". Founded and run by Maneesh Jain, we have served thousands of happy customers with 100% genuine mobiles, transparent pricing, instant 0% EMI financing, and authentic post-sale support.',
  '🎉 सिरनोटा वालों की दुकान — गंज बासोदा में सबसे विश्वसनीय मोबाइल शॉप | 0% EMI सुविधा उपलब्ध | हर स्मार्टफोन पर लकी ड्रॉ!',
  999.00,
  true
) ON CONFLICT (id) DO UPDATE SET updated_at = NOW();

-- Insert Brands
INSERT INTO public.brands (id, name, slug, logo_url, display_order, is_active, featured) VALUES
('b-samsung', 'Samsung', 'samsung', 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?q=80&w=240&auto=format&fit=crop', 1, true, true),
('b-vivo', 'Vivo', 'vivo', 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=240&auto=format&fit=crop', 2, true, true),
('b-oppo', 'Oppo', 'oppo', 'https://images.unsplash.com/photo-1580910051074-3eb694886505?q=80&w=240&auto=format&fit=crop', 3, true, true),
('b-oneplus', 'OnePlus', 'oneplus', 'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?q=80&w=240&auto=format&fit=crop', 4, true, true),
('b-realme', 'Realme', 'realme', 'https://images.unsplash.com/photo-1512499617640-c74ae3a79d37?q=80&w=240&auto=format&fit=crop', 5, true, true),
('b-redmi', 'Redmi / Xiaomi', 'redmi', 'https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?q=80&w=240&auto=format&fit=crop', 6, true, true),
('b-apple', 'Apple', 'apple', 'https://images.unsplash.com/photo-1621768216002-5ac171876625?q=80&w=240&auto=format&fit=crop', 7, true, true),
('b-motorola', 'Motorola', 'motorola', 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?q=80&w=240&auto=format&fit=crop', 8, true, true),
('b-boat', 'boAt', 'boat', 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?q=80&w=240&auto=format&fit=crop', 9, true, true),
('b-noise', 'Noise', 'noise', 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=240&auto=format&fit=crop', 10, true, true)
ON CONFLICT (id) DO NOTHING;

-- Insert Categories
INSERT INTO public.categories (id, name, slug, description, icon_name, image_url, display_order, is_active) VALUES
('cat-smartphones', 'Smartphones', 'smartphones', 'Android & iOS phones across all budgets and 5G bands', 'Smartphone', 'https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?q=80&w=600&auto=format&fit=crop', 1, true),
('cat-earbuds', 'Earbuds & Headphones', 'earbuds-headphones', 'True wireless stereo earbuds, sports neckbands and ANC headphones', 'Headphones', 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?q=80&w=600&auto=format&fit=crop', 2, true),
('cat-speakers', 'Bluetooth Speakers', 'bluetooth-speakers', 'Portable waterproof speakers for crystal bass and parties', 'Volume2', 'https://images.unsplash.com/photo-1545454675-3531b543be5d?q=80&w=600&auto=format&fit=crop', 3, true),
('cat-smartwatches', 'Smart Watches', 'smart-watches', 'Bluetooth calling, sport fitness tracking, AMOLED touch screens', 'Watch', 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?q=80&w=600&auto=format&fit=crop', 4, true),
('cat-powerbanks', 'Power Banks', 'power-banks', 'Fast charging high capacity 10000mAh & 20000mAh units', 'BatteryCharging', 'https://images.unsplash.com/photo-1609592426815-5e608034b225?q=80&w=600&auto=format&fit=crop', 5, true),
('cat-chargers', 'Chargers & Cables', 'chargers-cables', 'SuperVOOC, GaN 65W, Warp & Apple lightning charging accessories', 'Zap', 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=600&auto=format&fit=crop', 6, true),
('cat-covers', 'Cases & Tempered Glass', 'covers-glass', 'Rugged military cases, silicone soft covers & UV glue edge glass', 'ShieldCheck', 'https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?q=80&w=600&auto=format&fit=crop', 7, true)
ON CONFLICT (id) DO NOTHING;

-- Insert Lucky Draw Prizes
INSERT INTO public.lucky_draw_prizes (id, name, image_url, total_quantity, remaining_quantity, winning_chance_percent, is_active) VALUES
('prz-1', 'VIP Heavy-Duty Travel Trolley Bag (Bumper Gift)', 'https://images.unsplash.com/photo-1581553680321-4fffae59fccd?q=80&w=600&auto=format&fit=crop', 10, 7, 5.0, true),
('prz-2', 'Smart Induction Cooktop (Festival Edition)', 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?q=80&w=600&auto=format&fit=crop', 15, 9, 8.0, true),
('prz-3', 'Noise BT Calling Smartwatch (1.96" AMOLED)', 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=600&auto=format&fit=crop', 25, 16, 15.0, true),
('prz-4', 'boAt True Wireless Earbuds (ANC)', 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?q=80&w=600&auto=format&fit=crop', 35, 24, 22.0, true),
('prz-5', '10000mAh Fast Charging Power Bank', 'https://images.unsplash.com/photo-1609592426815-5e608034b225?q=80&w=600&auto=format&fit=crop', 40, 28, 25.0, true),
('prz-6', 'Meru Premium Mobile Care Kit & Tempered Glass', 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=600&auto=format&fit=crop', 100, 76, 25.0, true)
ON CONFLICT (id) DO NOTHING;
