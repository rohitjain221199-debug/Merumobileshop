-- ========================================================================
-- MERU MOBILE SHOP — SUPABASE PRODUCTION DATABASE SCHEMA & RLS POLICIES
-- Location: Ganj Basoda, Madhya Pradesh
-- Brand: सिरनोटा वालों की दुकान (Owner: Maneesh Jain)
-- ========================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. USER ROLES ENUM
DO $$ BEGIN
    CREATE TYPE user_role_type AS ENUM ('super_admin', 'admin', 'manager', 'staff', 'customer');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- 2. ORDER STATUS ENUM
DO $$ BEGIN
    CREATE TYPE order_status_type AS ENUM (
      'Pending', 'Confirmed', 'Processing', 'Packed', 'Shipped', 
      'Out for Delivery', 'Delivered', 'Cancelled', 'Returned', 'Refunded'
    );
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- 3. PROFILES TABLE (Linked with Supabase auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    phone VARCHAR(20) NOT NULL UNIQUE,
    full_name VARCHAR(255) NOT NULL,
    role user_role_type DEFAULT 'customer'::user_role_type NOT NULL,
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 4. USER ROLES TABLE
CREATE TABLE IF NOT EXISTS public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    role user_role_type NOT NULL,
    assigned_by UUID REFERENCES public.profiles(id),
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    UNIQUE(user_id, role)
);

-- 5. BRANDS TABLE
CREATE TABLE IF NOT EXISTS public.brands (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(150) NOT NULL UNIQUE,
    slug VARCHAR(150) NOT NULL UNIQUE,
    logo_url TEXT NOT NULL,
    display_order INT DEFAULT 0 NOT NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    featured BOOLEAN DEFAULT FALSE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 6. CATEGORIES TABLE
CREATE TABLE IF NOT EXISTS public.categories (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    slug VARCHAR(150) NOT NULL UNIQUE,
    description TEXT,
    icon_name VARCHAR(50),
    image_url TEXT,
    display_order INT DEFAULT 0 NOT NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 7. PRODUCTS TABLE
CREATE TABLE IF NOT EXISTS public.products (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    brand_id VARCHAR(100) REFERENCES public.brands(id) ON DELETE RESTRICT,
    category_id VARCHAR(100) REFERENCES public.categories(id) ON DELETE RESTRICT,
    model VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    short_description TEXT NOT NULL,
    specifications JSONB DEFAULT '{}'::jsonb NOT NULL,
    mrp NUMERIC(12, 2) NOT NULL,
    selling_price NUMERIC(12, 2) NOT NULL,
    offer_price NUMERIC(12, 2),
    discount_percent INT DEFAULT 0 NOT NULL,
    stock_quantity INT DEFAULT 0 NOT NULL,
    stock_status VARCHAR(50) DEFAULT 'in_stock' NOT NULL,
    sku VARCHAR(100) NOT NULL UNIQUE,
    barcode VARCHAR(100),
    warranty VARCHAR(255) NOT NULL,
    is_5g BOOLEAN DEFAULT FALSE NOT NULL,
    network_type VARCHAR(100),
    primary_image TEXT NOT NULL,
    is_featured BOOLEAN DEFAULT FALSE NOT NULL,
    is_new_arrival BOOLEAN DEFAULT FALSE NOT NULL,
    is_bestseller BOOLEAN DEFAULT FALSE NOT NULL,
    is_offer_product BOOLEAN DEFAULT FALSE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    seo_title VARCHAR(255),
    seo_description TEXT,
    seo_keywords TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 8. PRODUCT VARIANTS TABLE
CREATE TABLE IF NOT EXISTS public.product_variants (
    id VARCHAR(100) PRIMARY KEY,
    product_id VARCHAR(100) NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    sku VARCHAR(100) NOT NULL UNIQUE,
    color_name VARCHAR(100) NOT NULL,
    color_hex VARCHAR(20),
    ram VARCHAR(50),
    storage VARCHAR(50),
    mrp NUMERIC(12, 2) NOT NULL,
    selling_price NUMERIC(12, 2) NOT NULL,
    stock_quantity INT DEFAULT 0 NOT NULL,
    image_url TEXT,
    is_default BOOLEAN DEFAULT FALSE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 9. PRODUCT IMAGES TABLE
CREATE TABLE IF NOT EXISTS public.product_images (
    id VARCHAR(100) PRIMARY KEY,
    product_id VARCHAR(100) NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    image_url TEXT NOT NULL,
    display_order INT DEFAULT 0 NOT NULL,
    is_primary BOOLEAN DEFAULT FALSE NOT NULL
);

-- 10. INVENTORY TRANSACTIONS TABLE
CREATE TABLE IF NOT EXISTS public.inventory_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id VARCHAR(100) NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    product_name VARCHAR(255) NOT NULL,
    variant_id VARCHAR(100),
    variant_info VARCHAR(255),
    previous_quantity INT NOT NULL,
    new_quantity INT NOT NULL,
    change_amount INT NOT NULL,
    reason TEXT NOT NULL,
    admin_name VARCHAR(255) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 11. ADDRESSES TABLE
CREATE TABLE IF NOT EXISTS public.addresses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    full_name VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    alternate_phone VARCHAR(20),
    address_line1 TEXT NOT NULL,
    landmark TEXT,
    city VARCHAR(100) DEFAULT 'Ganj Basoda' NOT NULL,
    state VARCHAR(100) DEFAULT 'Madhya Pradesh' NOT NULL,
    pincode VARCHAR(20) DEFAULT '464221' NOT NULL,
    is_default BOOLEAN DEFAULT FALSE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 12. ORDERS TABLE
CREATE TABLE IF NOT EXISTS public.orders (
    id VARCHAR(100) PRIMARY KEY,
    order_number VARCHAR(100) NOT NULL UNIQUE,
    user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    customer_email VARCHAR(255),
    shipping_address JSONB NOT NULL,
    subtotal NUMERIC(12, 2) NOT NULL,
    discount_amount NUMERIC(12, 2) DEFAULT 0 NOT NULL,
    coupon_code VARCHAR(100),
    delivery_charge NUMERIC(12, 2) DEFAULT 0 NOT NULL,
    final_amount NUMERIC(12, 2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    payment_status VARCHAR(50) DEFAULT 'pending' NOT NULL,
    order_status order_status_type DEFAULT 'Pending'::order_status_type NOT NULL,
    order_notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 13. ORDER ITEMS TABLE
CREATE TABLE IF NOT EXISTS public.order_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id VARCHAR(100) NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    product_id VARCHAR(100) NOT NULL REFERENCES public.products(id) ON DELETE RESTRICT,
    product_name VARCHAR(255) NOT NULL,
    variant_id VARCHAR(100),
    variant_description VARCHAR(255),
    image_url TEXT NOT NULL,
    price NUMERIC(12, 2) NOT NULL,
    mrp NUMERIC(12, 2) NOT NULL,
    quantity INT NOT NULL,
    subtotal NUMERIC(12, 2) NOT NULL
);

-- 14. ORDER STATUS HISTORY TABLE
CREATE TABLE IF NOT EXISTS public.order_status_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id VARCHAR(100) NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    status order_status_type NOT NULL,
    note TEXT,
    updated_by VARCHAR(255),
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 15. OFFERS & COUPONS TABLE
CREATE TABLE IF NOT EXISTS public.offers (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    discount_type VARCHAR(20) NOT NULL, -- 'percentage' or 'flat'
    discount_value NUMERIC(12, 2) NOT NULL,
    coupon_code VARCHAR(100) UNIQUE,
    min_order_amount NUMERIC(12, 2) DEFAULT 0 NOT NULL,
    applicable_category_id VARCHAR(100) REFERENCES public.categories(id) ON DELETE SET NULL,
    applicable_product_id VARCHAR(100) REFERENCES public.products(id) ON DELETE SET NULL,
    start_date TIMESTAMPTZ NOT NULL,
    end_date TIMESTAMPTZ NOT NULL,
    usage_limit INT,
    usage_count INT DEFAULT 0 NOT NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    banner_badge VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 16. BANNERS TABLE
CREATE TABLE IF NOT EXISTS public.banners (
    id VARCHAR(100) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    subtitle TEXT,
    image_url TEXT NOT NULL,
    button_text VARCHAR(100) NOT NULL,
    button_destination VARCHAR(255) NOT NULL,
    display_order INT DEFAULT 0 NOT NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    start_date TIMESTAMPTZ,
    end_date TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 17. REVIEWS TABLE
CREATE TABLE IF NOT EXISTS public.reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id VARCHAR(100) NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(20),
    rating INT CHECK (rating >= 1 AND rating <= 5) NOT NULL,
    title VARCHAR(255) NOT NULL,
    comment TEXT NOT NULL,
    image_url TEXT,
    is_approved BOOLEAN DEFAULT FALSE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 18. BOOKING ENQUIRIES TABLE
CREATE TABLE IF NOT EXISTS public.bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    enquiry_type VARCHAR(100) NOT NULL,
    product_name VARCHAR(255),
    preferred_date DATE,
    message TEXT,
    status VARCHAR(50) DEFAULT 'New' NOT NULL,
    admin_notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 19. LUCKY DRAW PRIZES TABLE
CREATE TABLE IF NOT EXISTS public.lucky_draw_prizes (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    image_url TEXT NOT NULL,
    total_quantity INT NOT NULL,
    remaining_quantity INT NOT NULL,
    winning_chance_percent NUMERIC(5, 2) DEFAULT 10.00 NOT NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 20. LUCKY DRAW WINNERS TABLE
CREATE TABLE IF NOT EXISTS public.lucky_draw_winners (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    prize_id VARCHAR(100) NOT NULL REFERENCES public.lucky_draw_prizes(id) ON DELETE RESTRICT,
    prize_name VARCHAR(255) NOT NULL,
    prize_image TEXT NOT NULL,
    draw_date TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    is_delivered BOOLEAN DEFAULT FALSE NOT NULL,
    delivery_date DATE,
    ticket_number VARCHAR(100) NOT NULL UNIQUE
);

-- 21. FINANCE PROVIDERS TABLE
CREATE TABLE IF NOT EXISTS public.finance_providers (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    logo_url TEXT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    tagline VARCHAR(255) NOT NULL,
    interest_rate_from VARCHAR(100) NOT NULL,
    tenure_options VARCHAR(255) NOT NULL,
    documents_required JSONB NOT NULL,
    eligibility_notes TEXT NOT NULL,
    terms TEXT NOT NULL,
    cta_text VARCHAR(100) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 22. BOOK PAGES CONFIGURATION TABLE
CREATE TABLE IF NOT EXISTS public.book_pages (
    id VARCHAR(100) PRIMARY KEY,
    page_number INT NOT NULL UNIQUE,
    slug VARCHAR(100) NOT NULL UNIQUE,
    title VARCHAR(255) NOT NULL,
    subtitle TEXT NOT NULL,
    chapter_name VARCHAR(100) NOT NULL,
    icon_name VARCHAR(50) NOT NULL,
    is_enabled BOOLEAN DEFAULT TRUE NOT NULL,
    display_order INT NOT NULL,
    background_style TEXT,
    cta_label VARCHAR(100),
    cta_target_page INT,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 23. SITE SETTINGS TABLE
CREATE TABLE IF NOT EXISTS public.site_settings (
    id VARCHAR(50) PRIMARY KEY DEFAULT 'current',
    shop_name VARCHAR(255) NOT NULL,
    brand_tagline VARCHAR(255) NOT NULL,
    owner_name VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    whatsapp_number VARCHAR(20) NOT NULL,
    email VARCHAR(255) NOT NULL,
    address_street TEXT NOT NULL,
    address_area VARCHAR(100) NOT NULL,
    address_city VARCHAR(100) NOT NULL,
    address_district VARCHAR(100) NOT NULL,
    address_state VARCHAR(100) NOT NULL,
    address_pincode VARCHAR(20) NOT NULL,
    landmark TEXT NOT NULL,
    google_maps_url TEXT NOT NULL,
    opening_hours VARCHAR(255) NOT NULL,
    facebook_url TEXT,
    instagram_url TEXT,
    youtube_url TEXT,
    about_text TEXT NOT NULL,
    announcement_bar_text TEXT NOT NULL,
    free_delivery_above NUMERIC(10, 2) DEFAULT 999 NOT NULL,
    cod_available BOOLEAN DEFAULT TRUE NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 24. AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS public.audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    admin_name VARCHAR(255) NOT NULL,
    action VARCHAR(100) NOT NULL,
    entity VARCHAR(100) NOT NULL,
    entity_id VARCHAR(100),
    previous_value TEXT,
    new_value TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 25. NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS public.notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE NOT NULL,
    link TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- ========================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ========================================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.brands ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_variants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_status_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.offers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.banners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lucky_draw_prizes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lucky_draw_winners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.finance_providers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.book_pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Helper function to check admin role
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role IN ('super_admin', 'admin', 'manager')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Public read policies for catalogue
CREATE POLICY "Public can view active brands" ON public.brands FOR SELECT USING (is_active = true OR public.is_admin());
CREATE POLICY "Public can view active categories" ON public.categories FOR SELECT USING (is_active = true OR public.is_admin());
CREATE POLICY "Public can view active products" ON public.products FOR SELECT USING (is_active = true OR public.is_admin());
CREATE POLICY "Public can view product variants" ON public.product_variants FOR SELECT USING (true);
CREATE POLICY "Public can view product images" ON public.product_images FOR SELECT USING (true);
CREATE POLICY "Public can view active offers" ON public.offers FOR SELECT USING (is_active = true AND end_date >= NOW() OR public.is_admin());
CREATE POLICY "Public can view active banners" ON public.banners FOR SELECT USING (is_active = true OR public.is_admin());
CREATE POLICY "Public can view approved reviews" ON public.reviews FOR SELECT USING (is_approved = true OR public.is_admin());
CREATE POLICY "Public can view active lucky draw prizes" ON public.lucky_draw_prizes FOR SELECT USING (is_active = true OR public.is_admin());
CREATE POLICY "Public can view lucky draw winners" ON public.lucky_draw_winners FOR SELECT USING (true);
CREATE POLICY "Public can view active finance providers" ON public.finance_providers FOR SELECT USING (is_active = true OR public.is_admin());
CREATE POLICY "Public can view enabled book pages" ON public.book_pages FOR SELECT USING (is_enabled = true OR public.is_admin());
CREATE POLICY "Public can view site settings" ON public.site_settings FOR SELECT USING (true);

-- Customers can create bookings and view their own
CREATE POLICY "Anyone can create bookings" ON public.bookings FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can manage bookings" ON public.bookings FOR ALL USING (public.is_admin());

-- Reviews creation
CREATE POLICY "Anyone can submit reviews" ON public.reviews FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can manage reviews" ON public.reviews FOR ALL USING (public.is_admin());

-- Orders: Customer can read their own, Admins can read & update all
CREATE POLICY "Anyone can create orders" ON public.orders FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can create order items" ON public.order_items FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can manage all orders" ON public.orders FOR ALL USING (public.is_admin());
CREATE POLICY "Admins can manage all order items" ON public.order_items FOR ALL USING (public.is_admin());
CREATE POLICY "Public can view order status history" ON public.order_status_history FOR SELECT USING (true);

-- Admin full access to products, inventory, audit logs
CREATE POLICY "Admins can manage products" ON public.products FOR ALL USING (public.is_admin());
CREATE POLICY "Admins can manage variants" ON public.product_variants FOR ALL USING (public.is_admin());
CREATE POLICY "Admins can manage brands" ON public.brands FOR ALL USING (public.is_admin());
CREATE POLICY "Admins can manage categories" ON public.categories FOR ALL USING (public.is_admin());
CREATE POLICY "Admins can manage offers" ON public.offers FOR ALL USING (public.is_admin());
CREATE POLICY "Admins can manage banners" ON public.banners FOR ALL USING (public.is_admin());
CREATE POLICY "Admins can manage book pages" ON public.book_pages FOR ALL USING (public.is_admin());
CREATE POLICY "Admins can manage site settings" ON public.site_settings FOR ALL USING (public.is_admin());
CREATE POLICY "Admins can view inventory logs" ON public.inventory_transactions FOR SELECT USING (public.is_admin());
CREATE POLICY "Admins can view audit logs" ON public.audit_logs FOR SELECT USING (public.is_admin());

-- ========================================================================
-- STORAGE BUCKETS (Product Images, Brand Logos, Banners, Reviews)
-- ========================================================================
INSERT INTO storage.buckets (id, name, public) VALUES 
('product-images', 'product-images', true),
('brand-logos', 'brand-logos', true),
('banners', 'banners', true),
('review-images', 'review-images', true),
('lucky-draw-prizes', 'lucky-draw-prizes', true),
('site-assets', 'site-assets', true)
ON CONFLICT (id) DO NOTHING;
